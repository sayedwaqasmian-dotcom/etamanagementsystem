import crypto from 'crypto';

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_eta_salt_2026').digest('hex');
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: 'principal' | 'admin' | 'teacher' | 'accountant' | 'attendance_operator';
  passwordHash: string;
  phone: string;
  avatar?: string;
  assignedClassIds?: string[];
  createdAt: string;
}

export interface Teacher {
  id: string;
  name: string;
  gender: 'Male' | 'Female';
  qualification: string;
  subjects: string[];
  assignedClasses: string[];
  phone: string;
  joiningDate: string;
  monthlySalaryPKR: number;
  status: 'active' | 'archived';
  address: string;
  notes: string;
}

export interface ClassItem {
  id: string;
  name: string; // "6th", "7th", "8th", "9th", "10th", "11th", "12th"
  gradeNumber: number;
  sections: string[];
  subjects: string[];
  monthlyFeePKR: number;
  roomNo?: string;
  classTeacher?: string;
}

export interface Student {
  id: string; // e.g. "ETA-2026-001"
  name: string;
  fatherName: string;
  classId: string;
  className: string;
  section: string;
  rollNo: string;
  admissionDate: string;
  dob: string;
  gender: 'Male' | 'Female';
  studentPhone: string;
  guardianPhone: string;
  address: string;
  previousSchool: string;
  monthlyFeePKR: number;
  discountPKR: number;
  status: 'active' | 'archived' | 'graduated';
  notes: string;
  avatar?: string;
  createdAt: string;
}

export interface FeeInvoice {
  id: string;
  invoiceNo: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  month: string; // e.g. "October 2026"
  year: number;
  dueDate: string;
  amountPKR: number;
  discountPKR: number;
  netAmountPKR: number;
  paidAmountPKR: number;
  balancePKR: number;
  status: 'paid' | 'partial' | 'unpaid' | 'overdue' | 'waived';
  createdAt: string;
}

export interface FeePayment {
  id: string;
  receiptNo: string;
  invoiceId: string;
  studentId: string;
  studentName: string;
  amountPKR: number;
  paymentMethod: 'Cash' | 'Bank Transfer' | 'EasyPaisa' | 'JazzCash';
  paymentDate: string;
  collectorName: string;
  remarks: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  date: string; // YYYY-MM-DD
  classId: string;
  className: string;
  section: string;
  records: {
    studentId: string;
    studentName: string;
    rollNo: string;
    status: 'present' | 'absent' | 'late' | 'leave';
    remarks?: string;
  }[];
  recordedBy: string;
  updatedAt: string;
}

export interface ExamTest {
  id: string;
  title: string;
  classId: string;
  className: string;
  subject: string;
  date: string;
  totalMarks: number;
  passingMarks: number;
  instructions: string;
  results: {
    studentId: string;
    studentName: string;
    rollNo: string;
    marksObtained: number;
    remarks: string;
  }[];
  createdAt: string;
}

export interface McqQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  marks: number;
}

export interface McqTest {
  id: string;
  title: string;
  classId: string;
  className: string;
  subject: string;
  durationMinutes: number;
  totalMarks: number;
  questions: McqQuestion[];
  status: 'active' | 'draft';
  createdAt: string;
}

export interface McqAttempt {
  id: string;
  testId: string;
  testTitle: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  score: number;
  totalMarks: number;
  percentage: number;
  answers: {
    questionId: string;
    selectedOptionIndex: number;
    isCorrect: boolean;
  }[];
  submittedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  details: string;
}

export interface AcademySettings {
  name: string;
  shortName: string;
  principal: string;
  location: string;
  phone: string;
  whatsappNumber: string;
  whatsappLink: string;
  mapLink: string;
  currency: string;
  academicSession: string;
  tagline: string;
}

export function getInitialDatabaseData() {
  const commonPasswordHash = hashPassword('eta12345');

  const users: User[] = [
    {
      id: 'USR-01',
      name: 'Mr. Rahmat Ali',
      username: 'principal',
      email: 'principal@eta-academy.edu.pk',
      role: 'principal',
      passwordHash: commonPasswordHash,
      phone: '0345-6898969',
      createdAt: '2026-01-01T08:00:00Z',
    },
    {
      id: 'USR-02',
      name: 'Admin Desk',
      username: 'admin',
      email: 'admin@eta-academy.edu.pk',
      role: 'admin',
      passwordHash: commonPasswordHash,
      phone: '0345-6898969',
      createdAt: '2026-01-01T08:00:00Z',
    },
    {
      id: 'USR-03',
      name: 'Mr. Nouman Khan',
      username: 'teacher',
      email: 'nouman@eta-academy.edu.pk',
      role: 'teacher',
      passwordHash: commonPasswordHash,
      phone: '0345-6898969',
      assignedClassIds: ['CLS-09', 'CLS-10', 'CLS-11', 'CLS-12'],
      createdAt: '2026-01-01T08:00:00Z',
    },
    {
      id: 'USR-04',
      name: 'Muhammad Farooq',
      username: 'accountant',
      email: 'accounts@eta-academy.edu.pk',
      role: 'accountant',
      passwordHash: commonPasswordHash,
      phone: '0345-6898969',
      createdAt: '2026-01-01T08:00:00Z',
    },
    {
      id: 'USR-05',
      name: 'Tariq Mehmood',
      username: 'operator',
      email: 'attendance@eta-academy.edu.pk',
      role: 'attendance_operator',
      passwordHash: commonPasswordHash,
      phone: '0345-6898969',
      createdAt: '2026-01-01T08:00:00Z',
    },
  ];

  // Teachers as explicitly requested in prompt
  const teachers: Teacher[] = [
    {
      id: 'TCH-001',
      name: 'Mr. Nouman Khan',
      gender: 'Male',
      qualification: 'MPhil Botany/Chemistry',
      subjects: ['Botany', 'Chemistry', 'General Science'],
      assignedClasses: ['9th', '10th', '11th', '12th'],
      phone: '0345-6898969',
      joiningDate: '2023-03-01',
      monthlySalaryPKR: 45000,
      status: 'active',
      address: 'Khwazakhela, Swat',
      notes: 'Senior faculty Botany & Chemistry',
    },
    {
      id: 'TCH-002',
      name: 'Mr. Sultan Zeb',
      gender: 'Male',
      qualification: 'MPhil English',
      subjects: ['English Literature', 'English Grammar', 'Spoken English'],
      assignedClasses: ['8th', '9th', '10th', '11th', '12th'],
      phone: '0345-6898969',
      joiningDate: '2023-04-15',
      monthlySalaryPKR: 42000,
      status: 'active',
      address: 'Mata Road, Swat',
      notes: 'English Department Head',
    },
    {
      id: 'TCH-003',
      name: 'Hazrat Ali Mian',
      gender: 'Male',
      qualification: 'MA Urdu',
      subjects: ['Urdu Adab', 'Urdu Grammar', 'Islamic Studies'],
      assignedClasses: ['6th', '7th', '8th', '9th', '10th'],
      phone: '0345-6898969',
      joiningDate: '2022-09-01',
      monthlySalaryPKR: 38000,
      status: 'active',
      address: 'Khwazakhela Bazar, Swat',
      notes: 'Distinguished Urdu Scholar',
    },
    {
      id: 'TCH-004',
      name: 'Mr. Haider Ali',
      gender: 'Male',
      qualification: 'MPhil Physics',
      subjects: ['Physics', 'Applied Physics', 'Numerical Analysis'],
      assignedClasses: ['9th', '10th', '11th', '12th'],
      phone: '0345-6898969',
      joiningDate: '2023-02-10',
      monthlySalaryPKR: 46000,
      status: 'active',
      address: 'Khwazakhela, Swat',
      notes: 'Physics Laboratory Director',
    },
    {
      id: 'TCH-005',
      name: 'Mr. Qasim',
      gender: 'Male',
      qualification: 'MSc Mathematics',
      subjects: ['Mathematics', 'Calculus', 'Algebra'],
      assignedClasses: ['7th', '8th', '9th', '10th', '11th'],
      phone: '0345-6898969',
      joiningDate: '2023-06-01',
      monthlySalaryPKR: 40000,
      status: 'active',
      address: 'Mingora / Khwazakhela, Swat',
      notes: 'Mathematics lead',
    },
    {
      id: 'TCH-006',
      name: 'Ms. Sumera',
      gender: 'Female',
      qualification: 'BS Chemistry',
      subjects: ['Chemistry', 'Organic Chemistry'],
      assignedClasses: ['8th', '9th', '10th'],
      phone: '0345-6898969',
      joiningDate: '2024-01-15',
      monthlySalaryPKR: 35000,
      status: 'active',
      address: 'Khwazakhela, Swat',
      notes: 'Girls Section In-charge & Chemistry Lecturer',
    },
    {
      id: 'TCH-007',
      name: 'Ms. Asma',
      gender: 'Female',
      qualification: 'MCS Mathematics',
      subjects: ['Mathematics', 'Statistics'],
      assignedClasses: ['6th', '7th', '8th'],
      phone: '0345-6898969',
      joiningDate: '2024-02-01',
      monthlySalaryPKR: 35000,
      status: 'active',
      address: 'Khwazakhela, Swat',
      notes: 'Junior Section Mathematics Teacher',
    },
    {
      id: 'TCH-008',
      name: 'Ms. Hafsa',
      gender: 'Female',
      qualification: 'BS Computer Science',
      subjects: ['Computer Science', 'Information Technology', 'Coding Basics'],
      assignedClasses: ['6th', '7th', '8th', '9th', '10th', '11th', '12th'],
      phone: '0345-6898969',
      joiningDate: '2024-03-01',
      monthlySalaryPKR: 37000,
      status: 'active',
      address: 'Khwazakhela, Swat',
      notes: 'Computer Lab Coordinator',
    },
  ];

  const classes: ClassItem[] = [
    {
      id: 'CLS-06',
      name: '6th',
      gradeNumber: 6,
      sections: ['A', 'B'],
      subjects: ['English', 'Urdu', 'Mathematics', 'General Science', 'Islamiat', 'Social Studies', 'Computer'],
      monthlyFeePKR: 2500,
      roomNo: 'Room 101',
      classTeacher: 'Ms. Asma',
    },
    {
      id: 'CLS-07',
      name: '7th',
      gradeNumber: 7,
      sections: ['A', 'B'],
      subjects: ['English', 'Urdu', 'Mathematics', 'General Science', 'Islamiat', 'Social Studies', 'Computer'],
      monthlyFeePKR: 2500,
      roomNo: 'Room 102',
      classTeacher: 'Mr. Qasim',
    },
    {
      id: 'CLS-08',
      name: '8th',
      gradeNumber: 8,
      sections: ['A', 'B'],
      subjects: ['English', 'Urdu', 'Mathematics', 'General Science', 'Islamiat', 'Social Studies', 'Computer'],
      monthlyFeePKR: 2800,
      roomNo: 'Room 103',
      classTeacher: 'Mr. Sultan Zeb',
    },
    {
      id: 'CLS-09',
      name: '9th',
      gradeNumber: 9,
      sections: ['Science', 'Computer Science'],
      subjects: ['English', 'Urdu', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Computer Science', 'Islamiat', 'Pak Studies'],
      monthlyFeePKR: 3500,
      roomNo: 'Room 201',
      classTeacher: 'Mr. Haider Ali',
    },
    {
      id: 'CLS-10',
      name: '10th',
      gradeNumber: 10,
      sections: ['Science', 'Computer Science'],
      subjects: ['English', 'Urdu', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Computer Science', 'Islamiat', 'Pak Studies'],
      monthlyFeePKR: 3500,
      roomNo: 'Room 202',
      classTeacher: 'Mr. Nouman Khan',
    },
    {
      id: 'CLS-11',
      name: '11th',
      gradeNumber: 11,
      sections: ['Pre-Medical', 'Pre-Engineering', 'Computer Science'],
      subjects: ['English', 'Urdu', 'Physics', 'Chemistry', 'Biology', 'Mathematics', 'Computer Science', 'Islamiat'],
      monthlyFeePKR: 4500,
      roomNo: 'Room 301',
      classTeacher: 'Mr. Haider Ali',
    },
    {
      id: 'CLS-12',
      name: '12th',
      gradeNumber: 12,
      sections: ['Pre-Medical', 'Pre-Engineering', 'Computer Science'],
      subjects: ['English', 'Urdu', 'Physics', 'Chemistry', 'Biology', 'Mathematics', 'Computer Science', 'Pak Studies'],
      monthlyFeePKR: 4500,
      roomNo: 'Room 302',
      classTeacher: 'Mr. Nouman Khan',
    },
  ];

  // Seed 14 realistic active students across classes 6th - 12th
  const students: Student[] = [
    {
      id: 'ETA-2026-001',
      name: 'Muhammad Ahmad',
      fatherName: 'Abdul Rashid Khan',
      classId: 'CLS-06',
      className: '6th',
      section: 'A',
      rollNo: '01',
      admissionDate: '2026-03-01',
      dob: '2014-04-12',
      gender: 'Male',
      studentPhone: '0345-6898969',
      guardianPhone: '0346-9321456',
      address: 'Mata Road, Khwazakhela, Swat',
      previousSchool: 'Khwazakhela Public School',
      monthlyFeePKR: 2500,
      discountPKR: 0,
      status: 'active',
      notes: 'Hardworking student, top of junior batch',
      createdAt: '2026-03-01T09:00:00Z',
    },
    {
      id: 'ETA-2026-002',
      name: 'Fatima Bibi',
      fatherName: 'Gul Muhammad',
      classId: 'CLS-06',
      className: '6th',
      section: 'B',
      rollNo: '02',
      admissionDate: '2026-03-05',
      dob: '2014-06-18',
      gender: 'Female',
      studentPhone: '',
      guardianPhone: '0347-8812345',
      address: 'Bazar Khwazakhela, Swat',
      previousSchool: 'Al-Huda Academy',
      monthlyFeePKR: 2500,
      discountPKR: 500,
      status: 'active',
      notes: 'Sibling discount applied (Rs. 500)',
      createdAt: '2026-03-05T09:00:00Z',
    },
    {
      id: 'ETA-2026-003',
      name: 'Bilal Khan',
      fatherName: 'Sher Zaman',
      classId: 'CLS-07',
      className: '7th',
      section: 'A',
      rollNo: '01',
      admissionDate: '2026-02-15',
      dob: '2013-08-22',
      gender: 'Male',
      studentPhone: '',
      guardianPhone: '0342-9900112',
      address: 'Main Chowk, Khwazakhela, Swat',
      previousSchool: 'Swat Model High School',
      monthlyFeePKR: 2500,
      discountPKR: 0,
      status: 'active',
      notes: 'Excellent math foundation',
      createdAt: '2026-02-15T09:00:00Z',
    },
    {
      id: 'ETA-2026-004',
      name: 'Ayesha Noor',
      fatherName: 'Noor-ul-Haq',
      classId: 'CLS-07',
      className: '7th',
      section: 'B',
      rollNo: '02',
      admissionDate: '2026-02-20',
      dob: '2013-11-05',
      gender: 'Female',
      studentPhone: '',
      guardianPhone: '0348-1234567',
      address: 'Near Civil Hospital, Khwazakhela, Swat',
      previousSchool: 'Farishta Model School',
      monthlyFeePKR: 2500,
      discountPKR: 0,
      status: 'active',
      notes: 'Punctual and attentive',
      createdAt: '2026-02-20T09:00:00Z',
    },
    {
      id: 'ETA-2026-005',
      name: 'Hamza Tariq',
      fatherName: 'Tariq Mehmood',
      classId: 'CLS-08',
      className: '8th',
      section: 'A',
      rollNo: '01',
      admissionDate: '2026-01-10',
      dob: '2012-05-14',
      gender: 'Male',
      studentPhone: '0340-5544332',
      guardianPhone: '0345-6898969',
      address: 'Mata Road, Swat',
      previousSchool: 'Government High School Khwazakhela',
      monthlyFeePKR: 2800,
      discountPKR: 300,
      status: 'active',
      notes: 'Staff child concession (Rs. 300)',
      createdAt: '2026-01-10T09:00:00Z',
    },
    {
      id: 'ETA-2026-006',
      name: 'Zainab Rehman',
      fatherName: 'Fazal Rehman',
      classId: 'CLS-08',
      className: '8th',
      section: 'B',
      rollNo: '02',
      admissionDate: '2026-01-12',
      dob: '2012-09-30',
      gender: 'Female',
      studentPhone: '',
      guardianPhone: '0343-7766554',
      address: 'Charbagh / Khwazakhela, Swat',
      previousSchool: 'Swat Public School',
      monthlyFeePKR: 2800,
      discountPKR: 0,
      status: 'active',
      notes: 'High achiever in Science subjects',
      createdAt: '2026-01-12T09:00:00Z',
    },
    {
      id: 'ETA-2026-007',
      name: 'Usman Ali',
      fatherName: 'Liaqat Ali Khan',
      classId: 'CLS-09',
      className: '9th',
      section: 'Science',
      rollNo: '01',
      admissionDate: '2025-08-01',
      dob: '2011-03-10',
      gender: 'Male',
      studentPhone: '0341-9876543',
      guardianPhone: '0345-9876543',
      address: 'Shalpin Road, Khwazakhela, Swat',
      previousSchool: 'ETA Junior Section',
      monthlyFeePKR: 3500,
      discountPKR: 500,
      status: 'active',
      notes: 'Pre-Medical aspirant, consistent top 3',
      createdAt: '2025-08-01T09:00:00Z',
    },
    {
      id: 'ETA-2026-008',
      name: 'Zahid Ullah',
      fatherName: 'Inam Ullah',
      classId: 'CLS-09',
      className: '9th',
      section: 'Computer Science',
      rollNo: '02',
      admissionDate: '2025-08-05',
      dob: '2011-07-25',
      gender: 'Male',
      studentPhone: '0344-1122334',
      guardianPhone: '0346-4455667',
      address: 'Shin, Khwazakhela, Swat',
      previousSchool: 'Khwazakhela Science College',
      monthlyFeePKR: 3500,
      discountPKR: 0,
      status: 'active',
      notes: 'Passionate about programming',
      createdAt: '2025-08-05T09:00:00Z',
    },
    {
      id: 'ETA-2026-009',
      name: 'Shahab Uddin',
      fatherName: 'Siraj Uddin',
      classId: 'CLS-10',
      className: '10th',
      section: 'Science',
      rollNo: '01',
      admissionDate: '2025-04-10',
      dob: '2010-02-14',
      gender: 'Male',
      studentPhone: '0349-2233445',
      guardianPhone: '0345-7788990',
      address: 'Fatehpur Road, Swat',
      previousSchool: 'Government High School Khwazakhela',
      monthlyFeePKR: 3500,
      discountPKR: 0,
      status: 'active',
      notes: 'Matric Board preparation squad leader',
      createdAt: '2025-04-10T09:00:00Z',
    },
    {
      id: 'ETA-2026-010',
      name: 'Khadija Bibi',
      fatherName: 'Dr. Anwar Shah',
      classId: 'CLS-10',
      className: '10th',
      section: 'Science',
      rollNo: '02',
      admissionDate: '2025-04-12',
      dob: '2010-10-08',
      gender: 'Female',
      studentPhone: '',
      guardianPhone: '0344-5566778',
      address: 'Khwazakhela Bazar, Swat',
      previousSchool: 'St. Mary High School',
      monthlyFeePKR: 3500,
      discountPKR: 0,
      status: 'active',
      notes: 'Preparing for BISE Swat board exam',
      createdAt: '2025-04-12T09:00:00Z',
    },
    {
      id: 'ETA-2026-011',
      name: 'Abdullah Khan',
      fatherName: 'Dr. Mukhtiar Ahmad',
      classId: 'CLS-11',
      className: '11th',
      section: 'Pre-Medical',
      rollNo: '01',
      admissionDate: '2025-09-01',
      dob: '2009-01-20',
      gender: 'Male',
      studentPhone: '0347-1239874',
      guardianPhone: '0345-6677889',
      address: 'Mata Road, Khwazakhela, Swat',
      previousSchool: 'Cadet College Swat',
      monthlyFeePKR: 4500,
      discountPKR: 1000,
      status: 'active',
      notes: 'Merit Scholarship holder (Rs. 1000 discount)',
      createdAt: '2025-09-01T09:00:00Z',
    },
    {
      id: 'ETA-2026-012',
      name: 'Irfan Ullah',
      fatherName: 'Saad Ullah Khan',
      classId: 'CLS-11',
      className: '11th',
      section: 'Pre-Engineering',
      rollNo: '02',
      admissionDate: '2025-09-03',
      dob: '2009-04-15',
      gender: 'Male',
      studentPhone: '0346-7788221',
      guardianPhone: '0343-9988776',
      address: 'Chuprial Road, Swat',
      previousSchool: 'Government Degree College Khwazakhela',
      monthlyFeePKR: 4500,
      discountPKR: 0,
      status: 'active',
      notes: 'Targeting UET Peshawar engineering entrance',
      createdAt: '2025-09-03T09:00:00Z',
    },
    {
      id: 'ETA-2026-013',
      name: 'Saad Ali',
      fatherName: 'Bakht Ali',
      classId: 'CLS-12',
      className: '12th',
      section: 'Pre-Medical',
      rollNo: '01',
      admissionDate: '2024-09-01',
      dob: '2008-03-05',
      gender: 'Male',
      studentPhone: '0345-1234455',
      guardianPhone: '0342-8877665',
      address: 'Khwazakhela, Swat',
      previousSchool: 'ETA College Wing',
      monthlyFeePKR: 4500,
      discountPKR: 500,
      status: 'active',
      notes: 'MDCAT / ETEA Medical test batch',
      createdAt: '2024-09-01T09:00:00Z',
    },
    {
      id: 'ETA-2026-014',
      name: 'Musa Khan',
      fatherName: 'Zahid Khan',
      classId: 'CLS-12',
      className: '12th',
      section: 'Computer Science',
      rollNo: '02',
      admissionDate: '2024-09-05',
      dob: '2008-08-19',
      gender: 'Male',
      studentPhone: '0348-9900887',
      guardianPhone: '0345-6898969',
      address: 'Mata Road, Swat',
      previousSchool: 'ETA College Wing',
      monthlyFeePKR: 4500,
      discountPKR: 0,
      status: 'active',
      notes: 'NUST / FAST CS entrance prep',
      createdAt: '2024-09-05T09:00:00Z',
    },
  ];

  // Invoices for Current Month (October 2026) and Previous Month
  const currentMonth = 'October 2026';
  const feeInvoices: FeeInvoice[] = [
    {
      id: 'INV-2026-10-001',
      invoiceNo: 'ETA-INV-1001',
      studentId: 'ETA-2026-001',
      studentName: 'Muhammad Ahmad',
      classId: 'CLS-06',
      className: '6th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2500,
      discountPKR: 0,
      netAmountPKR: 2500,
      paidAmountPKR: 2500,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-002',
      invoiceNo: 'ETA-INV-1002',
      studentId: 'ETA-2026-002',
      studentName: 'Fatima Bibi',
      classId: 'CLS-06',
      className: '6th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2500,
      discountPKR: 500,
      netAmountPKR: 2000,
      paidAmountPKR: 2000,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-003',
      invoiceNo: 'ETA-INV-1003',
      studentId: 'ETA-2026-003',
      studentName: 'Bilal Khan',
      classId: 'CLS-07',
      className: '7th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2500,
      discountPKR: 0,
      netAmountPKR: 2500,
      paidAmountPKR: 0,
      balancePKR: 2500,
      status: 'overdue',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-004',
      invoiceNo: 'ETA-INV-1004',
      studentId: 'ETA-2026-004',
      studentName: 'Ayesha Noor',
      classId: 'CLS-07',
      className: '7th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2500,
      discountPKR: 0,
      netAmountPKR: 2500,
      paidAmountPKR: 2500,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-005',
      invoiceNo: 'ETA-INV-1005',
      studentId: 'ETA-2026-005',
      studentName: 'Hamza Tariq',
      classId: 'CLS-08',
      className: '8th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2800,
      discountPKR: 300,
      netAmountPKR: 2500,
      paidAmountPKR: 1500,
      balancePKR: 1000,
      status: 'partial',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-006',
      invoiceNo: 'ETA-INV-1006',
      studentId: 'ETA-2026-006',
      studentName: 'Zainab Rehman',
      classId: 'CLS-08',
      className: '8th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 2800,
      discountPKR: 0,
      netAmountPKR: 2800,
      paidAmountPKR: 2800,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-007',
      invoiceNo: 'ETA-INV-1007',
      studentId: 'ETA-2026-007',
      studentName: 'Usman Ali',
      classId: 'CLS-09',
      className: '9th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 3500,
      discountPKR: 500,
      netAmountPKR: 3000,
      paidAmountPKR: 3000,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-008',
      invoiceNo: 'ETA-INV-1008',
      studentId: 'ETA-2026-008',
      studentName: 'Zahid Ullah',
      classId: 'CLS-09',
      className: '9th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 3500,
      discountPKR: 0,
      netAmountPKR: 3500,
      paidAmountPKR: 0,
      balancePKR: 3500,
      status: 'overdue',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-009',
      invoiceNo: 'ETA-INV-1009',
      studentId: 'ETA-2026-009',
      studentName: 'Shahab Uddin',
      classId: 'CLS-10',
      className: '10th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 3500,
      discountPKR: 0,
      netAmountPKR: 3500,
      paidAmountPKR: 3500,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-010',
      invoiceNo: 'ETA-INV-1010',
      studentId: 'ETA-2026-010',
      studentName: 'Khadija Bibi',
      classId: 'CLS-10',
      className: '10th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 3500,
      discountPKR: 0,
      netAmountPKR: 3500,
      paidAmountPKR: 3500,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-011',
      invoiceNo: 'ETA-INV-1011',
      studentId: 'ETA-2026-011',
      studentName: 'Abdullah Khan',
      classId: 'CLS-11',
      className: '11th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 4500,
      discountPKR: 1000,
      netAmountPKR: 3500,
      paidAmountPKR: 3500,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-012',
      invoiceNo: 'ETA-INV-1012',
      studentId: 'ETA-2026-012',
      studentName: 'Irfan Ullah',
      classId: 'CLS-11',
      className: '11th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 4500,
      discountPKR: 0,
      netAmountPKR: 4500,
      paidAmountPKR: 2000,
      balancePKR: 2500,
      status: 'partial',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-013',
      invoiceNo: 'ETA-INV-1013',
      studentId: 'ETA-2026-013',
      studentName: 'Saad Ali',
      classId: 'CLS-12',
      className: '12th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 4500,
      discountPKR: 500,
      netAmountPKR: 4000,
      paidAmountPKR: 4000,
      balancePKR: 0,
      status: 'paid',
      createdAt: '2026-10-01T08:00:00Z',
    },
    {
      id: 'INV-2026-10-014',
      invoiceNo: 'ETA-INV-1014',
      studentId: 'ETA-2026-014',
      studentName: 'Musa Khan',
      classId: 'CLS-12',
      className: '12th',
      month: currentMonth,
      year: 2026,
      dueDate: '2026-10-10',
      amountPKR: 4500,
      discountPKR: 0,
      netAmountPKR: 4500,
      paidAmountPKR: 0,
      balancePKR: 4500,
      status: 'overdue',
      createdAt: '2026-10-01T08:00:00Z',
    },
  ];

  const feePayments: FeePayment[] = [
    {
      id: 'PAY-1001',
      receiptNo: 'ETA-REC-2026-001',
      invoiceId: 'INV-2026-10-001',
      studentId: 'ETA-2026-001',
      studentName: 'Muhammad Ahmad',
      amountPKR: 2500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-03',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Full fee paid for October 2026',
      createdAt: '2026-10-03T10:15:00Z',
    },
    {
      id: 'PAY-1002',
      receiptNo: 'ETA-REC-2026-002',
      invoiceId: 'INV-2026-10-002',
      studentId: 'ETA-2026-002',
      studentName: 'Fatima Bibi',
      amountPKR: 2000,
      paymentMethod: 'EasyPaisa',
      paymentDate: '2026-10-04',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'EasyPaisa Txn #EP88992',
      createdAt: '2026-10-04T11:30:00Z',
    },
    {
      id: 'PAY-1003',
      receiptNo: 'ETA-REC-2026-003',
      invoiceId: 'INV-2026-10-004',
      studentId: 'ETA-2026-004',
      studentName: 'Ayesha Noor',
      amountPKR: 2500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-05',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Cash receipt issued',
      createdAt: '2026-10-05T09:45:00Z',
    },
    {
      id: 'PAY-1004',
      receiptNo: 'ETA-REC-2026-004',
      invoiceId: 'INV-2026-10-005',
      studentId: 'ETA-2026-005',
      studentName: 'Hamza Tariq',
      amountPKR: 1500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-06',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Partial payment received, remaining Rs. 1000',
      createdAt: '2026-10-06T12:00:00Z',
    },
    {
      id: 'PAY-1005',
      receiptNo: 'ETA-REC-2026-005',
      invoiceId: 'INV-2026-10-006',
      studentId: 'ETA-2026-006',
      studentName: 'Zainab Rehman',
      amountPKR: 2800,
      paymentMethod: 'JazzCash',
      paymentDate: '2026-10-07',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Online transfer JazzCash Txn #JC55441',
      createdAt: '2026-10-07T14:20:00Z',
    },
    {
      id: 'PAY-1006',
      receiptNo: 'ETA-REC-2026-006',
      invoiceId: 'INV-2026-10-007',
      studentId: 'ETA-2026-007',
      studentName: 'Usman Ali',
      amountPKR: 3000,
      paymentMethod: 'Bank Transfer',
      paymentDate: '2026-10-07',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Habib Bank Ltd receipt attached',
      createdAt: '2026-10-07T15:10:00Z',
    },
    {
      id: 'PAY-1007',
      receiptNo: 'ETA-REC-2026-007',
      invoiceId: 'INV-2026-10-009',
      studentId: 'ETA-2026-009',
      studentName: 'Shahab Uddin',
      amountPKR: 3500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-08',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Full monthly fee paid',
      createdAt: '2026-10-08T10:00:00Z',
    },
    {
      id: 'PAY-1008',
      receiptNo: 'ETA-REC-2026-008',
      invoiceId: 'INV-2026-10-010',
      studentId: 'ETA-2026-010',
      studentName: 'Khadija Bibi',
      amountPKR: 3500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-08',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Full fee paid',
      createdAt: '2026-10-08T11:15:00Z',
    },
    {
      id: 'PAY-1009',
      receiptNo: 'ETA-REC-2026-009',
      invoiceId: 'INV-2026-10-011',
      studentId: 'ETA-2026-011',
      studentName: 'Abdullah Khan',
      amountPKR: 3500,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-09',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Net fee after scholarship paid',
      createdAt: '2026-10-09T09:30:00Z',
    },
    {
      id: 'PAY-1010',
      receiptNo: 'ETA-REC-2026-010',
      invoiceId: 'INV-2026-10-012',
      studentId: 'ETA-2026-012',
      studentName: 'Irfan Ullah',
      amountPKR: 2000,
      paymentMethod: 'Cash',
      paymentDate: '2026-10-09',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Partial fee paid, balance Rs. 2500',
      createdAt: '2026-10-09T10:45:00Z',
    },
    {
      id: 'PAY-1011',
      receiptNo: 'ETA-REC-2026-011',
      invoiceId: 'INV-2026-10-013',
      studentId: 'ETA-2026-013',
      studentName: 'Saad Ali',
      amountPKR: 4000,
      paymentMethod: 'Bank Transfer',
      paymentDate: '2026-10-09',
      collectorName: 'Muhammad Farooq (Accountant)',
      remarks: 'Allied Bank Khwazakhela online transfer',
      createdAt: '2026-10-09T13:00:00Z',
    },
  ];

  // Today's attendance session (2026-10-14)
  const today = '2026-10-14';
  const attendanceRecords: AttendanceRecord[] = [
    {
      id: 'ATT-2026-10-14-CLS-06',
      date: today,
      classId: 'CLS-06',
      className: '6th',
      section: 'A',
      records: [
        { studentId: 'ETA-2026-001', studentName: 'Muhammad Ahmad', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-002', studentName: 'Fatima Bibi', rollNo: '02', status: 'present' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:30:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-07',
      date: today,
      classId: 'CLS-07',
      className: '7th',
      section: 'A',
      records: [
        { studentId: 'ETA-2026-003', studentName: 'Bilal Khan', rollNo: '01', status: 'absent', remarks: 'Uninformed absence' },
        { studentId: 'ETA-2026-004', studentName: 'Ayesha Noor', rollNo: '02', status: 'present' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:35:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-08',
      date: today,
      classId: 'CLS-08',
      className: '8th',
      section: 'A',
      records: [
        { studentId: 'ETA-2026-005', studentName: 'Hamza Tariq', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-006', studentName: 'Zainab Rehman', rollNo: '02', status: 'present' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:40:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-09',
      date: today,
      classId: 'CLS-09',
      className: '9th',
      section: 'Science',
      records: [
        { studentId: 'ETA-2026-007', studentName: 'Usman Ali', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-008', studentName: 'Zahid Ullah', rollNo: '02', status: 'late', remarks: 'Arrived 15m late' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:45:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-10',
      date: today,
      classId: 'CLS-10',
      className: '10th',
      section: 'Science',
      records: [
        { studentId: 'ETA-2026-009', studentName: 'Shahab Uddin', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-010', studentName: 'Khadija Bibi', rollNo: '02', status: 'leave', remarks: 'Medical leave approved' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:50:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-11',
      date: today,
      classId: 'CLS-11',
      className: '11th',
      section: 'Pre-Medical',
      records: [
        { studentId: 'ETA-2026-011', studentName: 'Abdullah Khan', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-012', studentName: 'Irfan Ullah', rollNo: '02', status: 'present' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T08:55:00Z',
    },
    {
      id: 'ATT-2026-10-14-CLS-12',
      date: today,
      classId: 'CLS-12',
      className: '12th',
      section: 'Pre-Medical',
      records: [
        { studentId: 'ETA-2026-013', studentName: 'Saad Ali', rollNo: '01', status: 'present' },
        { studentId: 'ETA-2026-014', studentName: 'Musa Khan', rollNo: '02', status: 'present' },
      ],
      recordedBy: 'Tariq Mehmood (Attendance Operator)',
      updatedAt: '2026-10-14T09:00:00Z',
    },
  ];

  // Tests & Exams
  const tests: ExamTest[] = [
    {
      id: 'TST-001',
      title: 'First Monthly Assessment — Physics',
      classId: 'CLS-09',
      className: '9th',
      subject: 'Physics',
      date: '2026-10-05',
      totalMarks: 50,
      passingMarks: 20,
      instructions: 'Chapter 1 & 2: Physical Quantities, Kinematics. Calculator allowed.',
      results: [
        { studentId: 'ETA-2026-007', studentName: 'Usman Ali', rollNo: '01', marksObtained: 46, remarks: 'Excellent performance' },
        { studentId: 'ETA-2026-008', studentName: 'Zahid Ullah', rollNo: '02', marksObtained: 38, remarks: 'Good attempt, focus on numericals' },
      ],
      createdAt: '2026-10-01T10:00:00Z',
    },
    {
      id: 'TST-002',
      title: 'Mid-Term Exam — Mathematics',
      classId: 'CLS-10',
      className: '10th',
      subject: 'Mathematics',
      date: '2026-10-08',
      totalMarks: 75,
      passingMarks: 30,
      instructions: 'Quadratic Equations, Theory of Quadratic Equations, Variations.',
      results: [
        { studentId: 'ETA-2026-009', studentName: 'Shahab Uddin', rollNo: '01', marksObtained: 71, remarks: 'Outstanding, 1st position' },
        { studentId: 'ETA-2026-010', studentName: 'Khadija Bibi', rollNo: '02', marksObtained: 68, remarks: 'Very good' },
      ],
      createdAt: '2026-10-02T10:00:00Z',
    },
    {
      id: 'TST-003',
      title: 'Pre-Board Mock Assessment — Chemistry',
      classId: 'CLS-12',
      className: '12th',
      subject: 'Chemistry',
      date: '2026-10-10',
      totalMarks: 85,
      passingMarks: 34,
      instructions: 'Organic Chemistry, Reaction Mechanisms & Hydrocarbons.',
      results: [
        { studentId: 'ETA-2026-013', studentName: 'Saad Ali', rollNo: '01', marksObtained: 78, remarks: 'Top scorer' },
        { studentId: 'ETA-2026-014', studentName: 'Musa Khan', rollNo: '02', marksObtained: 62, remarks: 'Passed with high B grade' },
      ],
      createdAt: '2026-10-04T10:00:00Z',
    },
  ];

  // ETEA Style MCQ Practice Tests
  const mcqTests: McqTest[] = [
    {
      id: 'MCQ-001',
      title: 'ETEA / MDCAT Biology Practice Test 1',
      classId: 'CLS-12',
      className: '12th',
      subject: 'Biology',
      durationMinutes: 15,
      totalMarks: 20,
      status: 'active',
      createdAt: '2026-10-01T10:00:00Z',
      questions: [
        {
          id: 'Q1',
          question: 'Which of the following cellular organelles is known as the powerhouse of the cell?',
          options: ['Ribosome', 'Mitochondria', 'Golgi Apparatus', 'Lysosome'],
          correctOptionIndex: 1,
          explanation: 'Mitochondria produce ATP through oxidative phosphorylation, hence known as the powerhouse.',
          marks: 4,
        },
        {
          id: 'Q2',
          question: 'The Calvin cycle takes place in which part of the chloroplast?',
          options: ['Thylakoid membrane', 'Grana', 'Stroma', 'Outer membrane'],
          correctOptionIndex: 2,
          explanation: 'The light-independent reactions (Calvin cycle) take place in the stroma of chloroplasts.',
          marks: 4,
        },
        {
          id: 'Q3',
          question: 'Which enzyme is responsible for unwinding the DNA double helix during replication?',
          options: ['DNA Polymerase', 'Helicase', 'Ligase', 'Topoisomerase'],
          correctOptionIndex: 1,
          explanation: 'Helicase breaks the hydrogen bonds between bases to unwind the DNA double helix.',
          marks: 4,
        },
        {
          id: 'Q4',
          question: 'During human cardiac cycle, ventricular systole lasts for approximately:',
          options: ['0.1 second', '0.3 second', '0.4 second', '0.8 second'],
          correctOptionIndex: 1,
          explanation: 'In a cardiac cycle of 0.8s, ventricular systole lasts approximately 0.3s and diastole 0.5s.',
          marks: 4,
        },
        {
          id: 'Q5',
          question: 'Which hormone is secreted by the beta cells of islets of Langerhans in the pancreas?',
          options: ['Glucagon', 'Insulin', 'Somatostatin', 'Epinephrine'],
          correctOptionIndex: 1,
          explanation: 'Beta cells produce Insulin, while Alpha cells produce Glucagon.',
          marks: 4,
        },
      ],
    },
    {
      id: 'MCQ-002',
      title: 'ETEA Engineering Physics Practice Test',
      classId: 'CLS-11',
      className: '11th',
      subject: 'Physics',
      durationMinutes: 15,
      totalMarks: 20,
      status: 'active',
      createdAt: '2026-10-02T10:00:00Z',
      questions: [
        {
          id: 'Q201',
          question: 'The dimensions of Planck’s constant are equivalent to the dimensions of:',
          options: ['Energy', 'Linear Momentum', 'Angular Momentum', 'Power'],
          correctOptionIndex: 2,
          explanation: 'Planck constant (J·s) has dimensions [ML²T⁻¹], identical to angular momentum (mvr).',
          marks: 4,
        },
        {
          id: 'Q202',
          question: 'A projectile is fired at 45 degrees. Its range is maximum and equals:',
          options: ['vi² / g', 'vi² / 2g', '2 vi² / g', 'vi² / 4g'],
          correctOptionIndex: 0,
          explanation: 'At theta = 45 deg, sin(2 theta) = 1, giving R_max = vi² / g.',
          marks: 4,
        },
        {
          id: 'Q203',
          question: 'Work done by a centripetal force on an object in uniform circular motion is always:',
          options: ['Positive', 'Negative', 'Zero', 'Dependent on radius'],
          correctOptionIndex: 2,
          explanation: 'Force is perpendicular to displacement (angle = 90 deg, cos 90 = 0), so work done is zero.',
          marks: 4,
        },
        {
          id: 'Q204',
          question: 'Escape velocity from the surface of the Earth is approximately:',
          options: ['7.9 km/s', '11.2 km/s', '9.8 km/s', '14.2 km/s'],
          correctOptionIndex: 1,
          explanation: 'Earth escape velocity is sqrt(2gR) ~= 11.2 km/s.',
          marks: 4,
        },
        {
          id: 'Q205',
          question: 'In Simple Harmonic Motion (SHM), the acceleration of the particle is directly proportional to:',
          options: ['Velocity', 'Square of displacement', 'Displacement from mean position', 'Frequency'],
          correctOptionIndex: 2,
          explanation: 'a = - omega² * x, directly proportional to displacement with opposite sign.',
          marks: 4,
        },
      ],
    },
  ];

  const mcqAttempts: McqAttempt[] = [
    {
      id: 'ATM-001',
      testId: 'MCQ-001',
      testTitle: 'ETEA / MDCAT Biology Practice Test 1',
      studentId: 'ETA-2026-013',
      studentName: 'Saad Ali',
      rollNo: '01',
      score: 20,
      totalMarks: 20,
      percentage: 100,
      answers: [
        { questionId: 'Q1', selectedOptionIndex: 1, isCorrect: true },
        { questionId: 'Q2', selectedOptionIndex: 2, isCorrect: true },
        { questionId: 'Q3', selectedOptionIndex: 1, isCorrect: true },
        { questionId: 'Q4', selectedOptionIndex: 1, isCorrect: true },
        { questionId: 'Q5', selectedOptionIndex: 1, isCorrect: true },
      ],
      submittedAt: '2026-10-12T14:30:00Z',
    },
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'LOG-001',
      timestamp: '2026-10-14T08:00:00Z',
      userId: 'USR-01',
      userName: 'Mr. Rahmat Ali',
      action: 'SYSTEM_BOOT',
      module: 'Core',
      details: 'Academy management database initialized for academic session 2026-2027.',
    },
    {
      id: 'LOG-002',
      timestamp: '2026-10-14T08:30:00Z',
      userId: 'USR-05',
      userName: 'Tariq Mehmood',
      action: 'ATTENDANCE_RECORDED',
      module: 'Attendance',
      details: 'Daily attendance submitted for classes 6th through 12th.',
    },
    {
      id: 'LOG-003',
      timestamp: '2026-10-14T08:45:00Z',
      userId: 'USR-04',
      userName: 'Muhammad Farooq',
      action: 'FEE_PAYMENT_COLLECTED',
      module: 'Fees',
      details: 'Payment recorded for Saad Ali (Rs. 4,000 via Bank Transfer).',
    },
  ];

  const settings: AcademySettings = {
    name: 'The Excellent Tuition Academy Khwazakhela',
    shortName: 'ETA',
    principal: 'Mr. Rahmat Ali',
    location: 'Khwazakhela, Mata Road, Swat, Khyber Pakhtunkhwa, Pakistan',
    phone: '0345-6898969',
    whatsappNumber: '923456898969',
    whatsappLink: 'https://wa.me/923456898969',
    mapLink: 'https://www.google.com/maps?q=Khwazakhela+Mata+Road+Swat+KPK',
    currency: 'Rs. PKR',
    academicSession: '2026-2027',
    tagline: 'Quality Education | Brighter Future | Better Tomorrow',
  };

  return {
    users,
    teachers,
    classes,
    students,
    feeInvoices,
    feePayments,
    attendanceRecords,
    tests,
    mcqTests,
    mcqAttempts,
    auditLogs,
    settings,
  };
}
