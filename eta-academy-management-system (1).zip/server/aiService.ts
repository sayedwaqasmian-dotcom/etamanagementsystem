import { GoogleGenAI } from '@google/genai';
import { db } from './db.ts';

export interface ProposedAction {
  id: string;
  type: 'ADD_STUDENT' | 'RECORD_FEE_PAYMENT' | 'MARK_ATTENDANCE' | 'SCHEDULE_TEST' | 'NAVIGATE' | 'NONE';
  title: string;
  description: string;
  requiresConfirmation: boolean;
  params: Record<string, any>;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface AssistantResponse {
  reply: string;
  proposedAction?: ProposedAction | null;
  mode: 'GEMINI_AI' | 'LOCAL_RULE_BASED';
}

let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

export async function processAssistantMessage(
  userMessage: string,
  userRole: string,
  userName: string
): Promise<AssistantResponse> {
  const d = db.getData();

  // Summary context for AI (sanitized, no passwords/hashes)
  const contextSummary = {
    academy: d.settings.name,
    location: d.settings.location,
    principal: d.settings.principal,
    totalStudents: d.students.filter((s) => s.status === 'active').length,
    studentsList: d.students
      .filter((s) => s.status === 'active')
      .map((s) => ({ id: s.id, name: s.name, class: s.className, rollNo: s.rollNo, fee: s.monthlyFeePKR })),
    teachers: d.teachers.map((t) => ({ id: t.id, name: t.name, subjects: t.subjects, classes: t.assignedClasses })),
    totalInvoices: d.feeInvoices.length,
    totalCollectedPKR: d.feePayments.reduce((acc, p) => acc + p.amountPKR, 0),
    pendingInvoices: d.feeInvoices
      .filter((i) => i.balancePKR > 0)
      .map((i) => ({ invoice: i.invoiceNo, student: i.studentName, class: i.className, balance: i.balancePKR })),
    recentTests: d.tests.map((t) => ({ title: t.title, class: t.className, subject: t.subject, date: t.date })),
  };

  const ai = getGeminiClient();

  if (ai) {
    try {
      const systemInstruction = `You are "ETA Smart Assistant", the intelligent academy assistant for The Excellent Tuition Academy Khwazakhela (ETA), Swat, Pakistan.
Principal: Mr. Rahmat Ali.
Current staff user talking to you: ${userName} (Role: ${userRole}).

You understand both English and Roman Urdu fluently.
Examples:
- "Ahmad ko class 7 mein add kar do" -> understand student addition intent
- "Is mahine kitni fees collect hui?" -> fee collection query
- "Pending fees walay students ki list dikhao" -> pending fees list
- "Aaj class 6 ki attendance dikhao" -> attendance query

CRITICAL SECURITY RULES:
1. Always enforce role permissions:
   - "principal" has full access to all records, reports, staff salaries, and operations.
   - "admin" can manage students, classes, attendance, exams.
   - "teacher" can view assigned classes, enter marks, mark attendance.
   - "accountant" can view and manage fees, payments, balances.
   - "attendance_operator" can mark and view attendance only.
   If user lacks permission for a task, politely explain in English or Roman Urdu based on their query language.
2. If the user asks to create, modify, record a payment, or add a student, you MUST return a structured ProposedAction in JSON format with "requiresConfirmation: true" and specify parameters.
3. NEVER execute changes without asking the user to confirm the preview.
4. Always quote Pakistani Rupees (Rs. PKR).
5. Output your response as a valid JSON object matching this schema:
{
  "reply": "Your conversational response in the requested language (English or Roman Urdu)",
  "proposedAction": {
    "type": "ADD_STUDENT" | "RECORD_FEE_PAYMENT" | "MARK_ATTENDANCE" | "SCHEDULE_TEST" | "NAVIGATE" | "NONE",
    "title": "Short title of action",
    "description": "Clear explanation of what will be performed upon user confirmation",
    "requiresConfirmation": boolean,
    "params": { ... action details ... },
    "riskLevel": "LOW" | "MEDIUM" | "HIGH"
  } or null
}`;

      const prompt = `Academy Database Context:
${JSON.stringify(contextSummary, null, 2)}

User request: "${userMessage}"
Remember to return ONLY a JSON response without codeblock markdown wrappers if possible, or valid JSON parseable.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
        },
      });

      const text = response.text?.trim() || '';
      try {
        const parsed = JSON.parse(text);
        return {
          reply: parsed.reply || text,
          proposedAction: parsed.proposedAction || null,
          mode: 'GEMINI_AI',
        };
      } catch (e) {
        return {
          reply: text,
          proposedAction: null,
          mode: 'GEMINI_AI',
        };
      }
    } catch (err: any) {
      console.error('Gemini API call failed, falling back to local engine:', err?.message);
    }
  }

  // Graceful Fallback: Local Rule-Based Engine
  return processLocalAssistantMessage(userMessage, userRole, userName, d);
}

function processLocalAssistantMessage(
  msg: string,
  userRole: string,
  userName: string,
  data: ReturnType<typeof db.getData>
): AssistantResponse {
  const text = msg.toLowerCase().trim();

  // 1. Fee collection query
  if (text.includes('fee') || text.includes('fees') || text.includes('kitni fees') || text.includes('collection')) {
    const totalCollected = data.feePayments.reduce((sum, p) => sum + p.amountPKR, 0);
    const pendingTotal = data.feeInvoices.reduce((sum, i) => sum + i.balancePKR, 0);

    if (text.includes('pending') || text.includes('outstanding') || text.includes('baqi')) {
      const pendingList = data.feeInvoices
        .filter((i) => i.balancePKR > 0)
        .map((i) => `• ${i.studentName} (${i.className}): Rs. ${i.balancePKR.toLocaleString()} (${i.status})`)
        .slice(0, 6)
        .join('\n');

      return {
        reply: `Here is the current pending fees summary:\nTotal outstanding: Rs. ${pendingTotal.toLocaleString()} PKR across ${
          data.feeInvoices.filter((i) => i.balancePKR > 0).length
        } students.\n\n${pendingList}\n\nWould you like to open Fee Management or send WhatsApp reminders?`,
        proposedAction: {
          id: `ACT-${Date.now()}`,
          type: 'NAVIGATE',
          title: 'Open Fee Management',
          description: 'Navigate to the Fee Management section to view full invoices and send WhatsApp reminders.',
          requiresConfirmation: false,
          params: { route: '/fees' },
          riskLevel: 'LOW',
        },
        mode: 'LOCAL_RULE_BASED',
      };
    }

    return {
      reply: `Fee Summary for ETA Academy:\n• Total Collected this month: Rs. ${totalCollected.toLocaleString()} PKR\n• Total Outstanding balance: Rs. ${pendingTotal.toLocaleString()} PKR\n• Total Invoices: ${data.feeInvoices.length}\n• Currency: Pakistani Rupees (Rs. PKR)`,
      proposedAction: {
        id: `ACT-${Date.now()}`,
        type: 'NAVIGATE',
        title: 'View Fee Reports',
        description: 'Navigate to Fee section to view detailed invoices and print receipts.',
        requiresConfirmation: false,
        params: { route: '/fees' },
        riskLevel: 'LOW',
      },
      mode: 'LOCAL_RULE_BASED',
    };
  }

  // 2. Attendance Query
  if (text.includes('attendance') || text.includes('hazri') || text.includes('absent') || text.includes('present')) {
    const todayAtt = data.attendanceRecords.filter((a) => a.date === '2026-10-14' || a.date === new Date().toISOString().split('T')[0]);
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalLate = 0;
    let totalLeave = 0;

    todayAtt.forEach((session) => {
      session.records.forEach((r) => {
        if (r.status === 'present') totalPresent++;
        if (r.status === 'absent') totalAbsent++;
        if (r.status === 'late') totalLate++;
        if (r.status === 'leave') totalLeave++;
      });
    });

    const totalStudents = totalPresent + totalAbsent + totalLate + totalLeave || data.students.length;
    const pct = totalStudents > 0 ? Math.round((totalPresent / totalStudents) * 100) : 0;

    return {
      reply: `Today's Attendance Overview for ETA Academy:\n• Present: ${totalPresent}\n• Absent: ${totalAbsent}\n• Late: ${totalLate}\n• On Leave: ${totalLeave}\n• Overall Attendance Rate: ${pct}%\n\nYou can review class-wise attendance or generate parent WhatsApp messages in Attendance module.`,
      proposedAction: {
        id: `ACT-${Date.now()}`,
        type: 'NAVIGATE',
        title: 'Open Attendance Module',
        description: 'Go to Attendance sheet to mark or view class records.',
        requiresConfirmation: false,
        params: { route: '/attendance' },
        riskLevel: 'LOW',
      },
      mode: 'LOCAL_RULE_BASED',
    };
  }

  // 3. Add Student intent (Roman Urdu or English)
  if (text.includes('add') && (text.includes('student') || text.includes('ko add') || text.includes('dakhila') || text.includes('admission'))) {
    // Check permission
    if (userRole === 'attendance_operator') {
      return {
        reply: `Permission notice: As an Attendance Operator, you do not have permission to register new students. Please contact the Principal or Administrator.`,
        mode: 'LOCAL_RULE_BASED',
      };
    }

    // Extract potential name and class
    let studentName = 'New Student';
    let className = '7th';
    const classMatch = text.match(/class\s*(\d+|6th|7th|8th|9th|10th|11th|12th)/i);
    if (classMatch) {
      className = classMatch[1].toLowerCase().endsWith('th') ? classMatch[1] : `${classMatch[1]}th`;
    }

    const words = msg.split(' ');
    if (words.length >= 2) {
      studentName = words[0];
    }

    return {
      reply: `Proposal to add student: I have prepared an admission draft for **${studentName}** in Class **${className}**.\n\nPlease review the details below and confirm to save in database.`,
      proposedAction: {
        id: `ACT-${Date.now()}`,
        type: 'ADD_STUDENT',
        title: `Register New Student: ${studentName}`,
        description: `Enroll ${studentName} into Class ${className} with default monthly fee in PKR.`,
        requiresConfirmation: true,
        params: {
          name: studentName,
          className: className,
          fatherName: 'Guardian Name',
          section: 'A',
          monthlyFeePKR: className === '9th' || className === '10th' ? 3500 : className === '11th' || className === '12th' ? 4500 : 2500,
        },
        riskLevel: 'MEDIUM',
      },
      mode: 'LOCAL_RULE_BASED',
    };
  }

  // 4. Record fee payment intent
  if (text.includes('record') || text.includes('jama') || text.includes('payment') || text.includes('reciept')) {
    const amountMatch = text.match(/\d+/);
    const amount = amountMatch ? parseInt(amountMatch[0], 10) : 2500;

    return {
      reply: `Payment Draft:\nPrepared payment entry for Rs. ${amount.toLocaleString()} PKR.\nPlease select student and confirm to record receipt and update ledger.`,
      proposedAction: {
        id: `ACT-${Date.now()}`,
        type: 'RECORD_FEE_PAYMENT',
        title: `Record Fee Payment of Rs. ${amount.toLocaleString()} PKR`,
        description: `Create receipt for Rs. ${amount.toLocaleString()} PKR and adjust outstanding invoice.`,
        requiresConfirmation: true,
        params: {
          amountPKR: amount,
          paymentMethod: 'Cash',
          studentId: 'ETA-2026-003',
          studentName: 'Bilal Khan (7th)',
        },
        riskLevel: 'HIGH',
      },
      mode: 'LOCAL_RULE_BASED',
    };
  }

  // 5. Search / student list
  if (text.includes('search') || text.includes('talib ilm') || text.includes('students') || text.includes('class 7') || text.includes('class 8')) {
    const activeStudents = data.students.filter((s) => s.status === 'active');
    const previewList = activeStudents
      .slice(0, 5)
      .map((s) => `• ${s.name} (${s.className} - Roll #${s.rollNo}) - Fee: Rs. ${s.monthlyFeePKR}`)
      .join('\n');

    return {
      reply: `Found ${activeStudents.length} active students in ETA Academy.\n\nSample Records:\n${previewList}\n\nYou can search specific records or export CSV in Student Management.`,
      proposedAction: {
        id: `ACT-${Date.now()}`,
        type: 'NAVIGATE',
        title: 'Open Student Directory',
        description: 'View full student directory with filters, search, and printable ID cards.',
        requiresConfirmation: false,
        params: { route: '/students' },
        riskLevel: 'LOW',
      },
      mode: 'LOCAL_RULE_BASED',
    };
  }

  // Default response
  return {
    reply: `Assalam-o-Alaikum ${userName}! I am **ETA Smart Assistant** for The Excellent Tuition Academy Khwazakhela, Swat.\n\nI can help you:\n• Check live attendance & calculate daily percentages\n• Query fees collected in PKR and view outstanding balances\n• Search students across classes 6th to 12th\n• Draft new admissions with confirmation previews\n• Prepare fee receipts & test summaries\n• Understand English & Roman Urdu commands\n\nHow may I assist you today?`,
    mode: 'LOCAL_RULE_BASED',
  };
}
