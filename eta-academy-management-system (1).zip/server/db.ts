import fs from 'fs';
import path from 'path';
import {
  AcademySettings,
  AttendanceRecord,
  AuditLog,
  ClassItem,
  ExamTest,
  FeeInvoice,
  FeePayment,
  getInitialDatabaseData,
  McqAttempt,
  McqTest,
  Student,
  Teacher,
  User,
} from './seedData.ts';

export interface DatabaseSchema {
  users: User[];
  teachers: Teacher[];
  classes: ClassItem[];
  students: Student[];
  feeInvoices: FeeInvoice[];
  feePayments: FeePayment[];
  attendanceRecords: AttendanceRecord[];
  tests: ExamTest[];
  mcqTests: McqTest[];
  mcqAttempts: McqAttempt[];
  auditLogs: AuditLog[];
  settings: AcademySettings;
}

class DatabaseManager {
  private dbPath: string;
  private data: DatabaseSchema;
  private isSaving = false;

  constructor() {
    const dataDir = path.resolve('data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.dbPath = path.join(dataDir, 'eta_database.json');
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(this.dbPath)) {
        const fileContent = fs.readFileSync(this.dbPath, 'utf-8');
        const parsed = JSON.parse(fileContent);
        // Ensure all top-level keys exist
        const initial = getInitialDatabaseData();
        return {
          ...initial,
          ...parsed,
          settings: { ...initial.settings, ...(parsed.settings || {}) },
        };
      }
    } catch (err) {
      console.error('Error loading database file, falling back to seed data:', err);
    }
    const initial = getInitialDatabaseData();
    this.saveDirect(initial);
    return initial;
  }

  private saveDirect(dataToSave: DatabaseSchema) {
    try {
      const tempPath = `${this.dbPath}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tempPath, this.dbPath);
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public save() {
    this.saveDirect(this.data);
  }

  public getData(): DatabaseSchema {
    return this.data;
  }

  public resetToDefault() {
    this.data = getInitialDatabaseData();
    this.save();
    return this.data;
  }

  public restoreFromJson(jsonData: DatabaseSchema) {
    this.data = jsonData;
    this.save();
    return this.data;
  }

  public logAction(userId: string, userName: string, action: string, module: string, details: string) {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      userId,
      userName,
      action,
      module,
      details,
    };
    this.data.auditLogs.unshift(newLog);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs.pop();
    }
    this.save();
  }
}

export const db = new DatabaseManager();
