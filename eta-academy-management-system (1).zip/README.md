# THE EXCELLENT TUITION ACADEMY KHWAZAKHELA (ETA)
## Academy Management Web Application & Progressive Web App (PWA)

**Location:** Khwazakhela, Mata Road, Swat, Khyber Pakhtunkhwa, Pakistan  
**Principal and Founder:** Mr. Rahmat Ali  
**Official Phone:** 0345-6898969  
**WhatsApp:** [https://wa.me/923456898969](https://wa.me/923456898969)  
**Academic Classes:** 6th, 7th, 8th, 9th, 10th, 11th, and 12th  
**Standard Currency:** Pakistani Rupees (Rs. PKR)  
**Motto:** Quality Education | Brighter Future | Better Tomorrow  

---

## 🚀 Key Features

1. **Role-Based Access Control (RBAC):**
   - **Principal / Super Admin (Mr. Rahmat Ali):** Unrestricted access to all modules, financial payroll, audit logs, and settings.
   - **Administrator:** Full student enrollment, class management, timetable assignments, and reports.
   - **Teacher (Mr. Nouman Khan & faculty):** Assigned classes, attendance marking, mark sheets, and result cards.
   - **Accountant (Muhammad Farooq):** PKR fee invoices, partial/full payments, printable receipts, and financial reports.
   - **Attendance Operator (Tariq Mehmood):** Daily attendance registers and parent absence alerts.
   - *Quick Role Switcher:* Integrated in the sidebar for instant verification of permissions.

2. **Student Management Module:**
   - Unique auto-increment IDs (`ETA-2026-001`, `ETA-2026-002`, etc.).
   - Full student profiles with academic history, fee ledgers, exam results, and attendance records.
   - Search by name, roll number, class, or guardian phone.
   - Import and export authorized student records to CSV.
   - Printable official Student ID Cards with barcode and photo frame.

3. **Fee Management (PKR ONLY):**
   - Monthly fee invoicing for all classes (6th to 12th).
   - Support for full and partial payments, scholarships, and fee concessions.
   - Payment methods: Cash, Bank Transfer, EasyPaisa, and JazzCash.
   - Printable Official Fee Receipts with ETA institutional letterhead and signatures.
   - One-click WhatsApp payment reminders with pre-filled Urdu/English templates.

4. **Student Attendance:**
   - Daily attendance system for Classes 6th to 12th.
   - Mark Present, Absent, Late, or Leave with batch "Mark All Present" shortcut.
   - Automatic calculation of daily and monthly attendance percentages.
   - Instant WhatsApp absence notification generator for parents.
   - Printable daily attendance sheets.

5. **Tests, Exams & Academic Results:**
   - Monthly assessments, mid-terms, and pre-board mock examinations.
   - Mark entry with automatic percentage and grade calculation (A-1, A, B, C, D, F).
   - Printable Student Result Cards and class marksheets.

6. **ETEA Practice Test Simulator:**
   - MDCAT and Engineering entry test preparation module.
   - Real-time countdown timer with question palette navigation.
   - Marked-for-review capability and one-time final submission protection.
   - Immediate score calculation with detailed question explanations.

7. **ETA Smart Assistant (AI Academy Copilot):**
   - Understands both **English** and **Roman Urdu** queries (e.g., *"Is mahine kitni fees collect hui?"*, *"Pending fees walay students ki list dikhao"*, *"Ahmad ko class 7 mein add kar do"*).
   - Powered by `@google/genai` (model: `gemini-3.8-flash`) server-side when `GEMINI_API_KEY` is provided, with graceful local rule-based intent fallback.
   - **Safe Action Preview:** Shows a structured confirmation card before executing student additions or financial entries.

8. **Progressive Web App (PWA):**
   - Compliant `manifest.json` and service worker with offline caching.
   - High-contrast 192x192, 512x512, and maskable app icons.
   - In-app "Install App" button with native Chromium prompt and iOS Safari instructions.
   - Non-intrusive offline connectivity status indicator.

9. **Data Persistence & Backups:**
   - Server-side persistent storage in `data/eta_database.json` with atomic disk writes.
   - One-click full database JSON export (backup) and import (restore) in Academy Settings.
   - Comprehensive audit trail recording all major actions.

---

## 🔑 Default Credentials for Evaluation

| Role | Username | Password | Full Name |
|---|---|---|---|
| **Principal** | `principal` | `eta12345` | Mr. Rahmat Ali |
| **Administrator** | `admin` | `eta12345` | Admin Desk |
| **Teacher** | `teacher` | `eta12345` | Mr. Nouman Khan |
| **Accountant** | `accountant` | `eta12345` | Muhammad Farooq |
| **Attendance Operator** | `operator` | `eta12345` | Tariq Mehmood |

*(Users can also switch roles on the fly using the sidebar selector).*

---

## 💻 Installation & Local Setup

```bash
# 1. Clone or extract project
cd eta-academy

# 2. Install dependencies
npm install

# 3. Configure environment variables (.env)
cp .env.example .env
# Add GEMINI_API_KEY if desired for AI capabilities

# 4. Start full-stack development server
npm run dev
# The Express server + Vite SPA will launch on http://localhost:3000
```
