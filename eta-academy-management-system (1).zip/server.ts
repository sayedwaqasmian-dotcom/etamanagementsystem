import dotenv from 'dotenv';
dotenv.config();

import express, { Request, Response } from 'express';
import path from 'path';
import { db } from './server/db.ts';
import { hashPassword, Student, FeeInvoice, FeePayment, AttendanceRecord, ExamTest, McqTest, McqAttempt, Teacher } from './server/seedData.ts';
import { processAssistantMessage } from './server/aiService.ts';

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Request logging middleware
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// Helper for authentication check
function getUserFromHeader(req: Request) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace('Bearer ', '').trim();
  const d = db.getData();
  const user = d.users.find((u) => u.id === token || u.username === token);
  return user || null;
}

// -------------------------------------------------------------
// 1. AUTHENTICATION & USERS
// -------------------------------------------------------------
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const d = db.getData();
  const hashedInput = hashPassword(password);
  const user = d.users.find(
    (u) => (u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === username.toLowerCase()) && u.passwordHash === hashedInput
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials. Please check username or password.' });
  }

  db.logAction(user.id, user.name, 'USER_LOGIN', 'Auth', `User logged in with role: ${user.role}`);

  const { passwordHash, ...safeUser } = user;
  return res.json({
    user: safeUser,
    token: user.id, // For this demo full-stack app, ID acts as verified session token
  });
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const user = getUserFromHeader(req);
  if (!user) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser });
});

app.post('/api/auth/change-password', (req: Request, res: Response) => {
  const user = getUserFromHeader(req);
  if (!user) return res.status(401).json({ error: 'Not authenticated.' });

  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
  }

  if (user.passwordHash !== hashPassword(currentPassword)) {
    return res.status(400).json({ error: 'Current password does not match.' });
  }

  user.passwordHash = hashPassword(newPassword);
  db.save();
  db.logAction(user.id, user.name, 'PASSWORD_CHANGED', 'Auth', 'User changed their password.');

  res.json({ success: true, message: 'Password updated successfully.' });
});

// -------------------------------------------------------------
// 2. DASHBOARD LIVE STATS
// -------------------------------------------------------------
app.get('/api/dashboard/stats', (req: Request, res: Response) => {
  const d = db.getData();
  const activeStudents = d.students.filter((s) => s.status === 'active');

  // Class-wise count
  const classBreakdown: Record<string, number> = {};
  d.classes.forEach((c) => {
    classBreakdown[c.name] = activeStudents.filter((s) => s.classId === c.id || s.className === c.name).length;
  });

  // Today's attendance
  const today = new Date().toISOString().split('T')[0];
  const todaySessions = d.attendanceRecords.filter((a) => a.date === today || a.date === '2026-10-14');
  let todayPresent = 0;
  let todayAbsent = 0;
  let todayLate = 0;
  let todayLeave = 0;

  todaySessions.forEach((sess) => {
    sess.records.forEach((r) => {
      if (r.status === 'present') todayPresent++;
      else if (r.status === 'absent') todayAbsent++;
      else if (r.status === 'late') todayLate++;
      else if (r.status === 'leave') todayLeave++;
    });
  });

  const totalMarked = todayPresent + todayAbsent + todayLate + todayLeave;
  const attendanceRate = totalMarked > 0 ? Math.round((todayPresent / totalMarked) * 100) : 92;

  // Fee metrics
  const totalFeesInvoiced = d.feeInvoices.reduce((sum, inv) => sum + inv.netAmountPKR, 0);
  const totalFeesCollected = d.feePayments.reduce((sum, pay) => sum + pay.amountPKR, 0);
  const totalOutstanding = d.feeInvoices.reduce((sum, inv) => sum + inv.balancePKR, 0);

  // Recent admissions
  const recentStudents = [...d.students].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  // Recent fee payments
  const recentPayments = [...d.feePayments].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  // Recent tests
  const recentTests = [...d.tests].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 4);

  res.json({
    totalActiveStudents: activeStudents.length,
    totalStaff: d.teachers.filter((t) => t.status === 'active').length,
    classBreakdown,
    todayAttendance: {
      present: todayPresent,
      absent: todayAbsent,
      late: todayLate,
      leave: todayLeave,
      percentage: attendanceRate,
    },
    fees: {
      invoicedPKR: totalFeesInvoiced,
      collectedPKR: totalFeesCollected,
      outstandingPKR: totalOutstanding,
      currency: 'Rs. PKR',
    },
    recentStudents,
    recentPayments,
    recentTests,
    activeExamsCount: d.tests.length + d.mcqTests.length,
  });
});

// -------------------------------------------------------------
// 3. STUDENT MANAGEMENT
// -------------------------------------------------------------
app.get('/api/students', (req: Request, res: Response) => {
  const d = db.getData();
  const search = (req.query.search as string || '').toLowerCase().trim();
  const classFilter = (req.query.classId as string || '').trim();
  const statusFilter = (req.query.status as string || '').trim();

  let filtered = d.students.filter((s) => {
    if (classFilter && s.classId !== classFilter && s.className !== classFilter) return false;
    if (statusFilter && s.status !== statusFilter) return false;
    if (search) {
      const matchName = s.name.toLowerCase().includes(search);
      const matchFather = s.fatherName.toLowerCase().includes(search);
      const matchRoll = s.rollNo.toLowerCase().includes(search);
      const matchId = s.id.toLowerCase().includes(search);
      const matchPhone = s.guardianPhone.includes(search) || s.studentPhone.includes(search);
      return matchName || matchFather || matchRoll || matchId || matchPhone;
    }
    return true;
  });

  res.json({ students: filtered });
});

app.get('/api/students/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const student = d.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  // Student's full fee invoices & payments
  const invoices = d.feeInvoices.filter((i) => i.studentId === student.id);
  const payments = d.feePayments.filter((p) => p.studentId === student.id);

  // Student's attendance records
  const attendanceSessions = d.attendanceRecords
    .map((sess) => {
      const rec = sess.records.find((r) => r.studentId === student.id);
      if (rec) {
        return {
          date: sess.date,
          status: rec.status,
          remarks: rec.remarks || '',
          recordedBy: sess.recordedBy,
        };
      }
      return null;
    })
    .filter(Boolean);

  // Student's test results
  const testResults = d.tests
    .map((t) => {
      const resItem = t.results.find((r) => r.studentId === student.id);
      if (resItem) {
        return {
          testId: t.id,
          testTitle: t.title,
          subject: t.subject,
          date: t.date,
          totalMarks: t.totalMarks,
          marksObtained: resItem.marksObtained,
          percentage: Math.round((resItem.marksObtained / t.totalMarks) * 100),
          remarks: resItem.remarks,
        };
      }
      return null;
    })
    .filter(Boolean);

  // MCQ attempts
  const mcqAttempts = d.mcqAttempts.filter((a) => a.studentId === student.id);

  res.json({
    student,
    invoices,
    payments,
    attendance: attendanceSessions,
    testResults,
    mcqAttempts,
  });
});

app.post('/api/students', (req: Request, res: Response) => {
  const d = db.getData();
  const {
    name,
    fatherName,
    classId,
    className,
    section = 'A',
    rollNo,
    admissionDate = new Date().toISOString().split('T')[0],
    dob = '',
    gender = 'Male',
    studentPhone = '',
    guardianPhone = '0345-6898969',
    address = 'Khwazakhela, Swat',
    previousSchool = '',
    monthlyFeePKR = 2500,
    discountPKR = 0,
    status = 'active',
    notes = '',
    avatar = '',
  } = req.body;

  if (!name || !fatherName || !className) {
    return res.status(400).json({ error: 'Student name, father name, and class are required.' });
  }

  // Generate unique student ID
  const count = d.students.length + 1;
  const studentId = `ETA-2026-${String(count).padStart(3, '0')}`;

  const resolvedClassId = classId || d.classes.find((c) => c.name === className)?.id || 'CLS-06';
  const autoRollNo = rollNo || String(d.students.filter((s) => s.className === className).length + 1).padStart(2, '0');

  const newStudent: Student = {
    id: studentId,
    name,
    fatherName,
    classId: resolvedClassId,
    className,
    section,
    rollNo: autoRollNo,
    admissionDate,
    dob,
    gender,
    studentPhone,
    guardianPhone,
    address,
    previousSchool,
    monthlyFeePKR: Number(monthlyFeePKR),
    discountPKR: Number(discountPKR),
    status,
    notes,
    avatar,
    createdAt: new Date().toISOString(),
  };

  d.students.push(newStudent);

  // Automatically generate current month's invoice
  const currentMonth = 'October 2026';
  const netAmount = Math.max(0, Number(monthlyFeePKR) - Number(discountPKR));
  const newInvoice: FeeInvoice = {
    id: `INV-2026-10-${String(d.feeInvoices.length + 1).padStart(3, '0')}`,
    invoiceNo: `ETA-INV-${1000 + d.feeInvoices.length + 1}`,
    studentId: newStudent.id,
    studentName: newStudent.name,
    classId: resolvedClassId,
    className: newStudent.className,
    month: currentMonth,
    year: 2026,
    dueDate: '2026-10-10',
    amountPKR: Number(monthlyFeePKR),
    discountPKR: Number(discountPKR),
    netAmountPKR: netAmount,
    paidAmountPKR: 0,
    balancePKR: netAmount,
    status: 'unpaid',
    createdAt: new Date().toISOString(),
  };
  d.feeInvoices.push(newInvoice);

  db.save();
  db.logAction('SYSTEM', 'Staff', 'STUDENT_CREATED', 'Students', `Admitted new student ${name} (ID: ${studentId}) in Class ${className}`);

  res.status(201).json({ student: newStudent, invoice: newInvoice });
});

app.put('/api/students/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const index = d.students.findIndex((s) => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Student not found.' });

  const updated = {
    ...d.students[index],
    ...req.body,
    id: d.students[index].id, // Prevent ID alteration
  };

  d.students[index] = updated;
  db.save();
  db.logAction('SYSTEM', 'Staff', 'STUDENT_UPDATED', 'Students', `Updated student profile for ${updated.name} (${updated.id})`);

  res.json({ student: updated });
});

app.post('/api/students/:id/archive', (req: Request, res: Response) => {
  const d = db.getData();
  const student = d.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  student.status = student.status === 'archived' ? 'active' : 'archived';
  db.save();
  db.logAction('SYSTEM', 'Staff', 'STUDENT_ARCHIVED', 'Students', `Toggled archive status for student ${student.name} (${student.id})`);

  res.json({ student, message: `Student status set to ${student.status}` });
});

app.delete('/api/students/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const index = d.students.findIndex((s) => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Student not found.' });

  const removed = d.students.splice(index, 1)[0];
  db.save();
  db.logAction('SYSTEM', 'Staff', 'STUDENT_DELETED', 'Students', `Deleted student record ${removed.name} (${removed.id})`);

  res.json({ success: true, message: 'Student removed successfully.' });
});

// CSV Import
app.post('/api/students/import-csv', (req: Request, res: Response) => {
  const { csvData } = req.body;
  if (!csvData || typeof csvData !== 'string') {
    return res.status(400).json({ error: 'Invalid CSV data.' });
  }

  const d = db.getData();
  const lines = csvData.trim().split('\n');
  if (lines.length <= 1) return res.status(400).json({ error: 'CSV file is empty or only has headers.' });

  const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
  let importedCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
    if (cols.length < 3) continue;

    const rowObj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      rowObj[h] = cols[idx] || '';
    });

    const name = rowObj['name'] || rowObj['student name'] || cols[0];
    const fatherName = rowObj['father name'] || rowObj['father'] || cols[1] || 'Guardian';
    const className = rowObj['class'] || cols[2] || '6th';

    if (name && fatherName) {
      const studentId = `ETA-2026-${String(d.students.length + 1).padStart(3, '0')}`;
      const newStudent: Student = {
        id: studentId,
        name,
        fatherName,
        classId: d.classes.find((c) => c.name === className)?.id || 'CLS-06',
        className,
        section: rowObj['section'] || 'A',
        rollNo: rowObj['roll'] || String(d.students.filter((s) => s.className === className).length + 1),
        admissionDate: new Date().toISOString().split('T')[0],
        dob: rowObj['dob'] || '',
        gender: (rowObj['gender'] as 'Male' | 'Female') || 'Male',
        studentPhone: rowObj['phone'] || '',
        guardianPhone: rowObj['guardian phone'] || '0345-6898969',
        address: rowObj['address'] || 'Khwazakhela, Swat',
        previousSchool: rowObj['previous school'] || '',
        monthlyFeePKR: Number(rowObj['fee'] || 2500),
        discountPKR: 0,
        status: 'active',
        notes: 'Imported via CSV',
        createdAt: new Date().toISOString(),
      };
      d.students.push(newStudent);
      importedCount++;
    }
  }

  db.save();
  db.logAction('SYSTEM', 'Staff', 'CSV_IMPORT', 'Students', `Imported ${importedCount} students from CSV.`);
  res.json({ success: true, count: importedCount, message: `Successfully imported ${importedCount} students.` });
});

// CSV Export
app.get('/api/students/export-csv', (req: Request, res: Response) => {
  const d = db.getData();
  const headers = ['ID', 'Name', 'Father Name', 'Class', 'Section', 'Roll No', 'Admission Date', 'Phone', 'Guardian Phone', 'Address', 'Monthly Fee PKR', 'Status'];
  const rows = d.students.map((s) => [
    s.id,
    `"${s.name}"`,
    `"${s.fatherName}"`,
    s.className,
    s.section,
    s.rollNo,
    s.admissionDate,
    s.studentPhone,
    s.guardianPhone,
    `"${s.address}"`,
    s.monthlyFeePKR,
    s.status,
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="ETA_Students_List.csv"');
  res.send(csvContent);
});

// -------------------------------------------------------------
// 4. CLASSES & SECTIONS
// -------------------------------------------------------------
app.get('/api/classes', (req: Request, res: Response) => {
  const d = db.getData();
  const classesWithMeta = d.classes.map((cls) => {
    const studentCount = d.students.filter((s) => (s.classId === cls.id || s.className === cls.name) && s.status === 'active').length;
    return {
      ...cls,
      studentCount,
    };
  });
  res.json({ classes: classesWithMeta });
});

app.put('/api/classes/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const index = d.classes.findIndex((c) => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Class not found.' });

  d.classes[index] = { ...d.classes[index], ...req.body };
  db.save();
  res.json({ class: d.classes[index] });
});

// Class Promotion Workflow (preserves history)
app.post('/api/classes/promote', (req: Request, res: Response) => {
  const { fromClassId, toClassId, studentIds } = req.body;
  if (!fromClassId || !toClassId || !Array.isArray(studentIds) || studentIds.length === 0) {
    return res.status(400).json({ error: 'Source class, destination class, and student IDs are required.' });
  }

  const d = db.getData();
  const toClass = d.classes.find((c) => c.id === toClassId);
  if (!toClass) return res.status(404).json({ error: 'Target class not found.' });

  let promotedCount = 0;
  studentIds.forEach((id) => {
    const student = d.students.find((s) => s.id === id);
    if (student) {
      student.classId = toClass.id;
      student.className = toClass.name;
      student.monthlyFeePKR = toClass.monthlyFeePKR;
      promotedCount++;
    }
  });

  db.save();
  db.logAction('SYSTEM', 'Staff', 'CLASS_PROMOTION', 'Classes', `Promoted ${promotedCount} students to Class ${toClass.name}`);
  res.json({ success: true, count: promotedCount, message: `Successfully promoted ${promotedCount} students to Class ${toClass.name}.` });
});

// -------------------------------------------------------------
// 5. TEACHER & STAFF DIRECTORY
// -------------------------------------------------------------
app.get('/api/teachers', (req: Request, res: Response) => {
  const d = db.getData();
  res.json({ teachers: d.teachers });
});

app.post('/api/teachers', (req: Request, res: Response) => {
  const d = db.getData();
  const { name, gender = 'Male', qualification, subjects = [], assignedClasses = [], phone = '0345-6898969', monthlySalaryPKR = 35000, address = 'Khwazakhela, Swat', notes = '' } = req.body;

  if (!name || !qualification) {
    return res.status(400).json({ error: 'Teacher name and qualification are required.' });
  }

  const teacherId = `TCH-${String(d.teachers.length + 1).padStart(3, '0')}`;
  const newTeacher: Teacher = {
    id: teacherId,
    name,
    gender,
    qualification,
    subjects: Array.isArray(subjects) ? subjects : [subjects],
    assignedClasses: Array.isArray(assignedClasses) ? assignedClasses : [assignedClasses],
    phone,
    joiningDate: new Date().toISOString().split('T')[0],
    monthlySalaryPKR: Number(monthlySalaryPKR),
    status: 'active',
    address,
    notes,
  };

  d.teachers.push(newTeacher);
  db.save();
  db.logAction('SYSTEM', 'Staff', 'TEACHER_ADDED', 'Staff', `Added faculty member ${name} (${teacherId})`);
  res.status(201).json({ teacher: newTeacher });
});

app.put('/api/teachers/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const index = d.teachers.findIndex((t) => t.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Teacher not found.' });

  d.teachers[index] = { ...d.teachers[index], ...req.body };
  db.save();
  res.json({ teacher: d.teachers[index] });
});

// -------------------------------------------------------------
// 6. FEE MANAGEMENT (PKR ONLY)
// -------------------------------------------------------------
app.get('/api/fees/invoices', (req: Request, res: Response) => {
  const d = db.getData();
  const classFilter = (req.query.classId as string || '').trim();
  const statusFilter = (req.query.status as string || '').trim();
  const monthFilter = (req.query.month as string || '').trim();

  let invoices = d.feeInvoices.filter((inv) => {
    if (classFilter && inv.classId !== classFilter && inv.className !== classFilter) return false;
    if (statusFilter && inv.status !== statusFilter) return false;
    if (monthFilter && inv.month !== monthFilter) return false;
    return true;
  });

  res.json({ invoices });
});

app.get('/api/fees/payments', (req: Request, res: Response) => {
  const d = db.getData();
  res.json({ payments: d.feePayments });
});

app.post('/api/fees/pay', (req: Request, res: Response) => {
  const { invoiceId, amountPKR, paymentMethod = 'Cash', collectorName = 'Accountant', remarks = '' } = req.body;

  if (!invoiceId || !amountPKR || Number(amountPKR) <= 0) {
    return res.status(400).json({ error: 'Valid invoice ID and positive payment amount are required.' });
  }

  const d = db.getData();
  const invoice = d.feeInvoices.find((i) => i.id === invoiceId);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found.' });

  const payAmount = Number(amountPKR);
  if (payAmount > invoice.balancePKR) {
    return res.status(400).json({
      error: `Payment amount (Rs. ${payAmount}) exceeds invoice outstanding balance (Rs. ${invoice.balancePKR}).`,
    });
  }

  // Update invoice
  invoice.paidAmountPKR += payAmount;
  invoice.balancePKR = invoice.netAmountPKR - invoice.paidAmountPKR;
  if (invoice.balancePKR <= 0) {
    invoice.status = 'paid';
  } else {
    invoice.status = 'partial';
  }

  // Generate Receipt
  const receiptCount = d.feePayments.length + 1;
  const receiptNo = `ETA-REC-2026-${String(receiptCount).padStart(3, '0')}`;
  const payment: FeePayment = {
    id: `PAY-${Date.now()}`,
    receiptNo,
    invoiceId: invoice.id,
    studentId: invoice.studentId,
    studentName: invoice.studentName,
    amountPKR: payAmount,
    paymentMethod,
    paymentDate: new Date().toISOString().split('T')[0],
    collectorName,
    remarks,
    createdAt: new Date().toISOString(),
  };

  d.feePayments.unshift(payment);
  db.save();

  db.logAction(
    'ACCOUNTANT',
    collectorName,
    'FEE_PAYMENT_COLLECTED',
    'Fees',
    `Collected Rs. ${payAmount.toLocaleString()} PKR from ${invoice.studentName} (${invoice.className}) via ${paymentMethod}. Receipt: ${receiptNo}`
  );

  res.status(201).json({ success: true, payment, invoice });
});

// Bulk Invoice Generation for a new month
app.post('/api/fees/generate-monthly-invoices', (req: Request, res: Response) => {
  const { month = 'November 2026', dueDate = '2026-11-10' } = req.body;
  const d = db.getData();
  const activeStudents = d.students.filter((s) => s.status === 'active');
  let count = 0;

  activeStudents.forEach((st) => {
    // Check duplicate
    const exists = d.feeInvoices.some((inv) => inv.studentId === st.id && inv.month === month);
    if (!exists) {
      const net = Math.max(0, st.monthlyFeePKR - st.discountPKR);
      const inv: FeeInvoice = {
        id: `INV-${Date.now()}-${st.id}`,
        invoiceNo: `ETA-INV-${1000 + d.feeInvoices.length + 1}`,
        studentId: st.id,
        studentName: st.name,
        classId: st.classId,
        className: st.className,
        month,
        year: 2026,
        dueDate,
        amountPKR: st.monthlyFeePKR,
        discountPKR: st.discountPKR,
        netAmountPKR: net,
        paidAmountPKR: 0,
        balancePKR: net,
        status: 'unpaid',
        createdAt: new Date().toISOString(),
      };
      d.feeInvoices.push(inv);
      count++;
    }
  });

  db.save();
  db.logAction('SYSTEM', 'Staff', 'INVOICES_GENERATED', 'Fees', `Generated ${count} monthly invoices for ${month}.`);
  res.json({ success: true, count, message: `Generated ${count} new invoices for ${month}.` });
});

// -------------------------------------------------------------
// 7. STUDENT ATTENDANCE
// -------------------------------------------------------------
app.get('/api/attendance', (req: Request, res: Response) => {
  const d = db.getData();
  const date = (req.query.date as string || new Date().toISOString().split('T')[0]).trim();
  const classId = (req.query.classId as string || '').trim();

  let sessions = d.attendanceRecords.filter((a) => a.date === date);
  if (classId) {
    sessions = sessions.filter((a) => a.classId === classId || a.className === classId);
  }

  res.json({ sessions });
});

app.post('/api/attendance', (req: Request, res: Response) => {
  const { date, classId, className, section = 'A', records, recordedBy = 'Staff' } = req.body;
  if (!date || !classId || !Array.isArray(records)) {
    return res.status(400).json({ error: 'Date, class, and attendance records are required.' });
  }

  const d = db.getData();
  // Check if session exists for this class & date
  const existingIdx = d.attendanceRecords.findIndex((a) => a.date === date && (a.classId === classId || a.className === className));

  if (existingIdx !== -1) {
    d.attendanceRecords[existingIdx].records = records;
    d.attendanceRecords[existingIdx].updatedAt = new Date().toISOString();
    d.attendanceRecords[existingIdx].recordedBy = recordedBy;
  } else {
    const newSession: AttendanceRecord = {
      id: `ATT-${date}-${classId}`,
      date,
      classId,
      className: className || classId,
      section,
      records,
      recordedBy,
      updatedAt: new Date().toISOString(),
    };
    d.attendanceRecords.push(newSession);
  }

  db.save();
  db.logAction('OPERATOR', recordedBy, 'ATTENDANCE_SAVED', 'Attendance', `Recorded attendance for Class ${className || classId} on ${date}.`);
  res.json({ success: true, message: 'Attendance recorded successfully.' });
});

// -------------------------------------------------------------
// 8. TESTS, EXAMS & RESULTS
// -------------------------------------------------------------
app.get('/api/tests', (req: Request, res: Response) => {
  const d = db.getData();
  res.json({ tests: d.tests });
});

app.post('/api/tests', (req: Request, res: Response) => {
  const { title, classId, className, subject, date, totalMarks = 50, passingMarks = 20, instructions = '' } = req.body;
  if (!title || !subject || !date) {
    return res.status(400).json({ error: 'Test title, subject, and date are required.' });
  }

  const d = db.getData();
  const testId = `TST-${String(d.tests.length + 1).padStart(3, '0')}`;
  const newTest: ExamTest = {
    id: testId,
    title,
    classId: classId || 'CLS-09',
    className: className || '9th',
    subject,
    date,
    totalMarks: Number(totalMarks),
    passingMarks: Number(passingMarks),
    instructions,
    results: [],
    createdAt: new Date().toISOString(),
  };

  d.tests.push(newTest);
  db.save();
  db.logAction('TEACHER', 'Staff', 'TEST_CREATED', 'Tests', `Created assessment "${title}" for Class ${newTest.className} (${subject})`);
  res.status(201).json({ test: newTest });
});

app.put('/api/tests/:id/marks', (req: Request, res: Response) => {
  const { results } = req.body;
  if (!Array.isArray(results)) {
    return res.status(400).json({ error: 'Results array is required.' });
  }

  const d = db.getData();
  const test = d.tests.find((t) => t.id === req.params.id);
  if (!test) return res.status(404).json({ error: 'Test not found.' });

  // Validate obtained marks
  for (const r of results) {
    if (r.marksObtained < 0 || r.marksObtained > test.totalMarks) {
      return res.status(400).json({
        error: `Marks for ${r.studentName || 'student'} (${r.marksObtained}) must be between 0 and total marks (${test.totalMarks}).`,
      });
    }
  }

  test.results = results;
  db.save();
  db.logAction('TEACHER', 'Staff', 'MARKS_ENTERED', 'Tests', `Updated marks for ${results.length} students in "${test.title}"`);
  res.json({ success: true, test });
});

// -------------------------------------------------------------
// 9. ETEA MCQ PRACTICE TESTS
// -------------------------------------------------------------
app.get('/api/etea/tests', (req: Request, res: Response) => {
  const d = db.getData();
  res.json({ tests: d.mcqTests });
});

app.get('/api/etea/tests/:id', (req: Request, res: Response) => {
  const d = db.getData();
  const test = d.mcqTests.find((t) => t.id === req.params.id);
  if (!test) return res.status(404).json({ error: 'ETEA test not found.' });
  res.json({ test });
});

app.post('/api/etea/tests', (req: Request, res: Response) => {
  const { title, classId, className, subject, durationMinutes = 15, questions = [] } = req.body;
  if (!title || !subject || questions.length === 0) {
    return res.status(400).json({ error: 'Title, subject, and at least one question are required.' });
  }

  const d = db.getData();
  const totalMarks = questions.reduce((sum: number, q: any) => sum + (Number(q.marks) || 4), 0);
  const newTest: McqTest = {
    id: `MCQ-${String(d.mcqTests.length + 1).padStart(3, '0')}`,
    title,
    classId: classId || 'CLS-12',
    className: className || '12th',
    subject,
    durationMinutes: Number(durationMinutes),
    totalMarks,
    questions,
    status: 'active',
    createdAt: new Date().toISOString(),
  };

  d.mcqTests.push(newTest);
  db.save();
  res.status(201).json({ test: newTest });
});

app.post('/api/etea/tests/:id/submit', (req: Request, res: Response) => {
  const { studentId, studentName, rollNo, answers } = req.body;
  const d = db.getData();
  const test = d.mcqTests.find((t) => t.id === req.params.id);
  if (!test) return res.status(404).json({ error: 'Test not found.' });

  let score = 0;
  const evaluatedAnswers = test.questions.map((q) => {
    const studentAns = answers.find((a: any) => a.questionId === q.id);
    const selectedIdx = studentAns?.selectedOptionIndex ?? -1;
    const isCorrect = selectedIdx === q.correctOptionIndex;
    if (isCorrect) {
      score += q.marks;
    }
    return {
      questionId: q.id,
      selectedOptionIndex: selectedIdx,
      isCorrect,
    };
  });

  const percentage = Math.round((score / test.totalMarks) * 100);
  const attempt: McqAttempt = {
    id: `ATM-${Date.now()}`,
    testId: test.id,
    testTitle: test.title,
    studentId: studentId || 'GUEST',
    studentName: studentName || 'Student',
    rollNo: rollNo || '00',
    score,
    totalMarks: test.totalMarks,
    percentage,
    answers: evaluatedAnswers,
    submittedAt: new Date().toISOString(),
  };

  d.mcqAttempts.unshift(attempt);
  db.save();

  res.json({ attempt });
});

// -------------------------------------------------------------
// 10. AI ASSISTANT CHAT & ACTION EXECUTION
// -------------------------------------------------------------
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  const { message, userRole = 'admin', userName = 'Staff Member' } = req.body;
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Message is required.' });
  }

  try {
    const result = await processAssistantMessage(message, userRole, userName);
    res.json(result);
  } catch (err: any) {
    console.error('AI chat error:', err);
    res.status(500).json({ error: 'Failed to process AI message.' });
  }
});

app.post('/api/ai/execute-action', (req: Request, res: Response) => {
  const { actionType, params, confirmed } = req.body;
  if (!confirmed) {
    return res.status(400).json({ error: 'Action requires explicit user confirmation.' });
  }

  const d = db.getData();

  if (actionType === 'ADD_STUDENT') {
    const studentId = `ETA-2026-${String(d.students.length + 1).padStart(3, '0')}`;
    const newStudent: Student = {
      id: studentId,
      name: params.name || 'New Student',
      fatherName: params.fatherName || 'Guardian',
      classId: d.classes.find((c) => c.name === params.className)?.id || 'CLS-07',
      className: params.className || '7th',
      section: params.section || 'A',
      rollNo: String(d.students.filter((s) => s.className === params.className).length + 1),
      admissionDate: new Date().toISOString().split('T')[0],
      dob: '',
      gender: 'Male',
      studentPhone: '',
      guardianPhone: '0345-6898969',
      address: 'Khwazakhela, Swat',
      previousSchool: '',
      monthlyFeePKR: Number(params.monthlyFeePKR || 2500),
      discountPKR: 0,
      status: 'active',
      notes: 'Added via ETA Smart Assistant with user confirmation',
      createdAt: new Date().toISOString(),
    };
    d.students.push(newStudent);
    db.save();
    db.logAction('AI_ASSISTANT', 'Staff User', 'AI_ADD_STUDENT', 'Students', `Created student ${newStudent.name} via AI action.`);
    return res.json({ success: true, message: `Successfully enrolled ${newStudent.name} with ID ${studentId}.` });
  }

  if (actionType === 'RECORD_FEE_PAYMENT') {
    const invoice = d.feeInvoices.find((i) => i.balancePKR > 0);
    if (!invoice) return res.status(400).json({ error: 'No unpaid invoice found to apply payment.' });

    const payAmount = Math.min(Number(params.amountPKR || 2500), invoice.balancePKR);
    invoice.paidAmountPKR += payAmount;
    invoice.balancePKR = invoice.netAmountPKR - invoice.paidAmountPKR;
    invoice.status = invoice.balancePKR <= 0 ? 'paid' : 'partial';

    const receiptNo = `ETA-REC-2026-${String(d.feePayments.length + 1).padStart(3, '0')}`;
    const pay: FeePayment = {
      id: `PAY-${Date.now()}`,
      receiptNo,
      invoiceId: invoice.id,
      studentId: invoice.studentId,
      studentName: invoice.studentName,
      amountPKR: payAmount,
      paymentMethod: params.paymentMethod || 'Cash',
      paymentDate: new Date().toISOString().split('T')[0],
      collectorName: 'ETA Assistant (Confirmed)',
      remarks: 'Recorded via AI Assistant Action',
      createdAt: new Date().toISOString(),
    };
    d.feePayments.unshift(pay);
    db.save();
    db.logAction('AI_ASSISTANT', 'Staff User', 'AI_FEE_PAYMENT', 'Fees', `Recorded payment of Rs. ${payAmount} for ${invoice.studentName}. Receipt: ${receiptNo}`);
    return res.json({ success: true, message: `Successfully recorded payment of Rs. ${payAmount.toLocaleString()} PKR for ${invoice.studentName}. Receipt #${receiptNo} generated.` });
  }

  res.status(400).json({ error: 'Unknown action type.' });
});

// -------------------------------------------------------------
// 11. SETTINGS, BACKUP & RESTORE
// -------------------------------------------------------------
app.get('/api/settings', (req: Request, res: Response) => {
  const d = db.getData();
  res.json({
    settings: d.settings,
    auditLogs: d.auditLogs.slice(0, 50),
    hasGeminiKey: !!process.env.GEMINI_API_KEY,
  });
});

app.put('/api/settings', (req: Request, res: Response) => {
  const d = db.getData();
  d.settings = { ...d.settings, ...req.body };
  db.save();
  db.logAction('PRINCIPAL', 'Administrator', 'SETTINGS_UPDATED', 'Settings', 'Updated academy profile and configuration.');
  res.json({ success: true, settings: d.settings });
});

app.get('/api/settings/backup', (req: Request, res: Response) => {
  const d = db.getData();
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="ETA_Academy_Database_Backup.json"');
  res.send(JSON.stringify(d, null, 2));
});

app.post('/api/settings/restore', (req: Request, res: Response) => {
  const { databaseJson } = req.body;
  if (!databaseJson || !databaseJson.students || !databaseJson.classes) {
    return res.status(400).json({ error: 'Invalid database backup JSON format.' });
  }

  db.restoreFromJson(databaseJson);
  db.logAction('PRINCIPAL', 'Administrator', 'DATABASE_RESTORED', 'Settings', 'Restored database from uploaded JSON file.');
  res.json({ success: true, message: 'Database restored successfully from backup.' });
});

app.post('/api/settings/reset', (req: Request, res: Response) => {
  db.resetToDefault();
  db.logAction('PRINCIPAL', 'Administrator', 'DATABASE_RESET', 'Settings', 'Reset database to initial academy seed data.');
  res.json({ success: true, message: 'Database reset to initial ETA academy defaults.' });
});

// -------------------------------------------------------------
// 12. VITE MIDDLEWARE OR STATIC SERVING (DEV & PROD)
// -------------------------------------------------------------
async function setupServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve('dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`====================================================`);
    console.log(`ETA Academy Management System Server`);
    console.log(`Location: Khwazakhela, Mata Road, Swat, KPK`);
    console.log(`Listening on http://0.0.0.0:${PORT}`);
    console.log(`Gemini AI Key Attached: ${process.env.GEMINI_API_KEY ? 'YES' : 'NO (Using Built-in Local Engine)'}`);
    console.log(`====================================================`);
  });
}

setupServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
