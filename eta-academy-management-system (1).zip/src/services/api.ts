import {
  AcademySettings,
  AttendanceRecord,
  ClassItem,
  DashboardStats,
  ExamTest,
  FeeInvoice,
  FeePayment,
  McqAttempt,
  McqTest,
  ProposedAction,
  Student,
  Teacher,
  User,
} from '../types';

let currentAuthToken = localStorage.getItem('eta_auth_token') || 'USR-01'; // Default to principal for fast preview

export function setAuthToken(token: string) {
  currentAuthToken = token;
  localStorage.setItem('eta_auth_token', token);
}

export function clearAuthToken() {
  currentAuthToken = '';
  localStorage.removeItem('eta_auth_token');
}

async function fetchJson<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  if (currentAuthToken) {
    headers.set('Authorization', `Bearer ${currentAuthToken}`);
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errMsg = `Request failed: ${response.status} ${response.statusText}`;
    try {
      const errorData = await response.json();
      if (errorData.error) errMsg = errorData.error;
    } catch (e) {
      // ignore
    }
    throw new Error(errMsg);
  }

  return response.json();
}

export const api = {
  auth: {
    login: async (username: string, password: string) => {
      const data = await fetchJson<{ user: User; token: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setAuthToken(data.token);
      return data;
    },
    getMe: async () => {
      return fetchJson<{ user: User }>('/api/auth/me');
    },
    changePassword: async (currentPassword: string, newPassword: string) => {
      return fetchJson<{ success: boolean; message: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
    },
  },

  dashboard: {
    getStats: async (): Promise<DashboardStats> => {
      return fetchJson<DashboardStats>('/api/dashboard/stats');
    },
  },

  students: {
    getAll: async (params?: { search?: string; classId?: string; status?: string }) => {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.classId) query.set('classId', params.classId);
      if (params?.status) query.set('status', params.status);
      return fetchJson<{ students: Student[] }>(`/api/students?${query.toString()}`);
    },
    getById: async (id: string) => {
      return fetchJson<{
        student: Student;
        invoices: FeeInvoice[];
        payments: FeePayment[];
        attendance: any[];
        testResults: any[];
        mcqAttempts: McqAttempt[];
      }>(`/api/students/${id}`);
    },
    create: async (studentData: Partial<Student>) => {
      return fetchJson<{ student: Student; invoice: FeeInvoice }>('/api/students', {
        method: 'POST',
        body: JSON.stringify(studentData),
      });
    },
    update: async (id: string, studentData: Partial<Student>) => {
      return fetchJson<{ student: Student }>(`/api/students/${id}`, {
        method: 'PUT',
        body: JSON.stringify(studentData),
      });
    },
    archive: async (id: string) => {
      return fetchJson<{ student: Student; message: string }>(`/api/students/${id}/archive`, {
        method: 'POST',
      });
    },
    delete: async (id: string) => {
      return fetchJson<{ success: boolean; message: string }>(`/api/students/${id}`, {
        method: 'DELETE',
      });
    },
    importCsv: async (csvData: string) => {
      return fetchJson<{ success: boolean; count: number; message: string }>('/api/students/import-csv', {
        method: 'POST',
        body: JSON.stringify({ csvData }),
      });
    },
  },

  classes: {
    getAll: async () => {
      return fetchJson<{ classes: ClassItem[] }>('/api/classes');
    },
    update: async (id: string, data: Partial<ClassItem>) => {
      return fetchJson<{ class: ClassItem }>(`/api/classes/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    },
    promote: async (fromClassId: string, toClassId: string, studentIds: string[]) => {
      return fetchJson<{ success: boolean; count: number; message: string }>('/api/classes/promote', {
        method: 'POST',
        body: JSON.stringify({ fromClassId, toClassId, studentIds }),
      });
    },
  },

  teachers: {
    getAll: async () => {
      return fetchJson<{ teachers: Teacher[] }>('/api/teachers');
    },
    create: async (teacherData: Partial<Teacher>) => {
      return fetchJson<{ teacher: Teacher }>('/api/teachers', {
        method: 'POST',
        body: JSON.stringify(teacherData),
      });
    },
    update: async (id: string, teacherData: Partial<Teacher>) => {
      return fetchJson<{ teacher: Teacher }>(`/api/teachers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(teacherData),
      });
    },
  },

  fees: {
    getInvoices: async (params?: { classId?: string; status?: string; month?: string }) => {
      const query = new URLSearchParams();
      if (params?.classId) query.set('classId', params.classId);
      if (params?.status) query.set('status', params.status);
      if (params?.month) query.set('month', params.month);
      return fetchJson<{ invoices: FeeInvoice[] }>(`/api/fees/invoices?${query.toString()}`);
    },
    getPayments: async () => {
      return fetchJson<{ payments: FeePayment[] }>('/api/fees/payments');
    },
    recordPayment: async (data: {
      invoiceId: string;
      amountPKR: number;
      paymentMethod: string;
      collectorName?: string;
      remarks?: string;
    }) => {
      return fetchJson<{ success: boolean; payment: FeePayment; invoice: FeeInvoice }>('/api/fees/pay', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    generateMonthlyInvoices: async (month: string, dueDate: string) => {
      return fetchJson<{ success: boolean; count: number; message: string }>('/api/fees/generate-monthly-invoices', {
        method: 'POST',
        body: JSON.stringify({ month, dueDate }),
      });
    },
  },

  attendance: {
    getSessions: async (date?: string, classId?: string) => {
      const query = new URLSearchParams();
      if (date) query.set('date', date);
      if (classId) query.set('classId', classId);
      return fetchJson<{ sessions: AttendanceRecord[] }>(`/api/attendance?${query.toString()}`);
    },
    saveAttendance: async (data: {
      date: string;
      classId: string;
      className: string;
      section: string;
      records: any[];
      recordedBy: string;
    }) => {
      return fetchJson<{ success: boolean; message: string }>('/api/attendance', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
  },

  tests: {
    getAll: async () => {
      return fetchJson<{ tests: ExamTest[] }>('/api/tests');
    },
    create: async (data: Partial<ExamTest>) => {
      return fetchJson<{ test: ExamTest }>('/api/tests', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    saveMarks: async (testId: string, results: any[]) => {
      return fetchJson<{ success: boolean; test: ExamTest }>(`/api/tests/${testId}/marks`, {
        method: 'PUT',
        body: JSON.stringify({ results }),
      });
    },
  },

  etea: {
    getTests: async () => {
      return fetchJson<{ tests: McqTest[] }>('/api/etea/tests');
    },
    getTestById: async (id: string) => {
      return fetchJson<{ test: McqTest }>(`/api/etea/tests/${id}`);
    },
    createTest: async (data: Partial<McqTest>) => {
      return fetchJson<{ test: McqTest }>('/api/etea/tests', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    submitAttempt: async (testId: string, data: { studentId: string; studentName: string; rollNo: string; answers: any[] }) => {
      return fetchJson<{ attempt: McqAttempt }>(`/api/etea/tests/${testId}/submit`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
  },

  ai: {
    sendMessage: async (message: string, userRole: string, userName: string) => {
      return fetchJson<{
        reply: string;
        proposedAction?: ProposedAction | null;
        mode: 'GEMINI_AI' | 'LOCAL_RULE_BASED';
      }>('/api/ai/chat', {
        method: 'POST',
        body: JSON.stringify({ message, userRole, userName }),
      });
    },
    executeAction: async (actionType: string, params: any) => {
      return fetchJson<{ success: boolean; message: string }>('/api/ai/execute-action', {
        method: 'POST',
        body: JSON.stringify({ actionType, params, confirmed: true }),
      });
    },
  },

  settings: {
    get: async () => {
      return fetchJson<{ settings: AcademySettings; auditLogs: any[]; hasGeminiKey: boolean }>('/api/settings');
    },
    update: async (settings: Partial<AcademySettings>) => {
      return fetchJson<{ success: boolean; settings: AcademySettings }>('/api/settings', {
        method: 'PUT',
        body: JSON.stringify(settings),
      });
    },
    restore: async (databaseJson: any) => {
      return fetchJson<{ success: boolean; message: string }>('/api/settings/restore', {
        method: 'POST',
        body: JSON.stringify({ databaseJson }),
      });
    },
    reset: async () => {
      return fetchJson<{ success: boolean; message: string }>('/api/settings/reset', {
        method: 'POST',
      });
    },
  },
};
