export type UserRole = 'principal' | 'admin' | 'teacher' | 'accountant' | 'attendance_operator';

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  phone: string;
  avatar?: string;
  assignedClassIds?: string[];
  createdAt: string;
}

export interface Student {
  id: string;
  name: string;
  fatherName: string;
  classId: string;
  className: string;
  section: string;
  rollNo: string;
  admissionDate: string;
  dob: string;
  gender: 'Male' | 'Female';
  studentPhone: string;
  guardianPhone: string;
  address: string;
  previousSchool: string;
  monthlyFeePKR: number;
  discountPKR: number;
  status: 'active' | 'archived' | 'graduated';
  notes: string;
  avatar?: string;
  createdAt: string;
}

export interface Teacher {
  id: string;
  name: string;
  gender: 'Male' | 'Female';
  qualification: string;
  subjects: string[];
  assignedClasses: string[];
  phone: string;
  joiningDate: string;
  monthlySalaryPKR: number;
  status: 'active' | 'archived';
  address: string;
  notes: string;
}

export interface ClassItem {
  id: string;
  name: string;
  gradeNumber: number;
  sections: string[];
  subjects: string[];
  monthlyFeePKR: number;
  roomNo?: string;
  classTeacher?: string;
  studentCount?: number;
}

export interface FeeInvoice {
  id: string;
  invoiceNo: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  month: string;
  year: number;
  dueDate: string;
  amountPKR: number;
  discountPKR: number;
  netAmountPKR: number;
  paidAmountPKR: number;
  balancePKR: number;
  status: 'paid' | 'partial' | 'unpaid' | 'overdue' | 'waived';
  createdAt: string;
}

export interface FeePayment {
  id: string;
  receiptNo: string;
  invoiceId: string;
  studentId: string;
  studentName: string;
  amountPKR: number;
  paymentMethod: 'Cash' | 'Bank Transfer' | 'EasyPaisa' | 'JazzCash';
  paymentDate: string;
  collectorName: string;
  remarks: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  classId: string;
  className: string;
  section: string;
  records: {
    studentId: string;
    studentName: string;
    rollNo: string;
    status: 'present' | 'absent' | 'late' | 'leave';
    remarks?: string;
  }[];
  recordedBy: string;
  updatedAt: string;
}

export interface ExamTest {
  id: string;
  title: string;
  classId: string;
  className: string;
  subject: string;
  date: string;
  totalMarks: number;
  passingMarks: number;
  instructions: string;
  results: {
    studentId: string;
    studentName: string;
    rollNo: string;
    marksObtained: number;
    remarks: string;
  }[];
  createdAt: string;
}

export interface McqQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  marks: number;
}

export interface McqTest {
  id: string;
  title: string;
  classId: string;
  className: string;
  subject: string;
  durationMinutes: number;
  totalMarks: number;
  questions: McqQuestion[];
  status: 'active' | 'draft';
  createdAt: string;
}

export interface McqAttempt {
  id: string;
  testId: string;
  testTitle: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  score: number;
  totalMarks: number;
  percentage: number;
  answers: {
    questionId: string;
    selectedOptionIndex: number;
    isCorrect: boolean;
  }[];
  submittedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  details: string;
}

export interface AcademySettings {
  name: string;
  shortName: string;
  principal: string;
  location: string;
  phone: string;
  whatsappNumber: string;
  whatsappLink: string;
  mapLink: string;
  currency: string;
  academicSession: string;
  tagline: string;
}

export interface ProposedAction {
  id?: string;
  type: 'ADD_STUDENT' | 'RECORD_FEE_PAYMENT' | 'MARK_ATTENDANCE' | 'SCHEDULE_TEST' | 'NAVIGATE' | 'NONE';
  title: string;
  description: string;
  requiresConfirmation: boolean;
  params: Record<string, any>;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface DashboardStats {
  totalActiveStudents: number;
  totalStaff: number;
  classBreakdown: Record<string, number>;
  todayAttendance: {
    present: number;
    absent: number;
    late: number;
    leave: number;
    percentage: number;
  };
  fees: {
    invoicedPKR: number;
    collectedPKR: number;
    outstandingPKR: number;
    currency: string;
  };
  recentStudents: Student[];
  recentPayments: FeePayment[];
  recentTests: ExamTest[];
  activeExamsCount: number;
}
