import React, { useState, useEffect } from 'react';
import { api, clearAuthToken, setAuthToken } from './services/api';
import { User, UserRole, DashboardStats, Student, FeePayment, ExamTest } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { FloatingAssistant } from './components/FloatingAssistant';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PrintableReceipt } from './components/PrintableReceipt';
import { PrintableIdCard } from './components/PrintableIdCard';
import { PrintableResultCard } from './components/PrintableResultCard';

// Pages
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { StudentsPage } from './pages/StudentsPage';
import { ClassesPage } from './pages/ClassesPage';
import { TeachersPage } from './pages/TeachersPage';
import { FeesPage } from './pages/FeesPage';
import { AttendancePage } from './pages/AttendancePage';
import { ExamsPage } from './pages/ExamsPage';
import { EteaPage } from './pages/EteaPage';
import { ReportsPage } from './pages/ReportsPage';
import { AiAssistantPage } from './pages/AiAssistantPage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);

  // Active Printable Modals
  const [receiptPayment, setReceiptPayment] = useState<FeePayment | null>(null);
  const [idCardStudent, setIdCardStudent] = useState<Student | null>(null);
  const [resultCardData, setResultCardData] = useState<{ test: ExamTest; studentResult: any; student?: Student } | null>(null);

  // Quick Action trigger
  const [quickStudentModalOpen, setQuickStudentModalOpen] = useState(false);
  const [preselectedStudentForFee, setPreselectedStudentForFee] = useState<Student | null>(null);

  // Check current session
  useEffect(() => {
    async function checkAuth() {
      try {
        const res = await api.auth.getMe();
        setCurrentUser(res.user);
      } catch (err) {
        // Fallback demo user for preview: Principal Mr. Rahmat Ali
        setCurrentUser({
          id: 'USR-01',
          name: 'Mr. Rahmat Ali',
          username: 'principal',
          email: 'principal@eta-academy.edu.pk',
          role: 'principal',
          phone: '0345-6898969',
          createdAt: '2026-01-01T08:00:00Z',
        });
      } finally {
        setLoadingUser(false);
      }
    }
    checkAuth();
  }, []);

  // Load Dashboard Stats
  const fetchStats = async () => {
    try {
      const stats = await api.dashboard.getStats();
      setDashboardStats(stats);
    } catch (err) {
      console.error('Failed to load stats:', err);
    }
  };

  useEffect(() => {
    if (currentUser) {
      fetchStats();
    }
  }, [currentUser, currentTab]);

  const handleLogout = () => {
    clearAuthToken();
    setCurrentUser(null);
  };

  const handleRoleSwitch = (newRole: UserRole) => {
    if (!currentUser) return;
    const roleNames: Record<UserRole, { name: string; id: string; email: string }> = {
      principal: { name: 'Mr. Rahmat Ali', id: 'USR-01', email: 'principal@eta-academy.edu.pk' },
      admin: { name: 'Admin Desk', id: 'USR-02', email: 'admin@eta-academy.edu.pk' },
      teacher: { name: 'Mr. Nouman Khan', id: 'USR-03', email: 'nouman@eta-academy.edu.pk' },
      accountant: { name: 'Muhammad Farooq', id: 'USR-04', email: 'accounts@eta-academy.edu.pk' },
      attendance_operator: { name: 'Tariq Mehmood', id: 'USR-05', email: 'attendance@eta-academy.edu.pk' },
    };

    const target = roleNames[newRole];
    setAuthToken(target.id);
    setCurrentUser({
      ...currentUser,
      id: target.id,
      name: target.name,
      role: newRole,
      email: target.email,
    });
  };

  const handleOpenQuickAction = (action: string) => {
    if (action === 'ADD_STUDENT') {
      setCurrentTab('students');
    } else if (action === 'COLLECT_FEE') {
      setCurrentTab('fees');
    }
  };

  if (loadingUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300">
        <div className="w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="font-bold text-sm tracking-wide">The Excellent Tuition Academy Khwazakhela (ETA)...</p>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage onLoginSuccess={(u) => setCurrentUser(u)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row antialiased">
      
      {/* Desktop Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
        currentUser={currentUser}
        onLogout={handleLogout}
        onSwitchRole={handleRoleSwitch}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        
        {/* Top Header */}
        <Header
          currentUser={currentUser}
          onOpenQuickAction={handleOpenQuickAction}
          onSelectTab={(tab) => setCurrentTab(tab)}
        />

        {/* Viewport Content */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {currentTab === 'dashboard' && (
            <DashboardPage
              stats={dashboardStats}
              currentUser={currentUser}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onOpenQuickAction={handleOpenQuickAction}
              onViewStudent={(st) => {
                setIdCardStudent(st);
              }}
              onViewReceipt={(pay) => {
                setReceiptPayment(pay);
              }}
            />
          )}

          {currentTab === 'students' && (
            <StudentsPage
              currentUser={currentUser}
              onPrintIdCard={(st) => setIdCardStudent(st)}
              onRecordFeeForStudent={(st) => {
                setPreselectedStudentForFee(st);
                setCurrentTab('fees');
              }}
            />
          )}

          {currentTab === 'classes' && (
            <ClassesPage
              currentUser={currentUser}
              onNavigateTab={(tab) => setCurrentTab(tab)}
            />
          )}

          {currentTab === 'teachers' && (
            <TeachersPage currentUser={currentUser} />
          )}

          {currentTab === 'fees' && (
            <FeesPage
              currentUser={currentUser}
              onViewReceipt={(pay) => setReceiptPayment(pay)}
              preselectedStudent={preselectedStudentForFee}
            />
          )}

          {currentTab === 'attendance' && (
            <AttendancePage currentUser={currentUser} />
          )}

          {currentTab === 'exams' && (
            <ExamsPage
              currentUser={currentUser}
              onPrintResultCard={(test, studentResult, student) =>
                setResultCardData({ test, studentResult, student })
              }
            />
          )}

          {currentTab === 'etea' && (
            <EteaPage currentUser={currentUser} />
          )}

          {currentTab === 'reports' && (
            <ReportsPage currentUser={currentUser} />
          )}

          {currentTab === 'ai' && (
            <AiAssistantPage
              currentUser={currentUser}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onRefreshData={fetchStats}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsPage currentUser={currentUser} />
          )}
        </main>
      </div>

      {/* Floating ETA Smart Assistant (Available Across All Pages) */}
      <FloatingAssistant
        currentUser={currentUser}
        onNavigateTab={(tab) => setCurrentTab(tab)}
        onRefreshData={fetchStats}
      />

      {/* Mobile Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
      />

      {/* PWA Offline Mode Indicator Toast */}
      <OfflineIndicator />

      {/* Printable Modals */}
      {receiptPayment && (
        <PrintableReceipt
          payment={receiptPayment}
          onClose={() => setReceiptPayment(null)}
        />
      )}

      {idCardStudent && (
        <PrintableIdCard
          student={idCardStudent}
          onClose={() => setIdCardStudent(null)}
        />
      )}

      {resultCardData && (
        <PrintableResultCard
          test={resultCardData.test}
          studentResult={resultCardData.studentResult}
          student={resultCardData.student}
          onClose={() => setResultCardData(null)}
        />
      )}

    </div>
  );
}
