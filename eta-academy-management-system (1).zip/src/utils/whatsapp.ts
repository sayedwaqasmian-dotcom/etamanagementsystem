export function formatWhatsAppPhone(phone: string): string {
  // Convert 0345-6898969 or 03456898969 to 923456898969
  const cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('0')) {
    return '92' + cleaned.substring(1);
  }
  if (cleaned.startsWith('92')) {
    return cleaned;
  }
  return '92' + cleaned;
}

export function openWhatsAppChat(phone: string, message: string) {
  const formattedPhone = formatWhatsAppPhone(phone || '0345-6898969');
  const encodedMsg = encodeURIComponent(message);
  const url = `https://wa.me/${formattedPhone}?text=${encodedMsg}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

export const WhatsAppTemplates = {
  feeReminder: (studentName: string, className: string, month: string, balancePKR: number, dueDate: string) => {
    return `Assalam-o-Alaikum!
This is a gentle fee reminder from The Excellent Tuition Academy Khwazakhela (ETA), Swat.

Student: ${studentName}
Class: ${className}
Month: ${month}
Outstanding Fee: Rs. ${balancePKR.toLocaleString()} PKR
Due Date: ${dueDate}

Kindly deposit the fee at the academy accounts office.
Contact: 0345-6898969
Principal: Mr. Rahmat Ali
The Excellent Tuition Academy, Mata Road, Khwazakhela, Swat.`;
  },

  absenceNotice: (studentName: string, className: string, date: string) => {
    return `Assalam-o-Alaikum!
Notice from The Excellent Tuition Academy Khwazakhela (ETA), Swat:

Respected Guardian, your child ${studentName} (Class: ${className}) was marked ABSENT today (${date}).

Regular attendance is compulsory for academic success. Please confirm reason of absence by replying here or calling 0345-6898969.

The Excellent Tuition Academy, Mata Road, Khwazakhela.`;
  },

  examResult: (studentName: string, className: string, testTitle: string, subject: string, marksObtained: number, totalMarks: number, percentage: number) => {
    return `Assalam-o-Alaikum!
Academic Assessment Result from The Excellent Tuition Academy Khwazakhela:

Student: ${studentName} (Class: ${className})
Exam: ${testTitle}
Subject: ${subject}
Obtained Marks: ${marksObtained} / ${totalMarks} (${percentage}%)
Status: ${percentage >= 40 ? 'Passed' : 'Needs Improvement'}

Principal: Mr. Rahmat Ali
The Excellent Tuition Academy, Mata Road, Khwazakhela, Swat.
Contact: 0345-6898969`;
  },

  generalAnnouncement: (message: string) => {
    return `Assalam-o-Alaikum!
Announcement from The Excellent Tuition Academy Khwazakhela (ETA), Swat:

${message}

Contact: 0345-6898969
WhatsApp: https://wa.me/923456898969`;
  },
};
