import React, { useState, useEffect } from 'react';
import {
  Settings,
  Shield,
  Download,
  Upload,
  RotateCcw,
  Key,
  CheckCircle2,
  FileJson,
  Lock,
  Phone,
  MapPin,
  Save,
  Clock,
  History,
  AlertTriangle,
} from 'lucide-react';
import { AcademySettings, AuditLog, User } from '../types';
import { api } from '../services/api';

interface SettingsPageProps {
  currentUser: User;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ currentUser }) => {
  const [settings, setSettings] = useState<AcademySettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [hasGeminiKey, setHasGeminiKey] = useState(false);
  const [loading, setLoading] = useState(true);

  // Password Change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwMessage, setPwMessage] = useState<{ text: string; success: boolean } | null>(null);

  // Restore JSON state
  const [restoreJsonText, setRestoreJsonText] = useState('');
  const [showRestoreModal, setShowRestoreModal] = useState(false);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await api.settings.get();
      setSettings(res.settings);
      setAuditLogs(res.auditLogs || []);
      setHasGeminiKey(res.hasGeminiKey);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;

    try {
      await api.settings.update(settings);
      alert('Academy profile and settings saved successfully.');
      loadSettings();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setPwMessage({ text: 'New passwords do not match.', success: false });
      return;
    }

    try {
      const res = await api.auth.changePassword(currentPassword, newPassword);
      setPwMessage({ text: res.message, success: true });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setPwMessage({ text: err.message, success: false });
    }
  };

  const handleResetDefaults = async () => {
    if (!confirm('CAUTION: This will reset the database to initial ETA Academy seed data. Continue?')) {
      return;
    }

    try {
      await api.settings.reset();
      alert('Database reset to defaults.');
      window.location.reload();
    } catch (err: any) {
      alert(`Reset failed: ${err.message}`);
    }
  };

  const handleRestoreJson = async () => {
    if (!restoreJsonText.trim()) return;

    try {
      const parsed = JSON.parse(restoreJsonText);
      await api.settings.restore(parsed);
      alert('Database restored successfully from backup JSON.');
      setShowRestoreModal(false);
      window.location.reload();
    } catch (err: any) {
      alert(`Restore failed: ${err.message}`);
    }
  };

  if (!settings) {
    return <div className="p-8 text-center text-slate-400 text-xs">Loading academy settings...</div>;
  }

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      
      {/* Header */}
      <div>
        <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
          <Settings className="w-6 h-6 text-amber-400" />
          Academy Settings & System Administration
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Academy configuration, institutional details, database backup/restore, and security audit logs
        </p>
      </div>

      {/* Grid: Academy Profile & System Security */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Profile Form */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl">
          <h3 className="text-base font-extrabold text-white mb-4 pb-3 border-b border-slate-800">
            Official Academy Details
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-semibold">Official Academy Name</label>
                <input
                  type="text"
                  value={settings.name}
                  onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Short Name / Monogram</label>
                <input
                  type="text"
                  value={settings.shortName}
                  onChange={(e) => setSettings({ ...settings, shortName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Principal and Founder</label>
                <input
                  type="text"
                  value={settings.principal}
                  onChange={(e) => setSettings({ ...settings, principal: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-bold"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-semibold">Campus Address & Location</label>
                <input
                  type="text"
                  value={settings.location}
                  onChange={(e) => setSettings({ ...settings, location: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Primary Contact Phone</label>
                <input
                  type="text"
                  value={settings.phone}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Official WhatsApp Number</label>
                <input
                  type="text"
                  value={settings.whatsappNumber}
                  onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Academic Session</label>
                <input
                  type="text"
                  value={settings.academicSession}
                  onChange={(e) => setSettings({ ...settings, academicSession: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Default Currency</label>
                <input
                  type="text"
                  disabled
                  value={settings.currency}
                  className="w-full bg-slate-950/60 border border-slate-800 rounded-xl px-3.5 py-2 text-amber-400 font-mono font-bold"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-semibold">Motto / Tagline</label>
                <input
                  type="text"
                  value={settings.tagline}
                  onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 italic"
                />
              </div>
            </div>

            {currentUser.role === 'principal' && (
              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition shadow-md shadow-blue-600/20"
                >
                  <Save className="w-4 h-4" />
                  Save Academy Profile
                </button>
              </div>
            )}
          </form>
        </div>

        {/* Right Col: Database & Security Tools */}
        <div className="space-y-6">
          
          {/* Backup & Restore Deck */}
          <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-2 border-b border-slate-800">
              <FileJson className="w-4 h-4 text-emerald-400" />
              Database Backup & Restore
            </h3>

            <p className="text-xs text-slate-400 leading-relaxed">
              Export the complete persistent database (students, attendance, fees, exams) as a single JSON file.
            </p>

            <div className="space-y-2">
              <a
                href="/api/settings/backup"
                download="ETA_Database_Backup.json"
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition border border-slate-700"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Download Full Database Backup</span>
              </a>

              {currentUser.role === 'principal' && (
                <>
                  <button
                    onClick={() => setShowRestoreModal(true)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition border border-slate-700"
                  >
                    <Upload className="w-4 h-4 text-blue-400" />
                    <span>Restore from JSON File</span>
                  </button>

                  <button
                    onClick={handleResetDefaults}
                    className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-semibold text-xs transition border border-rose-500/30"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset to Seed Defaults</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Change Password Card */}
          <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-2 border-b border-slate-800">
              <Key className="w-4 h-4 text-amber-400" />
              Change Your Password
            </h3>

            {pwMessage && (
              <div
                className={`p-2.5 rounded-xl text-xs font-semibold ${
                  pwMessage.success ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}
              >
                {pwMessage.text}
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition shadow-sm"
              >
                Update Password
              </button>
            </form>
          </div>

        </div>

      </div>

      {/* Audit Logs Table */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-400" />
            <h3 className="font-extrabold text-sm text-white">System Security & Activity Audit Trail</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Last 50 recorded operations</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                <th className="p-3">Timestamp</th>
                <th className="p-3">User</th>
                <th className="p-3">Action</th>
                <th className="p-3">Module</th>
                <th className="p-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-300">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition">
                  <td className="p-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="p-3 font-bold text-white whitespace-nowrap">
                    {log.userName}
                  </td>
                  <td className="p-3 font-mono font-bold text-amber-400 whitespace-nowrap">
                    {log.action}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-semibold">
                      {log.module}
                    </span>
                  </td>
                  <td className="p-3 text-slate-300 leading-relaxed">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ----------------- MODAL: RESTORE JSON ----------------- */}
      {showRestoreModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <h3 className="font-black text-sm text-white mb-2">Paste Database JSON Backup</h3>
            <p className="text-xs text-slate-400 mb-3">
              Paste the entire contents of a previously downloaded database JSON backup file.
            </p>

            <textarea
              rows={8}
              value={restoreJsonText}
              onChange={(e) => setRestoreJsonText(e.target.value)}
              placeholder="Paste JSON here..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-100"
            />

            <div className="mt-4 flex justify-end gap-2 text-xs">
              <button
                onClick={() => setShowRestoreModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleRestoreJson}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                Restore Database
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
