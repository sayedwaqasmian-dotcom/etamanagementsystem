import React from 'react';
import {
  Users,
  GraduationCap,
  Receipt,
  CalendarCheck2,
  TrendingUp,
  AlertCircle,
  Clock,
  ArrowUpRight,
  UserPlus,
  CreditCard,
  FileSpreadsheet,
  BrainCircuit,
  Sparkles,
  Phone,
  CheckCircle2,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { DashboardStats, User, Student, FeePayment } from '../types';

interface DashboardPageProps {
  stats: DashboardStats | null;
  currentUser: User;
  onNavigateTab: (tab: string) => void;
  onOpenQuickAction: (action: string) => void;
  onViewStudent: (student: Student) => void;
  onViewReceipt: (payment: FeePayment) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  stats,
  currentUser,
  onNavigateTab,
  onOpenQuickAction,
  onViewStudent,
  onViewReceipt,
}) => {
  if (!stats) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-slate-400">
        <div className="w-8 h-8 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mb-3"></div>
        <p className="text-xs">Loading live ETA Academy records...</p>
      </div>
    );
  }

  const {
    totalActiveStudents,
    totalStaff,
    classBreakdown,
    todayAttendance,
    fees,
    recentStudents,
    recentPayments,
    recentTests,
    activeExamsCount,
  } = stats;

  const classesList = ['6th', '7th', '8th', '9th', '10th', '11th', '12th'];

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Welcome & Academy Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-slate-800 p-6 lg:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              The Excellent Tuition Academy Khwazakhela (ETA)
            </div>
            <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight">
              Welcome back, {currentUser.name}
            </h1>
            <p className="text-xs lg:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Mata Road, Khwazakhela, Swat, Khyber Pakhtunkhwa. Quality Education | Brighter Future | Better Tomorrow.
            </p>
          </div>

          {/* Quick Actions Deck */}
          <div className="flex flex-wrap items-center gap-2.5">
            {currentUser.role !== 'attendance_operator' && (
              <button
                onClick={() => onOpenQuickAction('ADD_STUDENT')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/20 transition transform active:scale-95"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ Student</span>
              </button>
            )}

            {(currentUser.role === 'principal' || currentUser.role === 'accountant' || currentUser.role === 'admin') && (
              <button
                onClick={() => onOpenQuickAction('COLLECT_FEE')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/20 transition transform active:scale-95"
              >
                <CreditCard className="w-4 h-4" />
                <span>Collect Fee (PKR)</span>
              </button>
            )}

            <button
              onClick={() => onNavigateTab('attendance')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold border border-slate-700 transition"
            >
              <CalendarCheck2 className="w-4 h-4 text-amber-400" />
              <span>Mark Attendance</span>
            </button>

            <button
              onClick={() => onNavigateTab('ai')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-lg shadow-amber-500/20 transition"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask ETA AI</span>
            </button>
          </div>
        </div>

        {/* Subtle Decorative Backdrop Elements */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* KPI Statistic Cards (Grid) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Active Students */}
        <div
          onClick={() => onNavigateTab('students')}
          className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-5 transition-all shadow-md hover:shadow-xl hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Students</span>
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center group-hover:scale-110 transition">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl lg:text-3xl font-black text-white">{totalActiveStudents}</span>
            <span className="text-xs text-blue-400 font-medium">Classes 6th–12th</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Enrolled in current session</span>
            <span className="text-blue-400 font-semibold group-hover:underline flex items-center">
              View <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 2: Today's Attendance */}
        <div
          onClick={() => onNavigateTab('attendance')}
          className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 p-5 transition-all shadow-md hover:shadow-xl hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Today's Attendance</span>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition">
              <CalendarCheck2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl lg:text-3xl font-black text-emerald-400">{todayAttendance.percentage}%</span>
            <span className="text-xs text-slate-400 font-medium">Present Rate</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>
              <strong className="text-emerald-400">{todayAttendance.present}</strong> Present •{' '}
              <strong className="text-rose-400">{todayAttendance.absent}</strong> Absent
            </span>
            <span className="text-emerald-400 font-semibold group-hover:underline flex items-center">
              Sheet <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 3: Fees Collected This Month */}
        <div
          onClick={() => onNavigateTab('fees')}
          className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-5 transition-all shadow-md hover:shadow-xl hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Fees Collected</span>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-110 transition">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-1.5">
            <span className="text-xs text-amber-400 font-bold">Rs.</span>
            <span className="text-2xl lg:text-3xl font-black text-white">
              {fees.collectedPKR.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400 font-mono">PKR</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>October 2026 Collection</span>
            <span className="text-amber-400 font-semibold group-hover:underline flex items-center">
              Ledger <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 4: Outstanding Fees Balance */}
        <div
          onClick={() => onNavigateTab('fees')}
          className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-rose-500/50 p-5 transition-all shadow-md hover:shadow-xl hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Outstanding Balance</span>
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:scale-110 transition">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-1.5">
            <span className="text-xs text-rose-400 font-bold">Rs.</span>
            <span className="text-2xl lg:text-3xl font-black text-rose-400">
              {fees.outstandingPKR.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400 font-mono">PKR</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Pending parent dues</span>
            <span className="text-rose-400 font-semibold group-hover:underline flex items-center">
              Remind <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

      </div>

      {/* Class Distribution & Monthly Financial Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Class-wise Strength Chart / Bars */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-lg">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-blue-400" />
                Class-wise Student Enrollment
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Strength distribution across Classes 6th through 12th</p>
            </div>
            <button
              onClick={() => onNavigateTab('classes')}
              className="text-xs font-semibold text-blue-400 hover:underline"
            >
              Manage Classes →
            </button>
          </div>

          <div className="mt-5 space-y-3.5">
            {classesList.map((cls) => {
              const count = classBreakdown[cls] || 0;
              const maxPossible = Math.max(...Object.values(classBreakdown), 5);
              const barPercent = Math.min(100, Math.round((count / maxPossible) * 100));

              return (
                <div key={cls} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">Class {cls}</span>
                    <span className="font-semibold text-slate-400 font-mono">
                      {count} {count === 1 ? 'student' : 'students'}
                    </span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden flex">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-600 via-indigo-500 to-amber-400 transition-all duration-700"
                      style={{ width: `${Math.max(barPercent, 12)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Academy Key Faculty & Metrics */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                Faculty & Administration
              </h3>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-300">
                {totalStaff} Staff
              </span>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <p className="font-bold text-white">Mr. Rahmat Ali</p>
                <p className="text-[11px] text-amber-400 font-medium">Principal & Founder</p>
                <p className="text-[10px] text-slate-400 mt-1">Founder of The Excellent Tuition Academy Swat</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <p className="font-bold text-white">Senior Science Faculty</p>
                <p className="text-[11px] text-slate-300">Mr. Nouman Khan (Botany/Chem) • Mr. Haider Ali (Physics)</p>
                <p className="text-[10px] text-slate-400 mt-1">Specialized coaching for Matric & FSc Board Exams</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <p className="font-bold text-white">Senior Languages & Math</p>
                <p className="text-[11px] text-slate-300">Mr. Sultan Zeb (English) • Hazrat Ali Mian (Urdu) • Mr. Qasim (Math)</p>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800">
            <button
              onClick={() => onNavigateTab('teachers')}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition text-center"
            >
              View Full Faculty Directory →
            </button>
          </div>
        </div>

      </div>

      {/* Two Column Section: Recent Admissions & Recent Fee Receipts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Student Admissions */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-lg">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-400" />
              Recent Admissions
            </h3>
            <button
              onClick={() => onNavigateTab('students')}
              className="text-xs font-semibold text-blue-400 hover:underline"
            >
              All Students →
            </button>
          </div>

          <div className="divide-y divide-slate-800/80 mt-2">
            {recentStudents.slice(0, 5).map((student) => (
              <div
                key={student.id}
                onClick={() => onViewStudent(student)}
                className="py-3 flex items-center justify-between hover:bg-slate-800/40 px-2 rounded-xl cursor-pointer transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-900/60 border border-blue-500/30 text-blue-300 flex items-center justify-center font-bold text-xs">
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white">{student.name}</p>
                    <p className="text-[11px] text-slate-400">
                      S/D of {student.fatherName} • Class {student.className}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono text-xs font-bold text-amber-400">
                    Rs. {student.monthlyFeePKR.toLocaleString()}
                  </span>
                  <p className="text-[10px] text-slate-500">{student.id}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Fee Payments (PKR) */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-lg">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-400" />
              Recent Fee Collections (PKR)
            </h3>
            <button
              onClick={() => onNavigateTab('fees')}
              className="text-xs font-semibold text-emerald-400 hover:underline"
            >
              Fee Ledger →
            </button>
          </div>

          <div className="divide-y divide-slate-800/80 mt-2">
            {recentPayments.slice(0, 5).map((payment) => (
              <div
                key={payment.id}
                onClick={() => onViewReceipt(payment)}
                className="py-3 flex items-center justify-between hover:bg-slate-800/40 px-2 rounded-xl cursor-pointer transition"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-bold text-white">{payment.studentName}</p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-semibold">
                      {payment.paymentMethod}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Receipt: <span className="font-mono text-slate-300">{payment.receiptNo}</span> • {payment.paymentDate}
                  </p>
                </div>

                <div className="text-right">
                  <span className="font-mono text-xs font-extrabold text-emerald-400">
                    + Rs. {payment.amountPKR.toLocaleString()} PKR
                  </span>
                  <span className="block text-[10px] text-blue-400 hover:underline">
                    Print Receipt
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Upcoming Assessments & ETEA Practice Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 p-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">ETEA & Board Exam Mock Engine Ready</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                Practice MCQ tests configured for Medical (MDCAT) & Engineering entrance with live countdown timer.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('etea')}
            className="shrink-0 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow-md"
          >
            Open ETEA Simulator →
          </button>
        </div>
      </div>

    </div>
  );
};
