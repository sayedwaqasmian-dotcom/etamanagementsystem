import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Award,
  PlusCircle,
  Printer,
  CheckCircle,
  X,
  Search,
  Filter,
  Users,
  Edit,
  Save,
  FileText,
  Phone,
} from 'lucide-react';
import { ExamTest, Student, User } from '../types';
import { api } from '../services/api';
import { calculateGrade } from '../components/PrintableResultCard';
import { openWhatsAppChat, WhatsAppTemplates } from '../utils/whatsapp';

interface ExamsPageProps {
  currentUser: User;
  onPrintResultCard: (test: ExamTest, studentResult: any, student?: Student) => void;
}

export const ExamsPage: React.FC<ExamsPageProps> = ({ currentUser, onPrintResultCard }) => {
  const [tests, setTests] = useState<ExamTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTest, setSelectedTest] = useState<ExamTest | null>(null);
  const [classStudents, setClassStudents] = useState<Student[]>([]);

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showMarksModal, setShowMarksModal] = useState(false);

  // New Test Form
  const [testForm, setTestForm] = useState({
    title: '',
    className: '9th',
    subject: 'Physics',
    date: new Date().toISOString().split('T')[0],
    totalMarks: 50,
    passingMarks: 20,
    instructions: '',
  });

  // Marks Entry Map: studentId -> { marks: number, remarks: string }
  const [marksMap, setMarksMap] = useState<Record<string, { marks: number; remarks: string }>>({});

  const loadTests = async () => {
    setLoading(true);
    try {
      const res = await api.tests.getAll();
      setTests(res.tests);
      if (res.tests.length > 0 && !selectedTest) {
        setSelectedTest(res.tests[0]);
      }
    } catch (err: any) {
      console.error('Failed to load tests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTests();
  }, []);

  const loadClassStudents = async (className: string) => {
    try {
      const res = await api.students.getAll({ classId: className, status: 'active' });
      setClassStudents(res.students);
    } catch (err) {
      // ignore
    }
  };

  const handleOpenMarksEntry = async (test: ExamTest) => {
    setSelectedTest(test);
    await loadClassStudents(test.className);

    // Populate marks map from existing results
    const initialMap: Record<string, { marks: number; remarks: string }> = {};
    test.results.forEach((r) => {
      initialMap[r.studentId] = { marks: r.marksObtained, remarks: r.remarks };
    });
    setMarksMap(initialMap);
    setShowMarksModal(true);
  };

  const handleSaveMarks = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTest) return;

    const results = classStudents.map((s) => ({
      studentId: s.id,
      studentName: s.name,
      rollNo: s.rollNo,
      marksObtained: Number(marksMap[s.id]?.marks ?? 0),
      remarks: marksMap[s.id]?.remarks || '',
    }));

    // Validation
    for (const r of results) {
      if (r.marksObtained < 0 || r.marksObtained > selectedTest.totalMarks) {
        alert(`Marks for ${r.studentName} must be between 0 and ${selectedTest.totalMarks}.`);
        return;
      }
    }

    try {
      await api.tests.saveMarks(selectedTest.id, results);
      alert('Assessment marks saved successfully.');
      setShowMarksModal(false);
      loadTests();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    }
  };

  const handleCreateTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testForm.title || !testForm.subject) {
      alert('Title and subject are required.');
      return;
    }

    try {
      const res = await api.tests.create(testForm);
      alert('Assessment test created successfully.');
      setShowCreateModal(false);
      loadTests();
      setSelectedTest(res.test);
    } catch (err: any) {
      alert(`Failed to create test: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <FileSpreadsheet className="w-6 h-6 text-amber-400" />
            Tests, Exams & Academic Results
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Conduct monthly assessments, enter marks, calculate grades, and generate official result cards
          </p>
        </div>

        <div className="flex items-center gap-2">
          {currentUser.role !== 'attendance_operator' && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create New Assessment</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Results</span>
          </button>
        </div>
      </div>

      {/* Tests Selection Deck */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {tests.map((test) => {
          const isSelected = selectedTest?.id === test.id;
          return (
            <div
              key={test.id}
              onClick={() => setSelectedTest(test)}
              className={`p-4 rounded-2xl border cursor-pointer transition shadow-md ${
                isSelected
                  ? 'bg-blue-950/60 border-blue-500 text-white'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 font-mono">
                  {test.id} • Class {test.className}
                </span>
                <span className="text-xs font-semibold text-slate-400">{test.date}</span>
              </div>
              <h3 className="font-bold text-sm text-white mt-1.5">{test.title}</h3>
              <p className="text-xs text-slate-300 mt-0.5">Subject: <strong>{test.subject}</strong></p>

              <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                <span>Max Marks: <strong>{test.totalMarks}</strong></span>
                <span className="text-emerald-400">Pass: {test.passingMarks}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Test Results Sheet */}
      {selectedTest && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">{selectedTest.title}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                  Class {selectedTest.className}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Subject: <strong>{selectedTest.subject}</strong> • Total Marks: <strong>{selectedTest.totalMarks}</strong> • Passing Marks: <strong>{selectedTest.passingMarks}</strong>
              </p>
              {selectedTest.instructions && (
                <p className="text-[11px] text-slate-500 italic mt-0.5">Note: {selectedTest.instructions}</p>
              )}
            </div>

            {currentUser.role !== 'attendance_operator' && (
              <button
                onClick={() => handleOpenMarksEntry(selectedTest)}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow-sm"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Enter / Edit Marks</span>
              </button>
            )}
          </div>

          {/* Results Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                  <th className="p-3 text-center">Roll #</th>
                  <th className="p-3">Student Name</th>
                  <th className="p-3 text-center">Marks Obtained</th>
                  <th className="p-3 text-center">Percentage</th>
                  <th className="p-3 text-center">Grade</th>
                  <th className="p-3">Teacher Remarks</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {selectedTest.results.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      No marks recorded yet for this test. Click "Enter / Edit Marks" to add results.
                    </td>
                  </tr>
                ) : (
                  selectedTest.results.map((res, index) => {
                    const percentage = Math.round((res.marksObtained / selectedTest.totalMarks) * 100);
                    const gradeInfo = calculateGrade(percentage);
                    const isPassed = res.marksObtained >= selectedTest.passingMarks;

                    return (
                      <tr key={index} className="hover:bg-slate-800/40 transition">
                        <td className="p-3 text-center font-mono font-bold text-amber-400">
                          {res.rollNo}
                        </td>
                        <td className="p-3 font-bold text-white">
                          {res.studentName}
                        </td>
                        <td className="p-3 text-center font-mono font-black text-sm text-blue-300">
                          {res.marksObtained} / {selectedTest.totalMarks}
                        </td>
                        <td className="p-3 text-center font-mono font-bold text-emerald-400">
                          {percentage}%
                        </td>
                        <td className="p-3 text-center font-bold">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              isPassed
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            }`}
                          >
                            {gradeInfo.grade.split(' ')[0]}
                          </span>
                        </td>
                        <td className="p-3 text-slate-400 italic">
                          {res.remarks || gradeInfo.remarks}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => onPrintResultCard(selectedTest, res)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white font-bold transition text-xs"
                            >
                              <Award className="w-3.5 h-3.5" />
                              Result Card
                            </button>

                            <button
                              onClick={() => {
                                const msg = WhatsAppTemplates.examResult(
                                  res.studentName,
                                  selectedTest.className,
                                  selectedTest.title,
                                  selectedTest.subject,
                                  res.marksObtained,
                                  selectedTest.totalMarks,
                                  percentage
                                );
                                openWhatsAppChat('0345-6898969', msg);
                              }}
                              title="Share result via WhatsApp"
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 transition"
                            >
                              <Phone className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: CREATE TEST ----------------- */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-blue-400" />
                Schedule Assessment Exam
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTest} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Test Title *</label>
                <input
                  type="text"
                  required
                  value={testForm.title}
                  onChange={(e) => setTestForm({ ...testForm, title: e.target.value })}
                  placeholder="e.g. Second Monthly Assessment"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Class</label>
                  <select
                    value={testForm.className}
                    onChange={(e) => setTestForm({ ...testForm, className: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="6th">Class 6th</option>
                    <option value="7th">Class 7th</option>
                    <option value="8th">Class 8th</option>
                    <option value="9th">Class 9th</option>
                    <option value="10th">Class 10th</option>
                    <option value="11th">Class 11th</option>
                    <option value="12th">Class 12th</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Subject *</label>
                  <input
                    type="text"
                    required
                    value={testForm.subject}
                    onChange={(e) => setTestForm({ ...testForm, subject: e.target.value })}
                    placeholder="e.g. Physics, Math"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Exam Date</label>
                  <input
                    type="date"
                    value={testForm.date}
                    onChange={(e) => setTestForm({ ...testForm, date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Total Marks</label>
                  <input
                    type="number"
                    value={testForm.totalMarks}
                    onChange={(e) => setTestForm({ ...testForm, totalMarks: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Syllabus / Instructions</label>
                <textarea
                  rows={2}
                  value={testForm.instructions}
                  onChange={(e) => setTestForm({ ...testForm, instructions: e.target.value })}
                  placeholder="e.g. Chapter 1 to 3, long questions & numericals."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
                >
                  Create Assessment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: MARKS ENTRY ----------------- */}
      {showMarksModal && selectedTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-black text-sm text-white">
                  Enter Marks: {selectedTest.title} (Class {selectedTest.className})
                </h3>
                <p className="text-[11px] text-slate-400">Total Marks: {selectedTest.totalMarks} • Passing: {selectedTest.passingMarks}</p>
              </div>
              <button onClick={() => setShowMarksModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMarks} className="mt-4 space-y-4">
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-800 pr-1">
                {classStudents.map((st) => (
                  <div key={st.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <p className="font-bold text-white">{st.name}</p>
                      <span className="text-[10px] text-slate-400 font-mono">Roll #{st.rollNo} • {st.id}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="w-24">
                        <input
                          type="number"
                          min={0}
                          max={selectedTest.totalMarks}
                          value={marksMap[st.id]?.marks ?? ''}
                          onChange={(e) =>
                            setMarksMap({
                              ...marksMap,
                              [st.id]: {
                                marks: Number(e.target.value),
                                remarks: marksMap[st.id]?.remarks || '',
                              },
                            })
                          }
                          placeholder="Marks"
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-center font-mono font-bold text-slate-100"
                        />
                      </div>

                      <div className="w-36">
                        <input
                          type="text"
                          value={marksMap[st.id]?.remarks ?? ''}
                          onChange={(e) =>
                            setMarksMap({
                              ...marksMap,
                              [st.id]: {
                                marks: marksMap[st.id]?.marks ?? 0,
                                remarks: e.target.value,
                              },
                            })
                          }
                          placeholder="Remark"
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-300"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setShowMarksModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  <Save className="w-4 h-4" />
                  Save Marks
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
