import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Printer,
  Download,
  Calendar,
  Filter,
  FileSpreadsheet,
  Receipt,
  Users,
  GraduationCap,
  CalendarCheck2,
  Award,
  Search,
} from 'lucide-react';
import { Student, FeeInvoice, FeePayment, Teacher, ExamTest, User } from '../types';
import { api } from '../services/api';

interface ReportsPageProps {
  currentUser: User;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ currentUser }) => {
  const [activeReport, setActiveReport] = useState<'fees' | 'outstanding' | 'attendance' | 'students' | 'results' | 'staff'>('fees');

  const [students, setStudents] = useState<Student[]>([]);
  const [invoices, setInvoices] = useState<FeeInvoice[]>([]);
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [tests, setTests] = useState<ExamTest[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [classFilter, setClassFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('2026-10-01');
  const [dateTo, setDateTo] = useState('2026-10-31');

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [stRes, invRes, payRes, tchRes, tstRes] = await Promise.all([
        api.students.getAll(),
        api.fees.getInvoices(),
        api.fees.getPayments(),
        api.teachers.getAll(),
        api.tests.getAll(),
      ]);

      setStudents(stRes.students);
      setInvoices(invRes.invoices);
      setPayments(payRes.payments);
      setTeachers(tchRes.teachers);
      setTests(tstRes.tests);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const handlePrintReport = () => {
    window.print();
  };

  const handleExportCSV = () => {
    let csv = '';
    if (activeReport === 'fees') {
      csv = 'Invoice No,Student Name,Class,Month,Net PKR,Paid PKR,Balance PKR,Status\n' +
        invoices.map((i) => `"${i.invoiceNo}","${i.studentName}","${i.className}","${i.month}",${i.netAmountPKR},${i.paidAmountPKR},${i.balancePKR},"${i.status}"`).join('\n');
    } else if (activeReport === 'outstanding') {
      csv = 'Student Name,Class,Due Month,Outstanding PKR,Status\n' +
        invoices.filter((i) => i.balancePKR > 0).map((i) => `"${i.studentName}","${i.className}","${i.month}",${i.balancePKR},"${i.status}"`).join('\n');
    } else if (activeReport === 'students') {
      csv = 'ID,Name,Father Name,Class,Roll,Phone,Monthly Fee PKR,Status\n' +
        students.map((s) => `"${s.id}","${s.name}","${s.fatherName}","${s.className}","${s.rollNo}","${s.guardianPhone}",${s.monthlyFeePKR},"${s.status}"`).join('\n');
    } else if (activeReport === 'staff') {
      csv = 'Staff ID,Name,Gender,Qualification,Salary PKR,Phone,Status\n' +
        teachers.map((t) => `"${t.id}","${t.name}","${t.gender}","${t.qualification}",${t.monthlySalaryPKR},"${t.phone}","${t.status}"`).join('\n');
    }

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ETA_Report_${activeReport}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredInvoices = invoices.filter((i) => !classFilter || i.className === classFilter);
  const outstandingInvoices = filteredInvoices.filter((i) => i.balancePKR > 0);
  const totalBilled = filteredInvoices.reduce((sum, i) => sum + i.netAmountPKR, 0);
  const totalCollected = filteredInvoices.reduce((sum, i) => sum + i.paidAmountPKR, 0);
  const totalDue = filteredInvoices.reduce((sum, i) => sum + i.balancePKR, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header bar */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <BarChart3 className="w-6 h-6 text-blue-400" />
            Academy Reports & Intelligence
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Financial revenue, outstanding fee ledgers, student admission lists, and assessment marks
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handlePrintReport}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Official Report</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="no-print flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800">
        {[
          { id: 'fees', label: 'Monthly Fee Ledger (PKR)', icon: Receipt },
          { id: 'outstanding', label: 'Outstanding Dues Report', icon: FileSpreadsheet },
          { id: 'students', label: 'Class-wise Student List', icon: GraduationCap },
          { id: 'results', label: 'Exam Results Summary', icon: Award },
          { id: 'staff', label: 'Faculty & Payroll Directory', icon: Users },
        ].map((tab) => {
          const isActive = activeReport === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveReport(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                isActive ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter toolbar */}
      <div className="no-print p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">Filter by Class</label>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200"
            >
              <option value="">All Classes (6th-12th)</option>
              {['6th', '7th', '8th', '9th', '10th', '11th', '12th'].map((c) => (
                <option key={c} value={c}>Class {c}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">Date Period</label>
            <div className="flex items-center gap-2 text-xs">
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-slate-200"
              />
              <span className="text-slate-500">to</span>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-slate-200"
              />
            </div>
          </div>
        </div>

        <span className="text-xs text-slate-400 font-medium">
          The Excellent Tuition Academy • Khwazakhela, Swat
        </span>
      </div>

      {/* Printable Report Canvas */}
      <div className="printable-area rounded-3xl bg-white text-slate-950 p-6 sm:p-10 shadow-2xl border border-slate-200 print:border-none print:shadow-none print:p-0">
        
        {/* Formal Academy Header */}
        <div className="text-center pb-6 border-b-2 border-slate-900/20">
          <div className="flex items-center justify-center gap-3 mb-1">
            <div className="w-12 h-12 rounded-full bg-blue-950 text-amber-400 font-black text-xl flex items-center justify-center border-2 border-amber-400">
              ETA
            </div>
            <div className="text-left">
              <h1 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-blue-950">
                The Excellent Tuition Academy
              </h1>
              <p className="text-xs font-bold uppercase tracking-widest text-amber-600">
                Khwazakhela, Swat • Khyber Pakhtunkhwa, Pakistan
              </p>
            </div>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Mata Road, Khwazakhela | Principal: <strong>Mr. Rahmat Ali</strong> | Contact: <strong>0345-6898969</strong>
          </p>
          <div className="inline-block mt-3 px-4 py-1 rounded-md bg-blue-950 text-amber-300 font-extrabold text-xs uppercase tracking-wider">
            {activeReport === 'fees' && 'Comprehensive Monthly Fee Collection Report (PKR)'}
            {activeReport === 'outstanding' && 'Outstanding & Overdue Fee Balance Report (PKR)'}
            {activeReport === 'students' && 'Official Class-wise Student Enrollment Register'}
            {activeReport === 'results' && 'Academic Assessment Results & Performance Report'}
            {activeReport === 'staff' && 'Faculty & Teaching Staff Directory'}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">
            Report Generated on: {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>

        {/* 1. Monthly Fee Report */}
        {activeReport === 'fees' && (
          <div className="mt-6 space-y-4">
            <div className="grid grid-cols-3 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 block">Total Billed:</span>
                <span className="font-black text-base text-slate-900">Rs. {totalBilled.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Collected:</span>
                <span className="font-black text-base text-emerald-700">Rs. {totalCollected.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Outstanding:</span>
                <span className="font-black text-base text-rose-700">Rs. {totalDue.toLocaleString()} PKR</span>
              </div>
            </div>

            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-blue-950 text-white font-bold">
                  <th className="p-2.5">Inv #</th>
                  <th className="p-2.5">Student Name</th>
                  <th className="p-2.5 text-center">Class</th>
                  <th className="p-2.5 text-right">Fee (PKR)</th>
                  <th className="p-2.5 text-right">Paid (PKR)</th>
                  <th className="p-2.5 text-right">Balance</th>
                  <th className="p-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="p-2.5 font-mono font-semibold">{inv.invoiceNo}</td>
                    <td className="p-2.5 font-bold">{inv.studentName}</td>
                    <td className="p-2.5 text-center">{inv.className}</td>
                    <td className="p-2.5 text-right font-mono">Rs. {inv.netAmountPKR.toLocaleString()}</td>
                    <td className="p-2.5 text-right font-mono text-emerald-700 font-bold">Rs. {inv.paidAmountPKR.toLocaleString()}</td>
                    <td className="p-2.5 text-right font-mono font-bold text-rose-700">Rs. {inv.balancePKR.toLocaleString()}</td>
                    <td className="p-2.5 text-center uppercase font-bold text-[10px]">{inv.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 2. Outstanding Dues Report */}
        {activeReport === 'outstanding' && (
          <div className="mt-6 space-y-4">
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex justify-between items-center">
              <span>Total Defaulters / Pending Students: <strong>{outstandingInvoices.length}</strong></span>
              <span className="font-bold text-base font-mono">Total Due: Rs. {totalDue.toLocaleString()} PKR</span>
            </div>

            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-blue-950 text-white font-bold">
                  <th className="p-2.5">Student Name</th>
                  <th className="p-2.5 text-center">Class</th>
                  <th className="p-2.5">Month</th>
                  <th className="p-2.5 text-right">Outstanding (Rs. PKR)</th>
                  <th className="p-2.5 text-center">Due Date</th>
                  <th className="p-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {outstandingInvoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="p-2.5 font-bold">{inv.studentName}</td>
                    <td className="p-2.5 text-center">{inv.className}</td>
                    <td className="p-2.5">{inv.month}</td>
                    <td className="p-2.5 text-right font-mono font-black text-rose-700">
                      Rs. {inv.balancePKR.toLocaleString()} PKR
                    </td>
                    <td className="p-2.5 text-center font-mono">{inv.dueDate}</td>
                    <td className="p-2.5 text-center uppercase font-bold text-[10px] text-rose-700">{inv.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 3. Students List */}
        {activeReport === 'students' && (
          <div className="mt-6">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-blue-950 text-white font-bold">
                  <th className="p-2.5">ID</th>
                  <th className="p-2.5">Student Name</th>
                  <th className="p-2.5">Father's Name</th>
                  <th className="p-2.5 text-center">Class</th>
                  <th className="p-2.5 text-center">Roll #</th>
                  <th className="p-2.5">Guardian Contact</th>
                  <th className="p-2.5 text-right">Fee (PKR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {students
                  .filter((s) => !classFilter || s.className === classFilter)
                  .map((s) => (
                    <tr key={s.id}>
                      <td className="p-2.5 font-mono">{s.id}</td>
                      <td className="p-2.5 font-bold">{s.name}</td>
                      <td className="p-2.5">{s.fatherName}</td>
                      <td className="p-2.5 text-center font-semibold">{s.className} ({s.section})</td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-950">{s.rollNo}</td>
                      <td className="p-2.5 font-mono">{s.guardianPhone}</td>
                      <td className="p-2.5 text-right font-mono font-bold">Rs. {s.monthlyFeePKR}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. Staff Directory */}
        {activeReport === 'staff' && (
          <div className="mt-6">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-blue-950 text-white font-bold">
                  <th className="p-2.5">ID</th>
                  <th className="p-2.5">Instructor Name</th>
                  <th className="p-2.5">Qualification</th>
                  <th className="p-2.5">Subjects Assigned</th>
                  <th className="p-2.5">Classes</th>
                  <th className="p-2.5">Phone</th>
                  <th className="p-2.5 text-right">Monthly Salary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {teachers.map((t) => (
                  <tr key={t.id}>
                    <td className="p-2.5 font-mono">{t.id}</td>
                    <td className="p-2.5 font-bold">{t.name}</td>
                    <td className="p-2.5 font-semibold text-blue-900">{t.qualification}</td>
                    <td className="p-2.5">{t.subjects.join(', ')}</td>
                    <td className="p-2.5">{t.assignedClasses.join(', ')}</td>
                    <td className="p-2.5 font-mono">{t.phone}</td>
                    <td className="p-2.5 text-right font-mono font-bold text-emerald-800">
                      Rs. {t.monthlySalaryPKR.toLocaleString()} PKR
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Signatures for Print */}
        <div className="pt-12 mt-8 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs">
          <div>
            <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-slate-800">
              Accounts Officer
            </div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Prepared By</p>
          </div>
          <div>
            <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-blue-950">
              Mr. Rahmat Ali
            </div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Principal & Founder (ETA)</p>
          </div>
        </div>

      </div>

    </div>
  );
};
