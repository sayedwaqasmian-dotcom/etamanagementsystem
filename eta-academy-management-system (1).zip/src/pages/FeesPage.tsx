import React, { useState, useEffect } from 'react';
import {
  Receipt,
  Search,
  Filter,
  CreditCard,
  PlusCircle,
  Printer,
  Phone,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowUpRight,
  Send,
  Calendar,
  X,
  ShieldCheck,
  Download,
} from 'lucide-react';
import { FeeInvoice, FeePayment, User, Student } from '../types';
import { api } from '../services/api';
import { openWhatsAppChat, WhatsAppTemplates } from '../utils/whatsapp';

interface FeesPageProps {
  currentUser: User;
  onViewReceipt: (payment: FeePayment) => void;
  preselectedStudent?: Student | null;
}

export const FeesPage: React.FC<FeesPageProps> = ({
  currentUser,
  onViewReceipt,
  preselectedStudent,
}) => {
  const [invoices, setInvoices] = useState<FeeInvoice[]>([]);
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('October 2026');

  // Active view tab: Invoices vs Payment History
  const [activeSubTab, setActiveSubTab] = useState<'invoices' | 'payments'>('invoices');

  // Modals
  const [showCollectModal, setShowCollectModal] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<FeeInvoice | null>(null);

  // Payment Form
  const [payAmount, setPayAmount] = useState<number>(2500);
  const [payMethod, setPayMethod] = useState<'Cash' | 'Bank Transfer' | 'EasyPaisa' | 'JazzCash'>('Cash');
  const [payRemarks, setPayRemarks] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Month Generation Form
  const [genMonth, setGenMonth] = useState('November 2026');
  const [genDueDate, setGenDueDate] = useState('2026-11-10');

  const loadFeeData = async () => {
    setLoading(true);
    try {
      const [invRes, payRes] = await Promise.all([
        api.fees.getInvoices({
          classId: selectedClass,
          status: selectedStatus,
          month: selectedMonth,
        }),
        api.fees.getPayments(),
      ]);
      setInvoices(invRes.invoices);
      setPayments(payRes.payments);
    } catch (err: any) {
      console.error('Failed to load fee data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFeeData();
  }, [selectedClass, selectedStatus, selectedMonth]);

  const handleOpenCollect = (invoice: FeeInvoice) => {
    setSelectedInvoice(invoice);
    setPayAmount(invoice.balancePKR > 0 ? invoice.balancePKR : invoice.netAmountPKR);
    setPayRemarks(`Payment for ${invoice.month}`);
    setShowCollectModal(true);
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;
    if (payAmount <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.fees.recordPayment({
        invoiceId: selectedInvoice.id,
        amountPKR: payAmount,
        paymentMethod: payMethod,
        collectorName: currentUser.name,
        remarks: payRemarks,
      });

      setShowCollectModal(false);
      loadFeeData();
      // Directly trigger receipt preview
      onViewReceipt(res.payment);
    } catch (err: any) {
      alert(`Payment failed: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleGenerateInvoices = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.fees.generateMonthlyInvoices(genMonth, genDueDate);
      alert(res.message);
      setShowGenerateModal(false);
      setSelectedMonth(genMonth);
      loadFeeData();
    } catch (err: any) {
      alert(`Failed to generate invoices: ${err.message}`);
    }
  };

  // Filtered lists
  const filteredInvoices = invoices.filter((i) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      i.studentName.toLowerCase().includes(s) ||
      i.studentId.toLowerCase().includes(s) ||
      i.invoiceNo.toLowerCase().includes(s) ||
      i.className.toLowerCase().includes(s)
    );
  });

  const filteredPayments = payments.filter((p) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      p.studentName.toLowerCase().includes(s) ||
      p.studentId.toLowerCase().includes(s) ||
      p.receiptNo.toLowerCase().includes(s)
    );
  });

  // Aggregates
  const totalInvoicedPKR = invoices.reduce((sum, i) => sum + i.netAmountPKR, 0);
  const totalCollectedPKR = payments.reduce((sum, p) => sum + p.amountPKR, 0);
  const totalOutstandingPKR = invoices.reduce((sum, i) => sum + i.balancePKR, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Receipt className="w-6 h-6 text-emerald-400" />
            Fee Management — Pakistani Rupees (Rs. PKR)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Student fee invoicing, partial & full payment receipts, WhatsApp reminders, and ledger audit
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(currentUser.role === 'principal' || currentUser.role === 'accountant' || currentUser.role === 'admin') && (
            <button
              onClick={() => setShowGenerateModal(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
            >
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>Generate New Month Invoices</span>
            </button>
          )}

          <div className="flex rounded-xl bg-slate-900 border border-slate-800 p-1">
            <button
              onClick={() => setActiveSubTab('invoices')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeSubTab === 'invoices' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Fee Invoices ({invoices.length})
            </button>
            <button
              onClick={() => setActiveSubTab('payments')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeSubTab === 'payments' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Payments & Receipts ({payments.length})
            </button>
          </div>
        </div>
      </div>

      {/* Financial Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Invoiced ({selectedMonth})</span>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xs font-bold text-amber-400">Rs.</span>
            <span className="text-2xl font-black text-white">{totalInvoicedPKR.toLocaleString()}</span>
            <span className="text-xs font-mono text-slate-400">PKR</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Total student fees billed</p>
        </div>

        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Collected</span>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xs font-bold text-emerald-400">Rs.</span>
            <span className="text-2xl font-black text-emerald-400">{totalCollectedPKR.toLocaleString()}</span>
            <span className="text-xs font-mono text-slate-400">PKR</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Verified bank, cash & mobile receipts</p>
        </div>

        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Outstanding Balance</span>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xs font-bold text-rose-400">Rs.</span>
            <span className="text-2xl font-black text-rose-400">{totalOutstandingPKR.toLocaleString()}</span>
            <span className="text-xs font-mono text-slate-400">PKR</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Awaiting parent clearance</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search invoice #, student name, ID..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Month Selector */}
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
          >
            <option value="October 2026">October 2026</option>
            <option value="November 2026">November 2026</option>
            <option value="September 2026">September 2026</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
          >
            <option value="">All Statuses</option>
            <option value="paid">Paid</option>
            <option value="partial">Partial</option>
            <option value="unpaid">Unpaid</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Main Table: Invoices View */}
      {activeSubTab === 'invoices' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                  <th className="p-3.5">Invoice #</th>
                  <th className="p-3.5">Student Details</th>
                  <th className="p-3.5 text-center">Class</th>
                  <th className="p-3.5">Fee Amount (PKR)</th>
                  <th className="p-3.5 text-emerald-400">Paid (PKR)</th>
                  <th className="p-3.5 text-rose-400">Remaining Balance</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      Loading fee invoices...
                    </td>
                  </tr>
                ) : filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      No invoices found for this selection.
                    </td>
                  </tr>
                ) : (
                  filteredInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 font-mono font-bold text-blue-400">
                        {inv.invoiceNo}
                      </td>

                      <td className="p-3.5">
                        <p className="font-bold text-white">{inv.studentName}</p>
                        <p className="font-mono text-[10px] text-slate-400">{inv.studentId}</p>
                      </td>

                      <td className="p-3.5 text-center">
                        <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-bold">
                          {inv.className}
                        </span>
                      </td>

                      <td className="p-3.5 font-mono font-bold text-white">
                        Rs. {inv.netAmountPKR.toLocaleString()}
                        {inv.discountPKR > 0 && (
                          <span className="block text-[10px] text-emerald-400 font-normal">
                            (-Rs. {inv.discountPKR} conc.)
                          </span>
                        )}
                      </td>

                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        Rs. {inv.paidAmountPKR.toLocaleString()}
                      </td>

                      <td className="p-3.5 font-mono font-bold">
                        <span className={inv.balancePKR > 0 ? 'text-rose-400' : 'text-slate-400'}>
                          Rs. {inv.balancePKR.toLocaleString()}
                        </span>
                      </td>

                      <td className="p-3.5 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            inv.status === 'paid'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : inv.status === 'partial'
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>

                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {inv.balancePKR > 0 && (
                            <>
                              <button
                                onClick={() => handleOpenCollect(inv)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition"
                              >
                                <CreditCard className="w-3.5 h-3.5" />
                                Collect
                              </button>

                              {/* WhatsApp Reminder Button */}
                              <button
                                onClick={() => {
                                  const text = WhatsAppTemplates.feeReminder(
                                    inv.studentName,
                                    inv.className,
                                    inv.month,
                                    inv.balancePKR,
                                    inv.dueDate
                                  );
                                  openWhatsAppChat('0345-6898969', text);
                                }}
                                title="Send WhatsApp Fee Reminder"
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 transition"
                              >
                                <Phone className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}

                          {inv.status === 'paid' && (
                            <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Settled
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Main Table: Payment Receipts History */}
      {activeSubTab === 'payments' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                  <th className="p-3.5">Receipt #</th>
                  <th className="p-3.5">Student Name</th>
                  <th className="p-3.5">Amount (PKR)</th>
                  <th className="p-3.5">Payment Method</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Collector</th>
                  <th className="p-3.5">Remarks</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {filteredPayments.map((pay) => (
                  <tr key={pay.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3.5 font-mono font-bold text-amber-400">
                      {pay.receiptNo}
                    </td>
                    <td className="p-3.5 font-bold text-white">
                      {pay.studentName}
                    </td>
                    <td className="p-3.5 font-mono font-black text-emerald-400">
                      Rs. {pay.amountPKR.toLocaleString()} PKR
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-semibold">
                        {pay.paymentMethod}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-300 font-mono">{pay.paymentDate}</td>
                    <td className="p-3.5 text-slate-400">{pay.collectorName}</td>
                    <td className="p-3.5 text-slate-400 italic">{pay.remarks || '-'}</td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => onViewReceipt(pay)}
                        className="flex items-center gap-1 ml-auto px-2.5 py-1 rounded-lg bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white font-bold transition text-xs"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        Print Receipt
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: COLLECT FEE ----------------- */}
      {showCollectModal && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-base text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-400" />
                Record Fee Payment (PKR)
              </h3>
              <button onClick={() => setShowCollectModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 my-3 text-xs space-y-1">
              <p className="font-bold text-white text-sm">{selectedInvoice.studentName}</p>
              <p className="text-slate-400">Class {selectedInvoice.className} • Inv #{selectedInvoice.invoiceNo}</p>
              <div className="flex justify-between pt-2 border-t border-slate-800 font-mono">
                <span className="text-slate-400">Outstanding Balance:</span>
                <span className="font-bold text-rose-400">Rs. {selectedInvoice.balancePKR.toLocaleString()} PKR</span>
              </div>
            </div>

            <form onSubmit={handleProcessPayment} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Amount Received (Rs. PKR) *
                </label>
                <input
                  type="number"
                  required
                  max={selectedInvoice.balancePKR}
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono font-bold text-sm focus:outline-hidden focus:border-emerald-500"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Support full or partial payments. Cannot exceed remaining balance.
                </span>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Payment Method *</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-emerald-500"
                >
                  <option value="Cash">Cash (Accounts Counter)</option>
                  <option value="EasyPaisa">EasyPaisa (0345-6898969)</option>
                  <option value="JazzCash">JazzCash</option>
                  <option value="Bank Transfer">Bank Transfer (HBL / Allied Bank Swat)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Remarks / Transaction Note</label>
                <input
                  type="text"
                  value={payRemarks}
                  onChange={(e) => setPayRemarks(e.target.value)}
                  placeholder="e.g. Paid in full for October session"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCollectModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm & Print Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: GENERATE INVOICES ----------------- */}
      {showGenerateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                Generate Monthly Fee Invoices
              </h3>
              <button onClick={() => setShowGenerateModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleGenerateInvoices} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Billing Month & Year</label>
                <input
                  type="text"
                  required
                  value={genMonth}
                  onChange={(e) => setGenMonth(e.target.value)}
                  placeholder="e.g. November 2026"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Due Date</label>
                <input
                  type="date"
                  required
                  value={genDueDate}
                  onChange={(e) => setGenDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                This will automatically generate invoices for all active students according to their class monthly fee and individual scholarships. Duplicate invoices are prevented.
              </p>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowGenerateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
                >
                  Generate Invoices
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
