import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  PlusCircle,
  Award,
  Sparkles,
  HelpCircle,
  Send,
  UserCheck,
  ShieldCheck,
  X,
} from 'lucide-react';
import { McqTest, McqAttempt, User } from '../types';
import { api } from '../services/api';

interface EteaPageProps {
  currentUser: User;
}

export const EteaPage: React.FC<EteaPageProps> = ({ currentUser }) => {
  const [tests, setTests] = useState<McqTest[]>([]);
  const [loading, setLoading] = useState(true);

  // Active testing state
  const [activeTest, setActiveTest] = useState<McqTest | null>(null);
  const [studentName, setStudentName] = useState(currentUser.name);
  const [studentRollNo, setStudentRollNo] = useState('12');
  const [testStarted, setTestStarted] = useState(false);
  const [currentQIndex, setCurrentQIndex] = useState(0);

  // Student Answers: questionId -> selectedOptionIndex (0, 1, 2, 3)
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [reviewMarked, setReviewMarked] = useState<Record<string, boolean>>({});

  // Countdown timer in seconds
  const [timeLeft, setTimeLeft] = useState(0);

  // Completed Attempt Result
  const [attemptResult, setAttemptResult] = useState<McqAttempt | null>(null);
  const [submitted, setSubmitted] = useState(false);

  // New MCQ Test Modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('Chemistry');
  const [newClass, setNewClass] = useState('12th');
  const [newDuration, setNewDuration] = useState(15);
  const [newQuestionsText, setNewQuestionsText] = useState('');

  const loadTests = async () => {
    setLoading(true);
    try {
      const res = await api.etea.getTests();
      setTests(res.tests);
    } catch (err: any) {
      console.error('Failed to load ETEA tests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTests();
  }, []);

  // Timer effect
  useEffect(() => {
    if (!testStarted || submitted || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitTest(true); // Auto-submit on timeout
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [testStarted, submitted, timeLeft]);

  const handleStartTest = (test: McqTest) => {
    setActiveTest(test);
    setSelectedAnswers({});
    setReviewMarked({});
    setCurrentQIndex(0);
    setAttemptResult(null);
    setSubmitted(false);
    setTimeLeft(test.durationMinutes * 60);
    setTestStarted(true);
  };

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    if (submitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIdx,
    }));
  };

  const handleToggleReview = (questionId: string) => {
    setReviewMarked((prev) => ({
      ...prev,
      [questionId]: !prev[questionId],
    }));
  };

  const handleSubmitTest = async (isTimeout = false) => {
    if (!activeTest || submitted) return;

    if (!isTimeout) {
      const totalQ = activeTest.questions.length;
      const answeredQ = Object.keys(selectedAnswers).length;
      if (answeredQ < totalQ) {
        if (!confirm(`You answered ${answeredQ} of ${totalQ} questions. Submit now?`)) {
          return;
        }
      } else {
        if (!confirm('Confirm final submission? This cannot be undone.')) {
          return;
        }
      }
    }

    try {
      const answersPayload = activeTest.questions.map((q) => ({
        questionId: q.id,
        selectedOptionIndex: selectedAnswers[q.id] ?? -1,
      }));

      const res = await api.etea.submitAttempt(activeTest.id, {
        studentId: currentUser.id,
        studentName: studentName || currentUser.name,
        rollNo: studentRollNo,
        answers: answersPayload,
      });

      setAttemptResult(res.attempt);
      setSubmitted(true);
    } catch (err: any) {
      alert(`Submission failed: ${err.message}`);
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleCreateTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newQuestionsText.trim()) {
      alert('Title and questions are required.');
      return;
    }

    // Parse simple question format:
    // Q: What is X?
    // A) Opt1
    // B) Opt2
    // C) Opt3
    // D) Opt4
    // Ans: B
    // Exp: Explanation
    const rawBlocks = newQuestionsText.split('---').map((b) => b.trim()).filter(Boolean);
    const questions: any[] = [];

    rawBlocks.forEach((block, idx) => {
      const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
      let qText = `Question ${idx + 1}`;
      const options: string[] = [];
      let correctIdx = 0;
      let exp = 'Explanation verified.';

      lines.forEach((line) => {
        if (line.startsWith('Q:')) qText = line.replace('Q:', '').trim();
        else if (line.match(/^[A-D]\)/i)) options.push(line.substring(2).trim());
        else if (line.startsWith('Ans:')) {
          const letter = line.replace('Ans:', '').trim().toUpperCase();
          if (letter === 'A') correctIdx = 0;
          if (letter === 'B') correctIdx = 1;
          if (letter === 'C') correctIdx = 2;
          if (letter === 'D') correctIdx = 3;
        } else if (line.startsWith('Exp:')) exp = line.replace('Exp:', '').trim();
      });

      if (options.length >= 2) {
        questions.push({
          id: `Q${idx + 1}`,
          question: qText,
          options,
          correctOptionIndex: correctIdx,
          explanation: exp,
          marks: 4,
        });
      }
    });

    if (questions.length === 0) {
      alert('Could not parse questions. Ensure questions have options A), B), C), D) and Ans:');
      return;
    }

    try {
      await api.etea.createTest({
        title: newTitle,
        subject: newSubject,
        className: newClass,
        durationMinutes: newDuration,
        questions,
      });
      alert('ETEA MCQ practice test created successfully!');
      setShowCreateModal(false);
      loadTests();
    } catch (err: any) {
      alert(`Failed: ${err.message}`);
    }
  };

  // If in active test taking mode
  if (testStarted && activeTest) {
    const q = activeTest.questions[currentQIndex];
    const totalQ = activeTest.questions.length;
    const answeredCount = Object.keys(selectedAnswers).length;

    return (
      <div className="space-y-6 max-w-4xl mx-auto pb-12">
        
        {/* Test Engine Header Bar */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500 text-slate-950">
                ETEA Simulator
              </span>
              <h2 className="font-extrabold text-white text-sm sm:text-base">{activeTest.title}</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Candidate: <strong>{studentName}</strong> (Roll #{studentRollNo}) • Class {activeTest.className} ({activeTest.subject})
            </p>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-black text-base border ${
              timeLeft < 180
                ? 'bg-rose-500/20 text-rose-400 border-rose-500 animate-pulse'
                : 'bg-slate-950 text-amber-400 border-slate-700'
            }`}>
              <Clock className="w-4 h-4" />
              <span>{formatTimer(timeLeft)}</span>
            </div>

            {!submitted && (
              <button
                onClick={() => handleSubmitTest(false)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition"
              >
                Submit Test
              </button>
            )}
          </div>
        </div>

        {/* If submitted, show result screen */}
        {submitted && attemptResult ? (
          <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl text-slate-100 space-y-6">
            <div className="text-center pb-6 border-b border-slate-800">
              <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 mx-auto flex items-center justify-center font-black text-2xl border border-amber-500/40 mb-3">
                <Award className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-black text-white">ETEA Assessment Result</h2>
              <p className="text-xs text-slate-400 mt-1">
                The Excellent Tuition Academy Khwazakhela (ETA) Swat
              </p>

              <div className="mt-4 flex items-center justify-center gap-6">
                <div>
                  <span className="text-[11px] text-slate-400 uppercase block">Obtained Score</span>
                  <span className="text-3xl font-black text-amber-400 font-mono">
                    {attemptResult.score} / {attemptResult.totalMarks}
                  </span>
                </div>
                <div className="w-px h-12 bg-slate-800"></div>
                <div>
                  <span className="text-[11px] text-slate-400 uppercase block">Percentage</span>
                  <span className="text-3xl font-black text-emerald-400 font-mono">
                    {attemptResult.percentage}%
                  </span>
                </div>
              </div>
            </div>

            {/* Answer Key & Explanation Review */}
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Detailed Question-by-Question Review
              </h3>

              <div className="space-y-3">
                {activeTest.questions.map((qItem, idx) => {
                  const studentAns = attemptResult.answers.find((a) => a.questionId === qItem.id);
                  const selectedIdx = studentAns?.selectedOptionIndex ?? -1;
                  const isCorrect = selectedIdx === qItem.correctOptionIndex;

                  return (
                    <div
                      key={qItem.id}
                      className={`p-4 rounded-2xl border text-xs leading-relaxed ${
                        isCorrect
                          ? 'bg-emerald-950/20 border-emerald-500/30'
                          : 'bg-rose-950/20 border-rose-500/30'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <span className="font-bold text-slate-200">
                          Q{idx + 1}. {qItem.question}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                            isCorrect ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {isCorrect ? '+4 Marks (Correct)' : '0 Marks (Incorrect)'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-2">
                        {qItem.options.map((opt, oIdx) => {
                          const isPicked = selectedIdx === oIdx;
                          const isRight = qItem.correctOptionIndex === oIdx;

                          let badgeStyle = 'bg-slate-900 border-slate-800 text-slate-300';
                          if (isRight) badgeStyle = 'bg-emerald-600/30 border-emerald-500 text-emerald-200 font-bold';
                          else if (isPicked && !isRight) badgeStyle = 'bg-rose-600/30 border-rose-500 text-rose-200 line-through';

                          return (
                            <div key={oIdx} className={`p-2 rounded-xl border flex items-center gap-2 ${badgeStyle}`}>
                              <span className="w-5 h-5 rounded-md bg-slate-950/60 font-mono text-[10px] flex items-center justify-center">
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <span>{opt}</span>
                            </div>
                          );
                        })}
                      </div>

                      {qItem.explanation && (
                        <div className="mt-2 p-2 rounded-lg bg-slate-950/80 text-[11px] text-slate-300 border border-slate-800">
                          <strong className="text-amber-400">Explanation:</strong> {qItem.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-between items-center">
              <button
                onClick={() => setTestStarted(false)}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
              >
                Back to Tests Directory
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs"
              >
                Print Result Report
              </button>
            </div>
          </div>
        ) : (
          /* Live Question Card */
          <div className="space-y-5">
            {/* Question Card */}
            <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl text-slate-100">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <span className="font-bold text-amber-400">
                  Question {currentQIndex + 1} of {totalQ}
                </span>
                <span className="text-slate-400">
                  Answered: <strong>{answeredCount}</strong> / {totalQ}
                </span>
              </div>

              <div className="mt-4">
                <p className="text-base sm:text-lg font-bold text-white leading-relaxed">
                  {q.question}
                </p>
              </div>

              {/* Options */}
              <div className="mt-6 space-y-2.5">
                {q.options.map((option, idx) => {
                  const isSelected = selectedAnswers[q.id] === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectOption(q.id, idx)}
                      className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border text-left text-xs sm:text-sm font-medium transition ${
                        isSelected
                          ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                          isSelected ? 'bg-white text-blue-900' : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {String.fromCharCode(65 + idx)}
                      </div>
                      <span className="flex-1 leading-snug">{option}</span>
                    </button>
                  );
                })}
              </div>

              {/* Navigation & Question Control */}
              <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setCurrentQIndex((prev) => Math.max(0, prev - 1))}
                  disabled={currentQIndex === 0}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleReview(q.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition ${
                    reviewMarked[q.id]
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  {reviewMarked[q.id] ? '★ Marked for Review' : '☆ Mark for Review'}
                </button>

                {currentQIndex < totalQ - 1 ? (
                  <button
                    type="button"
                    onClick={() => setCurrentQIndex((prev) => Math.min(totalQ - 1, prev + 1))}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/20"
                  >
                    <span>Save & Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleSubmitTest(false)}
                    className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-md shadow-emerald-600/20"
                  >
                    <span>Final Submit</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Question Quick Palette */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-2">
                Question Palette
              </span>
              <div className="flex flex-wrap gap-2">
                {activeTest.questions.map((qItem, idx) => {
                  const isAnswered = selectedAnswers[qItem.id] !== undefined;
                  const isCurrent = currentQIndex === idx;
                  const isMarked = reviewMarked[qItem.id];

                  let color = 'bg-slate-950 text-slate-400 border-slate-800';
                  if (isCurrent) color = 'ring-2 ring-blue-500 bg-blue-600 text-white';
                  else if (isMarked) color = 'bg-amber-500/20 text-amber-300 border-amber-500';
                  else if (isAnswered) color = 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40';

                  return (
                    <button
                      key={qItem.id}
                      onClick={() => setCurrentQIndex(idx)}
                      className={`w-8 h-8 rounded-xl border text-xs font-mono font-bold flex items-center justify-center transition ${color}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

      </div>
    );
  }

  // Tests Directory Screen
  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <BrainCircuit className="w-6 h-6 text-amber-400" />
            ETEA & Board MCQ Practice Simulator
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            MDCAT & Engineering entrance mock examinations with timer, negative marking options and instant explanations
          </p>
        </div>

        {currentUser.role !== 'attendance_operator' && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add New ETEA Test</span>
          </button>
        )}
      </div>

      {/* Available Tests Deck */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {loading ? (
          <div className="col-span-2 p-8 text-center text-slate-400 text-xs">
            Loading ETEA tests...
          </div>
        ) : tests.map((test) => (
          <div
            key={test.id}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl flex flex-col justify-between hover:border-blue-500/40 transition"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  Class {test.className} • {test.subject}
                </span>
                <span className="flex items-center gap-1 text-xs text-slate-400 font-mono">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  {test.durationMinutes} mins
                </span>
              </div>

              <h3 className="text-base font-extrabold text-white mt-3">{test.title}</h3>
              <p className="text-xs text-slate-400 mt-1">
                Total Questions: <strong>{test.questions.length} MCQs</strong> • Total Marks: <strong>{test.totalMarks}</strong>
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified Answer Keys
              </span>

              <button
                onClick={() => handleStartTest(test)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-md shadow-amber-500/10 transition"
              >
                Start Practice Exam →
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ----------------- MODAL: CREATE ETEA TEST ----------------- */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-amber-400" />
                Add New ETEA Practice Test
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTest} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-400 mb-1 font-semibold">Test Title *</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. ETEA MDCAT Chemistry Mock"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Class</label>
                  <select
                    value={newClass}
                    onChange={(e) => setNewClass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="9th">Class 9th</option>
                    <option value="10th">Class 10th</option>
                    <option value="11th">Class 11th</option>
                    <option value="12th">Class 12th</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Subject</label>
                  <input
                    type="text"
                    required
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    placeholder="e.g. Biology, Physics"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Duration (Minutes)</label>
                  <input
                    type="number"
                    value={newDuration}
                    onChange={(e) => setNewDuration(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  MCQs Bank (Separate questions with '---')
                </label>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] text-amber-300 font-mono mb-1">
                  Q: What is the unit of Force?<br />
                  A) Joule<br />
                  B) Newton<br />
                  C) Watt<br />
                  D) Pascal<br />
                  Ans: B<br />
                  Exp: Newton is the SI unit of force.<br />
                  ---
                </div>
                <textarea
                  rows={8}
                  required
                  value={newQuestionsText}
                  onChange={(e) => setNewQuestionsText(e.target.value)}
                  placeholder="Paste questions here using format above..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-100"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save & Publish Test
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
