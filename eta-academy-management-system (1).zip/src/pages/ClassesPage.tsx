import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Users,
  Award,
  ArrowRight,
  TrendingUp,
  Layers,
  Sparkles,
  Edit,
  Save,
  CheckCircle,
  X,
} from 'lucide-react';
import { ClassItem, Student, User } from '../types';
import { api } from '../services/api';

interface ClassesPageProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const ClassesPage: React.FC<ClassesPageProps> = ({ currentUser, onNavigateTab }) => {
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  // Promotion Modal
  const [showPromoteModal, setShowPromoteModal] = useState(false);
  const [fromClass, setFromClass] = useState('CLS-09');
  const [toClass, setToClass] = useState('CLS-10');
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [promoting, setPromoting] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [classRes, stRes] = await Promise.all([
        api.classes.getAll(),
        api.students.getAll({ status: 'active' }),
      ]);
      setClasses(classRes.classes);
      setStudents(stRes.students);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenPromote = () => {
    // Select all students of fromClass by default
    const eligible = students.filter((s) => s.classId === fromClass || s.className === '9th').map((s) => s.id);
    setSelectedStudentIds(eligible);
    setShowPromoteModal(true);
  };

  const handlePromoteStudents = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedStudentIds.length === 0) {
      alert('Please select at least one student to promote.');
      return;
    }

    setPromoting(true);
    try {
      const res = await api.classes.promote(fromClass, toClass, selectedStudentIds);
      alert(res.message);
      setShowPromoteModal(false);
      loadData();
    } catch (err: any) {
      alert(`Promotion failed: ${err.message}`);
    } finally {
      setPromoting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <BookOpen className="w-6 h-6 text-blue-400" />
            Class & Section Management (6th to 12th)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Classes, sections, assigned curriculum subjects, fee structures, and academic promotion
          </p>
        </div>

        {(currentUser.role === 'principal' || currentUser.role === 'admin') && (
          <button
            onClick={handleOpenPromote}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow-sm"
          >
            <TrendingUp className="w-4 h-4" />
            <span>Promote Students to Next Class</span>
          </button>
        )}
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {classes.map((cls) => {
          const classStudents = students.filter((s) => s.classId === cls.id || s.className === cls.name);
          const totalFeeRevenue = classStudents.reduce((sum, s) => sum + s.monthlyFeePKR, 0);

          return (
            <div
              key={cls.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 font-black text-lg flex items-center justify-center border border-blue-500/30">
                      {cls.name}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-white text-base">Class {cls.name}</h3>
                      <p className="text-[11px] text-slate-400">Class In-charge: <strong>{cls.classTeacher || 'Assigned Faculty'}</strong></p>
                    </div>
                  </div>
                  <span className="text-xs font-black font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
                    Rs. {cls.monthlyFeePKR.toLocaleString()} PKR
                  </span>
                </div>

                <div className="mt-4 space-y-3 text-xs">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Enrolled Strength:</span>
                    <span className="font-bold text-white font-mono">{classStudents.length} Students</span>
                  </div>

                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Active Sections:</span>
                    <span className="font-semibold text-slate-200">{cls.sections.join(', ')}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block mb-1">Subjects Covered:</span>
                    <div className="flex flex-wrap gap-1">
                      {cls.subjects.map((sub, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded-md bg-slate-950 text-slate-300 text-[10px] border border-slate-800">
                          {sub}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Monthly Pot.: <strong>Rs. {totalFeeRevenue.toLocaleString()}</strong>
                </span>

                <button
                  onClick={() => onNavigateTab('students')}
                  className="text-xs font-bold text-blue-400 hover:underline flex items-center gap-1"
                >
                  View Students <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ----------------- MODAL: STUDENT PROMOTION ----------------- */}
      {showPromoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-amber-400" />
                Session Academic Promotion Workflow
              </h3>
              <button onClick={() => setShowPromoteModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePromoteStudents} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Current Class</label>
                  <select
                    value={fromClass}
                    onChange={(e) => {
                      setFromClass(e.target.value);
                      const matchingStudents = students.filter((s) => s.classId === e.target.value).map((s) => s.id);
                      setSelectedStudentIds(matchingStudents);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        Class {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Promote To Class</label>
                  <select
                    value={toClass}
                    onChange={(e) => setToClass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        Class {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Select Students to Promote ({selectedStudentIds.length} Selected)
                </label>
                <div className="max-h-56 overflow-y-auto rounded-xl bg-slate-950 border border-slate-800 p-2 space-y-1">
                  {students
                    .filter((s) => s.classId === fromClass)
                    .map((s) => {
                      const isChecked = selectedStudentIds.includes(s.id);
                      return (
                        <label key={s.id} className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedStudentIds([...selectedStudentIds, s.id]);
                              } else {
                                setSelectedStudentIds(selectedStudentIds.filter((id) => id !== s.id));
                              }
                            }}
                            className="rounded text-amber-500 focus:ring-0"
                          />
                          <span className="font-semibold text-white">{s.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono">(Roll #{s.rollNo})</span>
                        </label>
                      );
                    })}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                Promoting students updates their current active class while preserving all historical fee invoices, past attendance sessions, and previous exam marks.
              </p>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPromoteModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={promoting}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  {promoting ? 'Promoting...' : 'Confirm Promotion'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
