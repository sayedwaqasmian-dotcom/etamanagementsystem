import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  User as UserIcon,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  ShieldCheck,
  RefreshCw,
  Phone,
  ArrowRight,
  Info,
} from 'lucide-react';
import { api } from '../services/api';
import { ProposedAction, User } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  proposedAction?: ProposedAction | null;
  timestamp: string;
  mode?: 'GEMINI_AI' | 'LOCAL_RULE_BASED';
}

interface AiAssistantPageProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
  onRefreshData?: () => void;
}

export const AiAssistantPage: React.FC<AiAssistantPageProps> = ({
  currentUser,
  onNavigateTab,
  onRefreshData,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-msg',
      sender: 'assistant',
      text: `Assalam-o-Alaikum ${currentUser.name}! I am **ETA Smart Assistant**, dedicated AI system for The Excellent Tuition Academy Khwazakhela, Swat.\n\nI understand both **English** and **Roman Urdu**. What would you like to query or execute today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasGeminiKey, setHasGeminiKey] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const samplePrompts = [
    { label: 'Pending Fees List', text: 'Pending fees walay students ki list dikhao' },
    { label: 'Fee Collection', text: 'Is mahine kitni fees collect hui?' },
    { label: 'Today Attendance', text: 'Aaj attendance ka kya status hai?' },
    { label: 'Search Class 7', text: 'Class 7 ke students search karo' },
    { label: 'Admit Ahmad (7th)', text: 'Ahmad ko class 7 mein add kar do' },
    { label: 'Record Fee Rs. 2500', text: 'Rs. 2500 ki fee payment record karni hai' },
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      const res = await api.ai.sendMessage(textToSend, currentUser.role, currentUser.name);
      const botMsg: Message = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: res.reply,
        proposedAction: res.proposedAction,
        mode: res.mode,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: 'assistant',
          text: `Error processing query: ${err.message || 'Server communication issue'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteAction = async (msgId: string, action: ProposedAction) => {
    if (action.type === 'NAVIGATE' && action.params?.route) {
      const tab = action.params.route.replace('/', '');
      onNavigateTab(tab);
      return;
    }

    try {
      setLoading(true);
      const res = await api.ai.executeAction(action.type, action.params);

      setMessages((prev) =>
        prev.map((m) => (m.id === msgId ? { ...m, proposedAction: null } : m))
      );

      setMessages((prev) => [
        ...prev,
        {
          id: `msg-success-${Date.now()}`,
          sender: 'assistant',
          text: `Action executed successfully: ${res.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);

      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      alert(`Action failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto pb-12">
      
      {/* Title & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-amber-400" />
            ETA Smart Assistant
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Official Academy AI copilot supporting English & Roman Urdu with validated action previews
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-semibold">
            <ShieldCheck className="w-4 h-4" />
            Role Guarded: {currentUser.role}
          </span>
        </div>
      </div>

      {/* Main Chat Box Container */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col h-[650px] overflow-hidden">
        
        {/* Chat Banner Info */}
        <div className="p-3 bg-blue-950/40 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-blue-400" />
            <span>AI actions that create or alter financial records require your explicit confirmation.</span>
          </div>
          <span className="text-[11px] font-mono text-amber-400">Currency: Rs. PKR</span>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mb-1 px-1">
                {m.sender === 'user' ? (
                  <>
                    <span className="font-semibold text-slate-300">{currentUser.name}</span>
                    <UserIcon className="w-3.5 h-3.5 text-blue-400" />
                  </>
                ) : (
                  <>
                    <Bot className="w-3.5 h-3.5 text-amber-400" />
                    <span className="font-semibold text-amber-400">ETA Smart Assistant</span>
                    {m.mode && (
                      <span className="text-[9px] px-1 rounded bg-slate-800 text-slate-400 font-mono">
                        {m.mode === 'GEMINI_AI' ? 'Gemini 3.8 Flash' : 'Built-in Engine'}
                      </span>
                    )}
                  </>
                )}
                <span>• {m.timestamp}</span>
              </div>

              <div
                className={`max-w-[85%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-xs shadow-md'
                    : 'bg-slate-950 text-slate-100 rounded-tl-xs border border-slate-800 shadow-md whitespace-pre-wrap'
                }`}
              >
                {m.text}

                {/* Proposed Action Preview Card */}
                {m.proposedAction && (
                  <div className="mt-4 p-4 rounded-2xl bg-slate-900 border border-amber-500/40 text-slate-100 shadow-lg">
                    <div className="flex items-center gap-2 text-amber-400 font-bold text-xs mb-1">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>{m.proposedAction.title}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-normal">
                      {m.proposedAction.description}
                    </p>

                    {/* Parameters details */}
                    {m.proposedAction.params && (
                      <div className="mt-3 p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300 space-y-1">
                        {Object.entries(m.proposedAction.params).map(([k, v]) => (
                          <div key={k} className="flex justify-between">
                            <span className="text-slate-400">{k}:</span>
                            <span className="text-amber-300 font-bold">{String(v)}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Confirm Button Group */}
                    <div className="mt-4 flex items-center gap-2">
                      <button
                        onClick={() => handleExecuteAction(m.id, m.proposedAction!)}
                        disabled={loading}
                        className="flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition disabled:opacity-50 shadow-sm"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{m.proposedAction.type === 'NAVIGATE' ? 'Open Page' : 'Confirm & Save in Database'}</span>
                      </button>
                      <button
                        onClick={() => {
                          setMessages((prev) =>
                            prev.map((item) =>
                              item.id === m.id ? { ...item, proposedAction: null } : item
                            )
                          );
                        }}
                        className="py-2 px-3 rounded-xl bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold transition"
                      >
                        Dismiss
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2.5 text-xs text-amber-400 bg-slate-950 p-4 rounded-2xl max-w-[65%] border border-slate-800">
              <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
              <span>Analyzing academy records and formulating response...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Suggestion Chips */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/70 overflow-x-auto flex gap-2 no-scrollbar">
          {samplePrompts.map((item, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(item.text)}
              className="whitespace-nowrap px-3 py-1.5 rounded-full bg-slate-900 hover:bg-slate-800 text-xs text-slate-300 border border-slate-800 transition"
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Message Input Box */}
        <div className="p-4 border-t border-slate-800 bg-slate-950">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-3"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything in English or Roman Urdu ('Ahmad ko class 7 mein add kar do')..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition disabled:opacity-40 shadow-lg shadow-amber-500/20"
            >
              <span>Send</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
