import React, { useState } from 'react';
import {
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  CheckCircle2,
  Shield,
  Sparkles,
  Phone,
  MapPin,
  KeyRound,
  GraduationCap,
} from 'lucide-react';
import { api } from '../services/api';
import { User, UserRole } from '../types';

interface LoginPageProps {
  onLoginSuccess: (user: User) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('principal');
  const [password, setPassword] = useState('eta12345');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [forgotOpen, setForgotOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await api.auth.login(username, password);
      onLoginSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = (uname: string) => {
    setUsername(uname);
    setPassword('eta12345');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 text-slate-100 relative overflow-hidden">
      
      {/* Background Radial Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Main Login Card */}
      <div className="relative z-10 w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        
        {/* Crest & Title */}
        <div className="text-center">
          <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-slate-950 font-black text-2xl items-center justify-center shadow-xl shadow-amber-500/20 border-2 border-amber-300 mb-3">
            ETA
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
            The Excellent Tuition Academy
          </h1>
          <p className="text-xs font-bold uppercase tracking-widest text-amber-400 mt-1">
            Khwazakhela, Swat
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Quality Education | Brighter Future | Better Tomorrow
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold">
            {error}
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 mb-1.5 font-semibold">
              Username or Email
            </label>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username or email"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-slate-300 font-semibold">Password</label>
              <button
                type="button"
                onClick={() => setForgotOpen(true)}
                className="text-[11px] text-amber-400 hover:underline"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-10 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-slate-400 hover:text-slate-200 absolute right-3 top-1/2 -translate-y-1/2"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded text-amber-500 focus:ring-0 bg-slate-950 border-slate-700"
              />
              <span>Remember session</span>
            </label>
            <span className="text-[11px] font-mono text-emerald-400">PKR Mode</span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs sm:text-sm tracking-wide transition shadow-xl shadow-amber-500/20 disabled:opacity-50"
          >
            {loading ? 'Authenticating...' : 'Sign In to ETA Academy'}
          </button>
        </form>

        {/* Quick Demo Credentials for Fast Evaluation */}
        <div className="pt-4 border-t border-slate-800/80">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2 text-center">
            One-Click Role Demonstration
          </p>
          <div className="grid grid-cols-2 gap-1.5 text-[11px]">
            <button
              type="button"
              onClick={() => handleQuickLogin('principal')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition"
            >
              <span className="font-bold text-amber-400 block">👑 Principal</span>
              <span className="text-[10px] text-slate-400">Mr. Rahmat Ali</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('admin')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition"
            >
              <span className="font-bold text-blue-400 block">💼 Administrator</span>
              <span className="text-[10px] text-slate-400">Admin Desk</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('accountant')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition"
            >
              <span className="font-bold text-purple-400 block">💰 Accountant</span>
              <span className="text-[10px] text-slate-400">Fee Counter</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('teacher')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition"
            >
              <span className="font-bold text-emerald-400 block">👨‍🏫 Teacher</span>
              <span className="text-[10px] text-slate-400">Nouman Khan</span>
            </button>
          </div>
        </div>

        {/* Contact info footer */}
        <div className="pt-3 border-t border-slate-800/60 text-center text-[10px] text-slate-400 space-y-1">
          <p className="flex items-center justify-center gap-1">
            <MapPin className="w-3 h-3 text-amber-400" />
            Mata Road, Khwazakhela, Swat, KP, Pakistan
          </p>
          <p className="flex items-center justify-center gap-1 font-mono text-emerald-400">
            <Phone className="w-3 h-3" />
            0345-6898969 • wa.me/923456898969
          </p>
        </div>

      </div>

      {/* Forgot Password Dialog */}
      {forgotOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="font-extrabold text-sm text-white mb-2">Password Recovery</h3>
            <p className="text-slate-300 leading-relaxed mb-4">
              For security reasons, password resets are handled directly by the Principal (Mr. Rahmat Ali).
              <br /><br />
              Please contact the academy office via WhatsApp or call:
              <strong className="block text-emerald-400 text-sm mt-1 font-mono">0345-6898969</strong>
            </p>
            <button
              onClick={() => setForgotOpen(false)}
              className="w-full py-2 rounded-xl bg-amber-500 font-bold text-slate-950"
            >
              Close
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
