import React, { useState, useEffect } from 'react';
import {
  CalendarCheck2,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  Coffee,
  CheckCheck,
  Save,
  Printer,
  Phone,
  Search,
  Filter,
  Users,
  AlertCircle,
} from 'lucide-react';
import { Student, AttendanceRecord, User, ClassItem } from '../types';
import { api } from '../services/api';
import { openWhatsAppChat, WhatsAppTemplates } from '../utils/whatsapp';

interface AttendancePageProps {
  currentUser: User;
}

export const AttendancePage: React.FC<AttendancePageProps> = ({ currentUser }) => {
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('6th');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Status mapping for students: studentId -> 'present' | 'absent' | 'late' | 'leave'
  const [attendanceMap, setAttendanceMap] = useState<Record<string, 'present' | 'absent' | 'late' | 'leave'>>({});
  const [remarksMap, setRemarksMap] = useState<Record<string, string>>({});

  const loadData = async () => {
    setLoading(true);
    try {
      const [classRes, stRes, attRes] = await Promise.all([
        api.classes.getAll(),
        api.students.getAll({ classId: selectedClass, status: 'active' }),
        api.attendance.getSessions(selectedDate, selectedClass),
      ]);

      setClasses(classRes.classes);
      setStudents(stRes.students);

      // If existing session exists for this date and class, load it
      const existingSession = attRes.sessions?.[0];
      const initialMap: Record<string, 'present' | 'absent' | 'late' | 'leave'> = {};
      const initialRemarks: Record<string, string> = {};

      if (existingSession && existingSession.records?.length > 0) {
        existingSession.records.forEach((rec) => {
          initialMap[rec.studentId] = rec.status;
          if (rec.remarks) initialRemarks[rec.studentId] = rec.remarks;
        });
      } else {
        // Default: set all present
        stRes.students.forEach((s) => {
          initialMap[s.id] = 'present';
        });
      }

      setAttendanceMap(initialMap);
      setRemarksMap(initialRemarks);
    } catch (err: any) {
      console.error('Failed to load attendance:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedClass, selectedDate]);

  const handleSetStatus = (studentId: string, status: 'present' | 'absent' | 'late' | 'leave') => {
    setAttendanceMap((prev) => ({
      ...prev,
      [studentId]: status,
    }));
  };

  const handleMarkAllPresent = () => {
    const updated: Record<string, 'present' | 'absent' | 'late' | 'leave'> = {};
    students.forEach((s) => {
      updated[s.id] = 'present';
    });
    setAttendanceMap(updated);
  };

  const handleSaveAttendance = async () => {
    setSaving(true);
    try {
      const records = students.map((s) => ({
        studentId: s.id,
        studentName: s.name,
        rollNo: s.rollNo,
        status: attendanceMap[s.id] || 'present',
        remarks: remarksMap[s.id] || '',
      }));

      await api.attendance.saveAttendance({
        date: selectedDate,
        classId: selectedClass,
        className: selectedClass,
        section: 'A',
        records,
        recordedBy: currentUser.name,
      });

      alert(`Attendance saved successfully for Class ${selectedClass} on ${selectedDate}.`);
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  // Stats calculation
  const total = students.length;
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let leaveCount = 0;

  students.forEach((s) => {
    const st = attendanceMap[s.id] || 'present';
    if (st === 'present') presentCount++;
    else if (st === 'absent') absentCount++;
    else if (st === 'late') lateCount++;
    else if (st === 'leave') leaveCount++;
  });

  const percentage = total > 0 ? Math.round((presentCount / total) * 100) : 0;

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <CalendarCheck2 className="w-6 h-6 text-emerald-400" />
            Daily Student Attendance
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Mark attendance for Classes 6th to 12th, send parent WhatsApp absence notifications and print daily register
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Sheet</span>
          </button>

          <button
            onClick={handleSaveAttendance}
            disabled={saving || students.length === 0}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-sm disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Attendance'}</span>
          </button>
        </div>
      </div>

      {/* Control & Date Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Class Select */}
          <div>
            <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">Select Class</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-100 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="6th">Class 6th</option>
              <option value="7th">Class 7th</option>
              <option value="8th">Class 8th</option>
              <option value="9th">Class 9th</option>
              <option value="10th">Class 10th</option>
              <option value="11th">Class 11th</option>
              <option value="12th">Class 12th</option>
            </select>
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">Attendance Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-100 focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Quick Batch Action */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={handleMarkAllPresent}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 text-xs font-bold border border-blue-500/30 transition"
          >
            <CheckCheck className="w-4 h-4 text-blue-400" />
            <span>Mark All Present</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Total Enrolled</span>
          <p className="text-xl font-black text-white mt-1">{total}</p>
        </div>
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-center">
          <span className="text-[10px] font-bold text-emerald-400 uppercase">Present</span>
          <p className="text-xl font-black text-emerald-400 mt-1">{presentCount}</p>
        </div>
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-center">
          <span className="text-[10px] font-bold text-rose-400 uppercase">Absent</span>
          <p className="text-xl font-black text-rose-400 mt-1">{absentCount}</p>
        </div>
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-center">
          <span className="text-[10px] font-bold text-amber-400 uppercase">Late</span>
          <p className="text-xl font-black text-amber-400 mt-1">{lateCount}</p>
        </div>
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 text-center col-span-2 sm:col-span-1">
          <span className="text-[10px] font-bold text-blue-400 uppercase">Present Rate</span>
          <p className="text-xl font-black text-blue-400 mt-1">{percentage}%</p>
        </div>
      </div>

      {/* Attendance Register Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                <th className="p-3.5 text-center">Roll #</th>
                <th className="p-3.5">Student Name</th>
                <th className="p-3.5">Father Name</th>
                <th className="p-3.5 text-center">Attendance Status</th>
                <th className="p-3.5">Remarks / Reason</th>
                <th className="p-3.5 text-right">Parent WhatsApp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    Loading student list...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No active students enrolled in Class {selectedClass}.
                  </td>
                </tr>
              ) : (
                students.map((st) => {
                  const currentStatus = attendanceMap[st.id] || 'present';

                  return (
                    <tr key={st.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 text-center font-mono font-bold text-amber-400">
                        {st.rollNo}
                      </td>

                      <td className="p-3.5 font-bold text-white">
                        {st.name}
                        <span className="block font-mono text-[10px] text-slate-400 font-normal">{st.id}</span>
                      </td>

                      <td className="p-3.5 text-slate-300">{st.fatherName}</td>

                      <td className="p-3.5 text-center">
                        <div className="inline-flex rounded-xl bg-slate-950 p-1 border border-slate-800 gap-1">
                          <button
                            type="button"
                            onClick={() => handleSetStatus(st.id, 'present')}
                            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition ${
                              currentStatus === 'present'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            P
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSetStatus(st.id, 'absent')}
                            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition ${
                              currentStatus === 'absent'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            A
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSetStatus(st.id, 'late')}
                            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition ${
                              currentStatus === 'late'
                                ? 'bg-amber-500 text-slate-950 shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            L
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSetStatus(st.id, 'leave')}
                            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition ${
                              currentStatus === 'leave'
                                ? 'bg-cyan-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            LV
                          </button>
                        </div>
                      </td>

                      <td className="p-3.5">
                        <input
                          type="text"
                          value={remarksMap[st.id] || ''}
                          onChange={(e) =>
                            setRemarksMap({ ...remarksMap, [st.id]: e.target.value })
                          }
                          placeholder="Optional remark..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 text-xs focus:outline-hidden focus:border-emerald-500"
                        />
                      </td>

                      <td className="p-3.5 text-right">
                        {currentStatus === 'absent' ? (
                          <button
                            onClick={() => {
                              const msg = WhatsAppTemplates.absenceNotice(st.name, st.className, selectedDate);
                              openWhatsAppChat(st.guardianPhone, msg);
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 font-bold text-xs border border-rose-500/30 transition"
                          >
                            <Phone className="w-3 h-3 text-rose-400" />
                            <span>Alert Absent</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-500 font-mono">
                            {st.guardianPhone}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
