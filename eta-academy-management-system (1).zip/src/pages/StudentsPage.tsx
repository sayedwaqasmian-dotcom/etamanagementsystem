import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Search,
  Filter,
  UserPlus,
  Download,
  Upload,
  Printer,
  CreditCard,
  Edit,
  Archive,
  Trash2,
  Phone,
  Eye,
  X,
  CheckCircle,
  AlertCircle,
  FileText,
  Calendar,
  Sparkles,
  MapPin,
  Clock,
  IdCard,
} from 'lucide-react';
import { Student, User, ClassItem } from '../types';
import { api } from '../services/api';
import { openWhatsAppChat, WhatsAppTemplates } from '../utils/whatsapp';

interface StudentsPageProps {
  currentUser: User;
  onPrintIdCard: (student: Student) => void;
  onRecordFeeForStudent?: (student: Student) => void;
}

export const StudentsPage: React.FC<StudentsPageProps> = ({
  currentUser,
  onPrintIdCard,
  onRecordFeeForStudent,
}) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('active');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);

  // Selected student for detail/edit
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [studentDetails, setStudentDetails] = useState<any>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Partial<Student>>({
    name: '',
    fatherName: '',
    className: '6th',
    section: 'A',
    rollNo: '',
    gender: 'Male',
    dob: '',
    admissionDate: new Date().toISOString().split('T')[0],
    studentPhone: '',
    guardianPhone: '0345-6898969',
    address: 'Khwazakhela, Swat',
    previousSchool: '',
    monthlyFeePKR: 2500,
    discountPKR: 0,
    status: 'active',
    notes: '',
  });

  const [csvContent, setCsvContent] = useState('');

  const loadStudents = async () => {
    setLoading(true);
    try {
      const res = await api.students.getAll({
        search,
        classId: selectedClass,
        status: selectedStatus,
      });
      setStudents(res.students);
    } catch (err: any) {
      console.error('Failed to load students:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadClasses = async () => {
    try {
      const res = await api.classes.getAll();
      setClasses(res.classes);
    } catch (err) {
      // ignore
    }
  };

  useEffect(() => {
    loadClasses();
  }, []);

  useEffect(() => {
    loadStudents();
  }, [search, selectedClass, selectedStatus]);

  const handleOpenAdd = () => {
    setFormData({
      name: '',
      fatherName: '',
      className: '6th',
      section: 'A',
      rollNo: '',
      gender: 'Male',
      dob: '',
      admissionDate: new Date().toISOString().split('T')[0],
      studentPhone: '',
      guardianPhone: '0345-6898969',
      address: 'Khwazakhela, Swat',
      previousSchool: '',
      monthlyFeePKR: 2500,
      discountPKR: 0,
      status: 'active',
      notes: '',
    });
    setShowAddModal(true);
  };

  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.fatherName) {
      alert('Student name and father name are required.');
      return;
    }

    try {
      await api.students.create(formData);
      setShowAddModal(false);
      loadStudents();
      alert(`Student enrolled successfully! Automatic invoice created for current month.`);
    } catch (err: any) {
      alert(`Failed to admit student: ${err.message}`);
    }
  };

  const handleOpenEdit = (student: Student) => {
    setSelectedStudent(student);
    setFormData({ ...student });
    setShowEditModal(true);
  };

  const handleUpdateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;

    try {
      await api.students.update(selectedStudent.id, formData);
      setShowEditModal(false);
      loadStudents();
      alert('Student record updated successfully.');
    } catch (err: any) {
      alert(`Update failed: ${err.message}`);
    }
  };

  const handleViewProfile = async (student: Student) => {
    setSelectedStudent(student);
    setShowProfileModal(true);
    setDetailsLoading(true);
    try {
      const details = await api.students.getById(student.id);
      setStudentDetails(details);
    } catch (err) {
      console.error(err);
    } finally {
      setDetailsLoading(false);
    }
  };

  const handleArchive = async (student: Student) => {
    if (!confirm(`Are you sure you want to ${student.status === 'active' ? 'archive' : 'un-archive'} ${student.name}? History will be preserved.`)) {
      return;
    }

    try {
      await api.students.archive(student.id);
      loadStudents();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDelete = async (student: Student) => {
    if (currentUser.role !== 'principal' && currentUser.role !== 'admin') {
      alert('Only Principal or Administrator can delete student records.');
      return;
    }

    if (!confirm(`WARNING: Permanent deletion of ${student.name} (${student.id}). Are you sure?`)) {
      return;
    }

    try {
      await api.students.delete(student.id);
      loadStudents();
      alert('Student record deleted.');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleImportCsv = async () => {
    if (!csvContent.trim()) {
      alert('Please paste CSV content.');
      return;
    }

    try {
      const res = await api.students.importCsv(csvContent);
      alert(res.message);
      setShowImportModal(false);
      setCsvContent('');
      loadStudents();
    } catch (err: any) {
      alert(`CSV Import failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <GraduationCap className="w-6 h-6 text-blue-400" />
            Student Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Complete student directory, registration, fee ledgers, and printable ID cards
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {currentUser.role !== 'attendance_operator' && (
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm"
            >
              <UserPlus className="w-4 h-4" />
              <span>Admit Student</span>
            </button>
          )}

          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Upload className="w-3.5 h-3.5 text-amber-400" />
            <span>Import CSV</span>
          </button>

          <a
            href="/api/students/export-csv"
            download
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </a>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, roll no, phone..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Class Filter */}
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
          >
            <option value="">All Classes (6th-12th)</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.name}>
                Class {cls.name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
          >
            <option value="">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="archived">Archived</option>
            <option value="graduated">Graduated</option>
          </select>

          <span className="text-xs text-slate-400 font-medium px-2">
            Total: <strong>{students.length}</strong>
          </span>
        </div>
      </div>

      {/* Students Data Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider font-bold border-b border-slate-800">
                <th className="p-3.5">Student ID & Name</th>
                <th className="p-3.5">Father Name</th>
                <th className="p-3.5 text-center">Class & Sec</th>
                <th className="p-3.5 text-center">Roll #</th>
                <th className="p-3.5">Monthly Fee (PKR)</th>
                <th className="p-3.5">Guardian Contact</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    Loading students...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No students found matching your criteria.
                  </td>
                </tr>
              ) : (
                students.map((st) => (
                  <tr key={st.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 font-bold flex items-center justify-center shrink-0 border border-blue-500/30">
                          {st.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-white hover:text-blue-400 cursor-pointer" onClick={() => handleViewProfile(st)}>
                            {st.name}
                          </p>
                          <p className="font-mono text-[10px] text-slate-400">{st.id}</p>
                        </div>
                      </div>
                    </td>

                    <td className="p-3.5 text-slate-300 font-medium">{st.fatherName}</td>

                    <td className="p-3.5 text-center font-bold text-slate-200">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                        {st.className} ({st.section})
                      </span>
                    </td>

                    <td className="p-3.5 text-center font-mono font-bold text-amber-400">
                      {st.rollNo}
                    </td>

                    <td className="p-3.5 font-mono">
                      <span className="font-bold text-white">Rs. {st.monthlyFeePKR.toLocaleString()}</span>
                      {st.discountPKR > 0 && (
                        <span className="block text-[10px] text-emerald-400">
                          -Rs. {st.discountPKR} discount
                        </span>
                      )}
                    </td>

                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-300">
                        <span>{st.guardianPhone}</span>
                        <button
                          onClick={() =>
                            openWhatsAppChat(
                              st.guardianPhone,
                              `Assalam-o-Alaikum! Message from The Excellent Tuition Academy Khwazakhela regarding student ${st.name} (Class ${st.className}).`
                            )
                          }
                          title="Chat with guardian on WhatsApp"
                          className="text-emerald-400 hover:text-emerald-300 p-1"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                    <td className="p-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          st.status === 'active'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : st.status === 'archived'
                            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            : 'bg-purple-500/15 text-purple-400 border border-purple-500/30'
                        }`}
                      >
                        {st.status}
                      </span>
                    </td>

                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => handleViewProfile(st)}
                          title="View Full Profile"
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onPrintIdCard(st)}
                          title="Print Student ID Card"
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 transition"
                        >
                          <IdCard className="w-3.5 h-3.5" />
                        </button>

                        {currentUser.role !== 'attendance_operator' && (
                          <button
                            onClick={() => handleOpenEdit(st)}
                            title="Edit Student"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {(currentUser.role === 'principal' || currentUser.role === 'admin') && (
                          <>
                            <button
                              onClick={() => handleArchive(st)}
                              title="Archive/Unarchive"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-500 transition"
                            >
                              <Archive className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(st)}
                              title="Delete Record"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-500 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ----------------- MODAL: ADD STUDENT ----------------- */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="font-black text-base text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-blue-400" />
                Admit New Student — The Excellent Tuition Academy
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateStudent} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Student Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Muhammad Ahmad"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Father's Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.fatherName || ''}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="e.g. Abdul Rashid Khan"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Class Assigned *</label>
                  <select
                    value={formData.className}
                    onChange={(e) => {
                      const cName = e.target.value;
                      const defaultFee = cName === '9th' || cName === '10th' ? 3500 : cName === '11th' || cName === '12th' ? 4500 : 2500;
                      setFormData({ ...formData, className: cName, monthlyFeePKR: defaultFee });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  >
                    <option value="6th">Class 6th</option>
                    <option value="7th">Class 7th</option>
                    <option value="8th">Class 8th</option>
                    <option value="9th">Class 9th</option>
                    <option value="10th">Class 10th</option>
                    <option value="11th">Class 11th (FSc)</option>
                    <option value="12th">Class 12th (FSc)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Section / Group</label>
                  <input
                    type="text"
                    value={formData.section || 'A'}
                    onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                    placeholder="e.g. A, Science, Pre-Medical"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as 'Male' | 'Female' })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Date of Birth</label>
                  <input
                    type="date"
                    value={formData.dob || ''}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Guardian / Father Phone *</label>
                  <input
                    type="text"
                    required
                    value={formData.guardianPhone || ''}
                    onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                    placeholder="e.g. 0345-6898969"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Student Phone (Optional)</label>
                  <input
                    type="text"
                    value={formData.studentPhone || ''}
                    onChange={(e) => setFormData({ ...formData, studentPhone: e.target.value })}
                    placeholder="e.g. 0340-1234567"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Monthly Tuition Fee (Rs. PKR) *</label>
                  <input
                    type="number"
                    required
                    value={formData.monthlyFeePKR || 2500}
                    onChange={(e) => setFormData({ ...formData, monthlyFeePKR: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-bold focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Scholarship / Discount (PKR)</label>
                  <input
                    type="number"
                    value={formData.discountPKR || 0}
                    onChange={(e) => setFormData({ ...formData, discountPKR: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Home Address (Swat / Khwazakhela)</label>
                <input
                  type="text"
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="e.g. Mata Road, Khwazakhela, Swat"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Previous School</label>
                <input
                  type="text"
                  value={formData.previousSchool || ''}
                  onChange={(e) => setFormData({ ...formData, previousSchool: e.target.value })}
                  placeholder="e.g. Swat Model High School"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md shadow-blue-600/20"
                >
                  Complete Admission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: EDIT STUDENT ----------------- */}
      {showEditModal && selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="font-black text-base text-white flex items-center gap-2">
                <Edit className="w-5 h-5 text-amber-400" />
                Edit Student Profile: {selectedStudent.name} ({selectedStudent.id})
              </h3>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateStudent} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Student Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Father's Name</label>
                  <input
                    type="text"
                    required
                    value={formData.fatherName || ''}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Class</label>
                  <select
                    value={formData.className}
                    onChange={(e) => setFormData({ ...formData, className: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="6th">Class 6th</option>
                    <option value="7th">Class 7th</option>
                    <option value="8th">Class 8th</option>
                    <option value="9th">Class 9th</option>
                    <option value="10th">Class 10th</option>
                    <option value="11th">Class 11th</option>
                    <option value="12th">Class 12th</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Roll Number</label>
                  <input
                    type="text"
                    value={formData.rollNo || ''}
                    onChange={(e) => setFormData({ ...formData, rollNo: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Monthly Fee (PKR)</label>
                  <input
                    type="number"
                    value={formData.monthlyFeePKR || 2500}
                    onChange={(e) => setFormData({ ...formData, monthlyFeePKR: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Scholarship / Discount (PKR)</label>
                  <input
                    type="number"
                    value={formData.discountPKR || 0}
                    onChange={(e) => setFormData({ ...formData, discountPKR: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Guardian Phone</label>
                  <input
                    type="text"
                    value={formData.guardianPhone || ''}
                    onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="active">Active</option>
                    <option value="archived">Archived</option>
                    <option value="graduated">Graduated</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Address</label>
                <input
                  type="text"
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: STUDENT PROFILE & ACADEMIC DOSSIER ----------------- */}
      {showProfileModal && selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white font-black text-xl flex items-center justify-center">
                  {selectedStudent.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-black text-lg text-white">{selectedStudent.name}</h3>
                  <p className="text-xs text-slate-400">
                    ID: <span className="font-mono text-amber-400">{selectedStudent.id}</span> • Class {selectedStudent.className} ({selectedStudent.section})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onPrintIdCard(selectedStudent)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition"
                >
                  <IdCard className="w-4 h-4" />
                  Print ID Card
                </button>
                <button onClick={() => setShowProfileModal(false)} className="text-slate-400 hover:text-white p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Profile Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 my-4 rounded-xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 block">Father Name:</span>
                <span className="font-semibold text-slate-200">{selectedStudent.fatherName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Roll Number:</span>
                <span className="font-mono font-bold text-amber-400">{selectedStudent.rollNo}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Monthly Fee:</span>
                <span className="font-mono font-bold text-emerald-400">Rs. {selectedStudent.monthlyFeePKR.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block">Guardian Phone:</span>
                <span className="font-mono text-slate-200">{selectedStudent.guardianPhone}</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-500 block">Address:</span>
                <span className="text-slate-200">{selectedStudent.address}</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-500 block">Previous School:</span>
                <span className="text-slate-200">{selectedStudent.previousSchool || 'Not recorded'}</span>
              </div>
            </div>

            {/* Sub-sections: Invoices, Attendance, Tests */}
            {detailsLoading ? (
              <div className="py-8 text-center text-slate-400 text-xs">Loading academic and financial history...</div>
            ) : studentDetails ? (
              <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
                {/* Fee Ledger */}
                <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2 flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4" />
                    Fee Invoices & Payments (PKR)
                  </h4>
                  {studentDetails.invoices?.length > 0 ? (
                    <div className="space-y-1.5 text-xs">
                      {studentDetails.invoices.map((inv: any) => (
                        <div key={inv.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                          <div>
                            <span className="font-bold text-white">{inv.month}</span>
                            <span className="text-slate-400 text-[10px] ml-2">Inv #{inv.invoiceNo}</span>
                          </div>
                          <div className="flex items-center gap-3 font-mono">
                            <span className="text-slate-300">Net: Rs. {inv.netAmountPKR}</span>
                            <span className="text-emerald-400">Paid: Rs. {inv.paidAmountPKR}</span>
                            <span className={inv.balancePKR > 0 ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                              Bal: Rs. {inv.balancePKR}
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${inv.status === 'paid' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                              {inv.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400">No invoices generated yet.</p>
                  )}
                </div>

                {/* Exam Results */}
                <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-2 flex items-center gap-1.5">
                    <FileText className="w-4 h-4" />
                    Academic Assessments
                  </h4>
                  {studentDetails.testResults?.length > 0 ? (
                    <div className="space-y-1.5 text-xs">
                      {studentDetails.testResults.map((t: any, idx: number) => (
                        <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                          <div>
                            <span className="font-bold text-white">{t.testTitle}</span>
                            <span className="text-slate-400 text-[10px] ml-2">({t.subject})</span>
                          </div>
                          <div className="flex items-center gap-3 font-mono">
                            <span className="font-bold text-amber-400">{t.marksObtained} / {t.totalMarks}</span>
                            <span className="text-emerald-400 font-bold">{t.percentage}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400">No assessment records yet.</p>
                  )}
                </div>
              </div>
            ) : null}

            <div className="mt-4 pt-4 border-t border-slate-800 flex justify-between items-center text-xs">
              <button
                onClick={() =>
                  openWhatsAppChat(
                    selectedStudent.guardianPhone,
                    `Assalam-o-Alaikum! Update from The Excellent Tuition Academy regarding ${selectedStudent.name} (Class ${selectedStudent.className}).`
                  )
                }
                className="flex items-center gap-1.5 text-emerald-400 hover:underline font-semibold"
              >
                <Phone className="w-3.5 h-3.5" />
                WhatsApp Guardian ({selectedStudent.guardianPhone})
              </button>

              <button
                onClick={() => setShowProfileModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- MODAL: CSV IMPORT ----------------- */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-amber-400" />
                Import Students from CSV
              </h3>
              <button onClick={() => setShowImportModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mt-3 leading-relaxed">
              Paste standard CSV rows with headers. Format example:
            </p>
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[10px] font-mono text-amber-300 my-2">
              name,father name,class,section,roll,phone,fee<br />
              Rashid Ali,Muhammad Ali,8th,A,05,0345-1234567,2800<br />
              Sara Khan,Gul Khan,9th,Science,06,0346-7654321,3500
            </div>

            <textarea
              rows={6}
              value={csvContent}
              onChange={(e) => setCsvContent(e.target.value)}
              placeholder="Paste CSV rows here..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-100 focus:outline-hidden focus:border-blue-500"
            />

            <div className="pt-3 border-t border-slate-800 flex justify-end gap-2 text-xs">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleImportCsv}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                Process & Import Records
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
