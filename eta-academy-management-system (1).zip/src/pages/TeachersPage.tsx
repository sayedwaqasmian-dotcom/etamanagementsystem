import React, { useState, useEffect } from 'react';
import {
  Users2,
  UserPlus,
  Printer,
  Search,
  Filter,
  Phone,
  Briefcase,
  GraduationCap,
  Calendar,
  DollarSign,
  X,
  Edit,
  Archive,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import { Teacher, User } from '../types';
import { api } from '../services/api';
import { openWhatsAppChat } from '../utils/whatsapp';

interface TeachersPageProps {
  currentUser: User;
}

export const TeachersPage: React.FC<TeachersPageProps> = ({ currentUser }) => {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [genderFilter, setGenderFilter] = useState('');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  const [formData, setFormData] = useState<Partial<Teacher>>({
    name: '',
    gender: 'Male',
    qualification: '',
    subjects: [],
    assignedClasses: [],
    phone: '0345-6898969',
    monthlySalaryPKR: 40000,
    address: 'Khwazakhela, Swat',
    notes: '',
  });

  const [subjectsInput, setSubjectsInput] = useState('');
  const [classesInput, setClassesInput] = useState('');

  const loadTeachers = async () => {
    setLoading(true);
    try {
      const res = await api.teachers.getAll();
      setTeachers(res.teachers);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTeachers();
  }, []);

  const handleOpenAdd = () => {
    setFormData({
      name: '',
      gender: 'Male',
      qualification: '',
      subjects: [],
      assignedClasses: [],
      phone: '0345-6898969',
      monthlySalaryPKR: 40000,
      address: 'Khwazakhela, Swat',
      notes: '',
    });
    setSubjectsInput('');
    setClassesInput('');
    setShowAddModal(true);
  };

  const handleOpenEdit = (teacher: Teacher) => {
    setSelectedTeacher(teacher);
    setFormData({ ...teacher });
    setSubjectsInput(teacher.subjects.join(', '));
    setClassesInput(teacher.assignedClasses.join(', '));
    setShowEditModal(true);
  };

  const handleCreateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.qualification) {
      alert('Name and qualification are required.');
      return;
    }

    try {
      const subs = subjectsInput.split(',').map((s) => s.trim()).filter(Boolean);
      const cls = classesInput.split(',').map((c) => c.trim()).filter(Boolean);

      await api.teachers.create({
        ...formData,
        subjects: subs,
        assignedClasses: cls,
      });

      alert('Faculty member added successfully.');
      setShowAddModal(false);
      loadTeachers();
    } catch (err: any) {
      alert(`Failed: ${err.message}`);
    }
  };

  const handleUpdateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeacher) return;

    try {
      const subs = subjectsInput.split(',').map((s) => s.trim()).filter(Boolean);
      const cls = classesInput.split(',').map((c) => c.trim()).filter(Boolean);

      await api.teachers.update(selectedTeacher.id, {
        ...formData,
        subjects: subs,
        assignedClasses: cls,
      });

      alert('Faculty profile updated successfully.');
      setShowEditModal(false);
      loadTeachers();
    } catch (err: any) {
      alert(`Update failed: ${err.message}`);
    }
  };

  const filteredTeachers = teachers.filter((t) => {
    if (genderFilter && t.gender !== genderFilter) return false;
    if (search) {
      const s = search.toLowerCase();
      return (
        t.name.toLowerCase().includes(s) ||
        t.qualification.toLowerCase().includes(s) ||
        t.subjects.some((sub) => sub.toLowerCase().includes(s))
      );
    }
    return true;
  });

  const canViewSalary = currentUser.role === 'principal' || currentUser.role === 'accountant';
  const totalPayroll = teachers.reduce((sum, t) => sum + t.monthlySalaryPKR, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Users2 className="w-6 h-6 text-amber-400" />
            Teacher & Staff Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Faculty directory, academic qualifications, class assignments and salary management (PKR)
          </p>
        </div>

        <div className="flex items-center gap-2">
          {currentUser.role === 'principal' && (
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add Faculty Member</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Faculty Directory</span>
          </button>
        </div>
      </div>

      {/* Salary Overview for Principal & Accountant */}
      {canViewSalary && (
        <div className="rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950/70 border border-slate-800 p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Faculty Payroll Overview</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-amber-400 font-mono">Rs. {totalPayroll.toLocaleString()}</span>
              <span className="text-xs text-slate-300 font-mono">PKR / Month</span>
            </div>
          </div>
          <div className="text-xs text-slate-400">
            Total Staff: <strong>{teachers.length} Instructors</strong> • Principal & Accounts Authorized
          </div>
        </div>
      )}

      {/* Filter toolbar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search faculty name, subject, degree..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={genderFilter}
            onChange={(e) => setGenderFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
          >
            <option value="">All Faculty</option>
            <option value="Male">Male Instructors</option>
            <option value="Female">Female Instructors</option>
          </select>

          <span className="text-xs text-slate-400 font-medium px-2">
            Showing <strong>{filteredTeachers.length}</strong> teachers
          </span>
        </div>
      </div>

      {/* Teachers Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {loading ? (
          <div className="col-span-4 p-8 text-center text-slate-400 text-xs">Loading faculty members...</div>
        ) : (
          filteredTeachers.map((teacher) => (
            <div
              key={teacher.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="font-mono text-[10px] text-amber-400 font-bold">{teacher.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                      teacher.gender === 'Female'
                        ? 'bg-purple-500/20 text-purple-300'
                        : 'bg-blue-500/20 text-blue-300'
                    }`}
                  >
                    {teacher.gender}
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className="font-extrabold text-sm text-white">{teacher.name}</h3>
                  <p className="text-xs font-semibold text-amber-300 mt-0.5">{teacher.qualification}</p>
                </div>

                <div className="mt-4 space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400 text-[11px] block">Subjects:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {teacher.subjects.map((sub, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-slate-950 text-slate-300 text-[10px] border border-slate-800">
                          {sub}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 text-[11px] block">Assigned Classes:</span>
                    <span className="font-semibold text-slate-200">{teacher.assignedClasses.join(', ')}</span>
                  </div>

                  {canViewSalary && (
                    <div className="pt-2 border-t border-slate-800 flex justify-between font-mono">
                      <span className="text-slate-400">Monthly Salary:</span>
                      <span className="font-bold text-emerald-400">Rs. {teacher.monthlySalaryPKR.toLocaleString()} PKR</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <button
                  onClick={() => openWhatsAppChat(teacher.phone, `Assalam-o-Alaikum ${teacher.name}! Official message from ETA Academy Principal Office.`)}
                  className="flex items-center gap-1 text-emerald-400 hover:underline font-mono text-[11px]"
                >
                  <Phone className="w-3 h-3" />
                  {teacher.phone}
                </button>

                {currentUser.role === 'principal' && (
                  <button
                    onClick={() => handleOpenEdit(teacher)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="Edit Details"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* ----------------- MODAL: ADD / EDIT TEACHER ----------------- */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-black text-sm text-white">
                {showAddModal ? 'Add Faculty Member' : `Edit: ${selectedTeacher?.name}`}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={showAddModal ? handleCreateTeacher : handleUpdateTeacher} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Teacher Full Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Mr. Nouman Khan"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Qualification *</label>
                  <input
                    type="text"
                    required
                    value={formData.qualification || ''}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    placeholder="e.g. MPhil Physics"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-slate-400 mb-1 font-semibold">Subjects (Comma Separated)</label>
                  <input
                    type="text"
                    value={subjectsInput}
                    onChange={(e) => setSubjectsInput(e.target.value)}
                    placeholder="e.g. Botany, Chemistry, General Science"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-slate-400 mb-1 font-semibold">Assigned Classes (Comma Separated)</label>
                  <input
                    type="text"
                    value={classesInput}
                    onChange={(e) => setClassesInput(e.target.value)}
                    placeholder="e.g. 9th, 10th, 11th, 12th"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                {canViewSalary && (
                  <div>
                    <label className="block text-slate-400 mb-1 font-semibold">Monthly Salary (PKR)</label>
                    <input
                      type="number"
                      value={formData.monthlySalaryPKR || 40000}
                      onChange={(e) => setFormData({ ...formData, monthlySalaryPKR: Number(e.target.value) })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-slate-400 mb-1 font-semibold">Contact Phone</label>
                  <input
                    type="text"
                    value={formData.phone || ''}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="0345-6898969"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">Address (Swat)</label>
                <input
                  type="text"
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Khwazakhela, Swat"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
                >
                  Save Faculty Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
