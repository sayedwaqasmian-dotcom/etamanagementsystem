import React from 'react';
import { FeePayment, FeeInvoice, Student } from '../types';
import { Printer, X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface PrintableReceiptProps {
  payment: FeePayment;
  invoice?: FeeInvoice;
  student?: Student;
  onClose: () => void;
}

export const PrintableReceipt: React.FC<PrintableReceiptProps> = ({
  payment,
  invoice,
  student,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white text-slate-900 rounded-2xl shadow-2xl p-6 md:p-8 my-8 print:p-0 print:m-0 print:shadow-none print:w-full print:rounded-none">
        
        {/* Actions bar (hidden in print) */}
        <div className="no-print flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
          <div className="flex items-center gap-2 text-emerald-600 font-semibold text-sm">
            <CheckCircle2 className="w-5 h-5" />
            Official Fee Receipt Ready
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold transition shadow-sm"
            >
              <Printer className="w-4 h-4" />
              Print Receipt
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="printable-area border-2 border-slate-900/10 rounded-xl p-6 bg-amber-500/5 print:border-none print:p-0 print:bg-white">
          
          {/* Header */}
          <div className="text-center pb-5 border-b-2 border-slate-900/20">
            <div className="flex items-center justify-center gap-3 mb-1">
              <div className="w-12 h-12 rounded-full bg-blue-900 text-amber-400 flex items-center justify-center font-black text-xl shadow-md border-2 border-amber-400">
                ETA
              </div>
              <div className="text-left">
                <h1 className="text-xl md:text-2xl font-black tracking-tight text-blue-950 uppercase">
                  The Excellent Tuition Academy
                </h1>
                <p className="text-xs font-bold tracking-widest text-amber-600 uppercase">
                  Khwazakhela, Swat • Khyber Pakhtunkhwa
                </p>
              </div>
            </div>
            <p className="text-[11px] text-slate-600 mt-1">
              Mata Road, Khwazakhela, Swat | Principal: <strong>Mr. Rahmat Ali</strong> | Phone: <strong>0345-6898969</strong>
            </p>
            <div className="inline-block mt-2 px-3 py-0.5 bg-blue-950 text-amber-300 text-xs font-extrabold uppercase tracking-wider rounded-md">
              Fee Collection Receipt (PKR)
            </div>
          </div>

          {/* Receipt Details Meta */}
          <div className="grid grid-cols-2 gap-4 py-4 text-xs border-b border-slate-200">
            <div>
              <p className="text-slate-500">Receipt No:</p>
              <p className="font-mono font-bold text-sm text-blue-900">{payment.receiptNo}</p>
              
              <p className="text-slate-500 mt-2">Invoice Reference:</p>
              <p className="font-mono font-semibold text-slate-800">{payment.invoiceId}</p>
            </div>
            <div className="text-right">
              <p className="text-slate-500">Date of Payment:</p>
              <p className="font-semibold text-slate-800">{payment.paymentDate}</p>

              <p className="text-slate-500 mt-2">Payment Method:</p>
              <span className="inline-block px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded text-[11px]">
                {payment.paymentMethod}
              </span>
            </div>
          </div>

          {/* Student Info */}
          <div className="bg-slate-50 rounded-lg p-3 my-4 border border-slate-200 text-xs">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <span className="text-slate-500 block">Student Name:</span>
                <span className="font-bold text-slate-900 text-sm">{payment.studentName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Student ID:</span>
                <span className="font-mono font-semibold text-slate-800">{payment.studentId}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Class & Section:</span>
                <span className="font-semibold text-slate-800">
                  {student?.className || invoice?.className || 'Class'} ({student?.section || 'A'})
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Roll Number:</span>
                <span className="font-mono font-semibold text-slate-800">{student?.rollNo || '01'}</span>
              </div>
            </div>
          </div>

          {/* Financial Breakdown Table */}
          <table className="w-full text-xs text-left border-collapse my-3">
            <thead>
              <tr className="bg-blue-950 text-white font-bold">
                <th className="p-2.5 rounded-l">Description</th>
                <th className="p-2.5 text-center">Month</th>
                <th className="p-2.5 text-right rounded-r">Amount (Rs. PKR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              <tr>
                <td className="p-2.5 font-medium">Academy Tuition & Coaching Fee</td>
                <td className="p-2.5 text-center">{invoice?.month || 'October 2026'}</td>
                <td className="p-2.5 text-right font-semibold">
                  Rs. {(invoice?.amountPKR || payment.amountPKR).toLocaleString()} PKR
                </td>
              </tr>
              {invoice?.discountPKR && invoice.discountPKR > 0 ? (
                <tr className="text-emerald-700">
                  <td className="p-2.5">Scholarship / Fee Concession Applied</td>
                  <td className="p-2.5 text-center">-</td>
                  <td className="p-2.5 text-right font-semibold">- Rs. {invoice.discountPKR.toLocaleString()} PKR</td>
                </tr>
              ) : null}
              <tr className="bg-amber-50/60 font-bold text-slate-900 border-t-2 border-slate-300">
                <td className="p-2.5 text-blue-950 text-sm">AMOUNT RECEIVED (THIS PAYMENT)</td>
                <td className="p-2.5 text-center text-xs text-slate-600">PAID IN FULL/PARTIAL</td>
                <td className="p-2.5 text-right text-base text-blue-950 font-black">
                  Rs. {payment.amountPKR.toLocaleString()} PKR
                </td>
              </tr>
              {invoice ? (
                <tr className="text-xs text-slate-600">
                  <td className="p-2.5" colSpan={2}>
                    Remaining Outstanding Balance for this invoice:
                  </td>
                  <td className={`p-2.5 text-right font-bold ${invoice.balancePKR > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                    Rs. {invoice.balancePKR.toLocaleString()} PKR
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>

          {payment.remarks && (
            <div className="p-2 bg-slate-100 rounded text-[11px] text-slate-600 my-2">
              <strong>Remarks:</strong> {payment.remarks}
            </div>
          )}

          {/* Security & Signatures */}
          <div className="pt-8 mt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-center text-xs">
            <div>
              <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-slate-800">
                {payment.collectorName || 'Muhammad Farooq'}
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">Accountant / Cashier</p>
            </div>
            <div>
              <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-blue-950">
                Mr. Rahmat Ali
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">Principal & Founder (ETA)</p>
            </div>
          </div>

          {/* Footer Note */}
          <div className="mt-6 pt-3 border-t border-slate-200 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Computerized Fee Receipt • Valid without stamp • The Excellent Tuition Academy Khwazakhela, Swat
          </div>

        </div>

      </div>
    </div>
  );
};
