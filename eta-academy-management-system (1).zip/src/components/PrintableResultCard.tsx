import React from 'react';
import { ExamTest, Student } from '../types';
import { Printer, X, Award, CheckCircle } from 'lucide-react';

interface PrintableResultCardProps {
  test: ExamTest;
  studentResult: {
    studentId: string;
    studentName: string;
    rollNo: string;
    marksObtained: number;
    remarks: string;
  };
  student?: Student;
  onClose: () => void;
}

export function calculateGrade(percentage: number): { grade: string; remarks: string } {
  if (percentage >= 80) return { grade: 'A-1 (Outstanding)', remarks: 'Excellent Performance' };
  if (percentage >= 70) return { grade: 'A (Very Good)', remarks: 'Commendable Effort' };
  if (percentage >= 60) return { grade: 'B (Good)', remarks: 'Good work, keep improving' };
  if (percentage >= 50) return { grade: 'C (Fair)', remarks: 'Average, needs focus' };
  if (percentage >= 40) return { grade: 'D (Pass)', remarks: 'Borderline pass' };
  return { grade: 'F (Fail)', remarks: 'Below passing criteria' };
}

export const PrintableResultCard: React.FC<PrintableResultCardProps> = ({
  test,
  studentResult,
  student,
  onClose,
}) => {
  const percentage = Math.round((studentResult.marksObtained / test.totalMarks) * 100);
  const gradeInfo = calculateGrade(percentage);
  const isPassed = studentResult.marksObtained >= test.passingMarks;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white text-slate-900 rounded-2xl shadow-2xl p-6 md:p-8 my-8 print:p-0 print:m-0 print:shadow-none print:w-full print:rounded-none">
        
        {/* Actions bar (hidden in print) */}
        <div className="no-print flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
          <div className="flex items-center gap-2 text-blue-900 font-semibold text-sm">
            <Award className="w-5 h-5 text-amber-500" />
            Official Academic Result Card
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-4 py-2 bg-blue-900 hover:bg-blue-950 text-white rounded-xl text-xs font-bold transition shadow-sm"
            >
              <Printer className="w-4 h-4" />
              Print Result Card
            </button>
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-700 rounded-lg transition">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="printable-area border-2 border-slate-900/10 rounded-xl p-6 bg-slate-50/50 print:border-none print:p-0 print:bg-white">
          
          {/* Header */}
          <div className="text-center pb-5 border-b-2 border-slate-900/20">
            <div className="flex items-center justify-center gap-3 mb-1">
              <div className="w-12 h-12 rounded-full bg-blue-950 text-amber-400 flex items-center justify-center font-black text-xl border-2 border-amber-400">
                ETA
              </div>
              <div className="text-left">
                <h1 className="text-xl md:text-2xl font-black tracking-tight text-blue-950 uppercase">
                  The Excellent Tuition Academy
                </h1>
                <p className="text-xs font-bold tracking-widest text-amber-600 uppercase">
                  Khwazakhela, Swat • Khyber Pakhtunkhwa
                </p>
              </div>
            </div>
            <p className="text-[11px] text-slate-600 mt-1">
              Mata Road, Khwazakhela | Principal: <strong>Mr. Rahmat Ali</strong> | Phone: <strong>0345-6898969</strong>
            </p>
            <div className="inline-block mt-2 px-4 py-1 bg-blue-950 text-amber-300 text-xs font-black uppercase tracking-wider rounded-md">
              Student Progress & Assessment Report
            </div>
          </div>

          {/* Student & Test Meta */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 my-4 bg-white rounded-xl border border-slate-200 text-xs shadow-xs">
            <div>
              <span className="text-slate-500 block">Student Name:</span>
              <span className="font-extrabold text-blue-950 text-sm">{studentResult.studentName}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Father's Name:</span>
              <span className="font-semibold text-slate-800">{student?.fatherName || 'Guardian'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Class & Roll No:</span>
              <span className="font-bold text-slate-800">
                Class {test.className} (Roll #{studentResult.rollNo})
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Assessment Title:</span>
              <span className="font-semibold text-slate-800">{test.title}</span>
            </div>
          </div>

          {/* Marks Breakdown Table */}
          <table className="w-full text-xs text-left border-collapse my-4">
            <thead>
              <tr className="bg-blue-950 text-white font-bold">
                <th className="p-3 rounded-l">Subject</th>
                <th className="p-3 text-center">Exam Date</th>
                <th className="p-3 text-center">Total Marks</th>
                <th className="p-3 text-center">Passing Marks</th>
                <th className="p-3 text-center">Obtained Marks</th>
                <th className="p-3 text-right rounded-r">Percentage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800 bg-white">
              <tr>
                <td className="p-3 font-bold text-blue-950">{test.subject}</td>
                <td className="p-3 text-center text-slate-600">{test.date}</td>
                <td className="p-3 text-center font-mono">{test.totalMarks}</td>
                <td className="p-3 text-center font-mono">{test.passingMarks}</td>
                <td className="p-3 text-center font-mono font-bold text-base text-blue-950">
                  {studentResult.marksObtained}
                </td>
                <td className="p-3 text-right font-mono font-bold text-sm text-emerald-700">
                  {percentage}%
                </td>
              </tr>
            </tbody>
          </table>

          {/* Grade & Status Card */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-4 p-4 rounded-xl bg-blue-50 border border-blue-200 text-xs">
            <div>
              <span className="text-slate-500 block text-[11px]">Grade Awarded:</span>
              <span className="font-black text-blue-950 text-base">{gradeInfo.grade}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Assessment Status:</span>
              <span className={`inline-flex items-center gap-1 font-bold text-sm ${isPassed ? 'text-emerald-700' : 'text-rose-700'}`}>
                <CheckCircle className="w-4 h-4" />
                {isPassed ? 'PASSED / SATISFACTORY' : 'NEEDS RETAKE'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Teacher Remarks:</span>
              <span className="font-medium text-slate-800 italic">
                "{studentResult.remarks || gradeInfo.remarks}"
              </span>
            </div>
          </div>

          {/* Signatures */}
          <div className="pt-8 mt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-center text-xs">
            <div>
              <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-slate-800">
                Subject Teacher
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">Faculty Signature</p>
            </div>
            <div>
              <div className="border-b border-slate-400 w-44 mx-auto pb-1 mb-1 font-semibold text-blue-950">
                Mr. Rahmat Ali
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">Principal & Founder (ETA)</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
