import React from 'react';
import { Student } from '../types';
import { Printer, X, Shield, Phone, MapPin, User as UserIcon } from 'lucide-react';

interface PrintableIdCardProps {
  student: Student;
  onClose: () => void;
}

export const PrintableIdCard: React.FC<PrintableIdCardProps> = ({ student, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 overflow-y-auto backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white text-slate-900 rounded-2xl shadow-2xl p-6 my-8 print:p-0 print:m-0 print:shadow-none print:w-auto">
        
        {/* Actions bar (hidden in print) */}
        <div className="no-print flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
          <span className="font-semibold text-sm text-slate-800">Student ID Card (Printable)</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-blue-900 hover:bg-blue-950 text-white rounded-xl text-xs font-bold transition shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Card
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* The ID Card (Standard CR80 aspect ratio style) */}
        <div className="printable-area w-full max-w-[340px] mx-auto rounded-2xl overflow-hidden border border-slate-300 shadow-xl bg-gradient-to-b from-blue-950 via-slate-900 to-blue-950 text-white relative">
          
          {/* Card Header */}
          <div className="p-4 text-center border-b border-amber-500/30 bg-blue-900/60 relative">
            <div className="flex items-center justify-center gap-2 mb-0.5">
              <div className="w-9 h-9 rounded-full bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center shadow-md">
                ETA
              </div>
              <div className="text-left">
                <h2 className="text-xs font-black tracking-wider uppercase text-white leading-tight">
                  The Excellent Tuition Academy
                </h2>
                <p className="text-[9px] font-bold tracking-widest text-amber-400 uppercase">
                  Khwazakhela, Swat
                </p>
              </div>
            </div>
            <p className="text-[8px] text-slate-300 mt-1">
              Quality Education | Brighter Future | Better Tomorrow
            </p>
          </div>

          {/* Card Body */}
          <div className="p-4 flex flex-col items-center">
            {/* Photo frame */}
            <div className="w-24 h-28 rounded-xl border-2 border-amber-400 overflow-hidden bg-slate-800 shadow-lg flex items-center justify-center mb-3">
              {student.avatar ? (
                <img src={student.avatar} alt={student.name} className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center justify-center text-slate-400">
                  <UserIcon className="w-10 h-10 text-amber-400/80 mb-1" />
                  <span className="text-[9px] font-semibold text-slate-300">PHOTO</span>
                </div>
              )}
            </div>

            {/* Student Name & Class */}
            <h3 className="text-base font-extrabold text-amber-300 text-center tracking-tight">
              {student.name}
            </h3>
            <div className="mt-1 px-3 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-bold">
              Class {student.className} • Section {student.section}
            </div>

            {/* Student Info Table */}
            <div className="w-full mt-3 pt-3 border-t border-slate-700/60 text-[11px] space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Student ID:</span>
                <span className="font-mono font-bold text-white">{student.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Father's Name:</span>
                <span className="font-semibold text-slate-200">{student.fatherName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Roll Number:</span>
                <span className="font-mono font-bold text-amber-300">{student.rollNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Emergency Phone:</span>
                <span className="font-semibold text-slate-200">{student.guardianPhone || '0345-6898969'}</span>
              </div>
            </div>

            {/* Simulated Barcode / Magnetic Strip */}
            <div className="w-full mt-4 pt-3 border-t border-slate-700 flex flex-col items-center">
              <div className="w-48 h-6 bg-white/90 rounded px-2 py-0.5 flex items-center justify-between">
                {/* Barcode lines */}
                <div className="flex items-center gap-[2px] w-full h-full">
                  {[3, 1, 2, 4, 1, 2, 1, 3, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 1, 2, 3, 1, 4, 2].map((w, i) => (
                    <div key={i} className="bg-slate-950 h-full" style={{ width: `${w * 1.5}px` }} />
                  ))}
                </div>
              </div>
              <span className="text-[8px] font-mono text-slate-400 mt-1">{student.id}</span>
            </div>

            {/* Principal Signature */}
            <div className="w-full mt-3 pt-2 flex justify-between items-end text-[9px] text-slate-400">
              <div className="flex items-center gap-1 text-[8px] text-slate-400">
                <Shield className="w-3 h-3 text-amber-400" />
                <span>ETA Swat</span>
              </div>
              <div className="text-right">
                <div className="font-serif italic font-semibold text-slate-200 border-b border-slate-500 pb-0.5">
                  Rahmat Ali
                </div>
                <span className="text-[8px] text-slate-400">Principal Signature</span>
              </div>
            </div>
          </div>

          {/* Card Back / Footer */}
          <div className="bg-slate-950/80 p-2.5 text-center text-[8px] text-slate-400 border-t border-slate-800">
            <p className="flex items-center justify-center gap-1">
              <MapPin className="w-2.5 h-2.5 text-amber-400" />
              Mata Road, Khwazakhela, Swat, KP
            </p>
            <p className="flex items-center justify-center gap-1 mt-0.5">
              <Phone className="w-2.5 h-2.5 text-amber-400" />
              0345-6898969 • wa.me/923456898969
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
