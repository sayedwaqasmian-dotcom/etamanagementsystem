import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Bot, User as UserIcon, CheckCircle2, AlertTriangle, ArrowRight, CornerDownLeft } from 'lucide-react';
import { api } from '../services/api';
import { ProposedAction, User } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  proposedAction?: ProposedAction | null;
  timestamp: string;
}

interface FloatingAssistantProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
  onRefreshData?: () => void;
}

export const FloatingAssistant: React.FC<FloatingAssistantProps> = ({
  currentUser,
  onNavigateTab,
  onRefreshData,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-init',
      sender: 'assistant',
      text: `Assalam-o-Alaikum ${currentUser.name}! I am **ETA Smart Assistant** for The Excellent Tuition Academy Khwazakhela, Swat.\n\nYou can ask in **English** or **Roman Urdu**, for example:\n• "Ahmad ko class 7 mein add kar do."\n• "Is mahine kitni fees collect hui?"\n• "Pending fees walay students ki list dikhao."\n• "Aaj class 6 ki attendance dikhao."\n\nHow can I help you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInput('');
    setLoading(true);

    try {
      const res = await api.ai.sendMessage(textToSend, currentUser.role, currentUser.name);
      const assistantMsg: Message = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: res.reply,
        proposedAction: res.proposedAction,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: 'assistant',
          text: `Apologies, I encountered an error: ${err.message || 'Unable to connect to assistant service.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteAction = async (msgId: string, action: ProposedAction) => {
    if (action.type === 'NAVIGATE' && action.params?.route) {
      const tab = action.params.route.replace('/', '');
      onNavigateTab(tab);
      setIsOpen(false);
      return;
    }

    try {
      setLoading(true);
      const res = await api.ai.executeAction(action.type, action.params);
      
      // Update message to show action completed
      setMessages((prev) =>
        prev.map((m) =>
          m.id === msgId ? { ...m, proposedAction: null } : m
        )
      );

      setMessages((prev) => [
        ...prev,
        {
          id: `msg-done-${Date.now()}`,
          sender: 'assistant',
          text: `Action executed successfully: ${res.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);

      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      alert(`Action failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    'Is mahine kitni fees collect hui?',
    'Pending fees walay students ki list dikhao',
    'Aaj attendance ka kya status hai?',
    'Ahmad ko class 7 mein add kar do',
  ];

  return (
    <>
      {/* Floating Trigger Button */}
      <div className="no-print fixed bottom-18 md:bottom-6 right-5 z-40">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-xs shadow-2xl shadow-amber-500/30 transition transform hover:scale-105 active:scale-95 border-2 border-slate-900"
          title="Open ETA Smart Assistant"
        >
          <Sparkles className="w-5 h-5 text-slate-950 animate-bounce" />
          <span className="hidden sm:inline">ETA AI Assistant</span>
          <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900"></span>
        </button>
      </div>

      {/* Slide-over Drawer */}
      {isOpen && (
        <div className="no-print fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col text-slate-100 shadow-2xl animate-in slide-in-from-right duration-300">
            
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center font-black text-slate-950 text-sm shadow-md">
                  ETA
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                    ETA Smart Assistant
                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                      AI
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    The Excellent Tuition Academy Khwazakhela
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Language & Capabilities Badge */}
            <div className="px-4 py-2 bg-blue-950/40 border-b border-slate-800/80 text-[11px] text-blue-300 flex items-center justify-between">
              <span>Supports: <strong>English</strong> & <strong>Roman Urdu</strong></span>
              <span className="text-amber-400 font-medium">Safe Action Preview</span>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-1 px-1">
                    {m.sender === 'user' ? (
                      <>
                        <span>{currentUser.name}</span>
                        <UserIcon className="w-3 h-3 text-blue-400" />
                      </>
                    ) : (
                      <>
                        <Bot className="w-3 h-3 text-amber-400" />
                        <span>ETA Assistant</span>
                      </>
                    )}
                    <span>• {m.timestamp}</span>
                  </div>

                  <div
                    className={`max-w-[88%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-blue-600 text-white rounded-tr-xs'
                        : 'bg-slate-800 text-slate-100 rounded-tl-xs border border-slate-700/80 shadow-md whitespace-pre-wrap'
                    }`}
                  >
                    {m.text}

                    {/* Proposed Action Card */}
                    {m.proposedAction && (
                      <div className="mt-3 p-3 rounded-xl bg-slate-950/90 border border-amber-500/40 text-slate-200">
                        <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs mb-1">
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>{m.proposedAction.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-snug">
                          {m.proposedAction.description}
                        </p>

                        {/* Action Preview Params */}
                        {m.proposedAction.params && (
                          <div className="mt-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300 space-y-0.5">
                            {Object.entries(m.proposedAction.params).map(([k, v]) => (
                              <div key={k} className="flex justify-between">
                                <span className="text-slate-400">{k}:</span>
                                <span className="text-amber-300 font-semibold">{String(v)}</span>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Confirmation Buttons */}
                        <div className="mt-3 flex items-center gap-2">
                          <button
                            onClick={() => handleExecuteAction(m.id, m.proposedAction!)}
                            disabled={loading}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition disabled:opacity-50"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {m.proposedAction.type === 'NAVIGATE' ? 'Go to Page' : 'Confirm & Execute'}
                          </button>
                          <button
                            onClick={() => {
                              setMessages((prev) =>
                                prev.map((item) =>
                                  item.id === m.id ? { ...item, proposedAction: null } : item
                                )
                              );
                            }}
                            className="py-1.5 px-2.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white text-xs transition"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 text-xs text-amber-400 bg-slate-800/80 p-3 rounded-2xl max-w-[70%] border border-slate-700">
                  <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
                  <span>ETA Assistant is thinking...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Sample Suggestions */}
            <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/40 overflow-x-auto flex gap-1.5 no-scrollbar">
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(p)}
                  className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 border border-slate-700 transition"
                >
                  {p}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <div className="p-3 border-t border-slate-800 bg-slate-950">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask in English or Roman Urdu..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 transition disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
