import React, { useState } from 'react';
import {
  Bell,
  Search,
  Sparkles,
  UserPlus,
  PlusCircle,
  CalendarCheck,
  CheckCheck,
  Phone,
  Moon,
  Sun,
  Menu,
  X,
  CreditCard,
  GraduationCap,
} from 'lucide-react';
import { User } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  currentUser: User;
  onOpenQuickAction: (action: string) => void;
  onSelectTab: (tab: string) => void;
  unreadCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onOpenQuickAction,
  onSelectTab,
  unreadCount = 3,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const notifications = [
    { id: 1, title: 'Fee Payment Pending', message: '3 students in Class 7th & 9th have overdue fees for October 2026.', time: '10 mins ago', type: 'fee', tab: 'fees' },
    { id: 2, title: 'Absence Notice Today', message: '1 student (Bilal Khan) absent in Class 7th. WhatsApp alert ready.', time: '35 mins ago', type: 'attendance', tab: 'attendance' },
    { id: 3, title: 'Upcoming ETEA Practice Test', message: 'MDCAT Biology practice exam scheduled for Class 12th.', time: '1 hr ago', type: 'exam', tab: 'etea' },
  ];

  return (
    <header className="no-print sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="flex items-center justify-between px-4 lg:px-6 py-2.5">
        
        {/* Left: Academy Branding & Mobile Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="md:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            {showMobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-sm lg:text-base text-white tracking-tight">
                ETA Academy Management System
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Swat, KP
              </span>
            </div>
            <p className="hidden md:block text-[11px] text-amber-400 font-medium tracking-wide">
              Quality Education | Brighter Future | Better Tomorrow
            </p>
          </div>
        </div>

        {/* Center/Right: Quick Actions */}
        <div className="flex items-center gap-2 lg:gap-3">
          
          {/* Quick Action Buttons (Role Restricted) */}
          <div className="hidden xl:flex items-center gap-1.5 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            {currentUser.role !== 'attendance_operator' && (
              <button
                onClick={() => onOpenQuickAction('ADD_STUDENT')}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition"
              >
                <UserPlus className="w-3.5 h-3.5 text-blue-400" />
                <span>+ Student</span>
              </button>
            )}

            {(currentUser.role === 'principal' || currentUser.role === 'accountant' || currentUser.role === 'admin') && (
              <button
                onClick={() => onOpenQuickAction('COLLECT_FEE')}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition"
              >
                <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                <span>Collect Fee</span>
              </button>
            )}

            <button
              onClick={() => onSelectTab('attendance')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition"
            >
              <CalendarCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Attendance</span>
            </button>
          </div>

          {/* AI Smart Assistant Quick Button */}
          <button
            onClick={() => onSelectTab('ai')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/10 transition transform active:scale-95"
            title="Open ETA Smart Assistant (English & Roman Urdu)"
          >
            <Sparkles className="w-3.5 h-3.5 text-slate-950" />
            <span className="hidden sm:inline">ETA Assistant</span>
          </button>

          {/* WhatsApp Direct Link */}
          <a
            href="https://wa.me/923456898969"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs font-semibold transition"
            title="Academy WhatsApp Official"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="hidden md:inline font-mono">0345-6898969</span>
          </a>

          {/* In-App PWA Install */}
          <PWAInstallButton variant="header" />

          {/* Notification Center */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-4 text-slate-100 z-50">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Notifications & Alerts
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-slate-950">
                      {notifications.length}
                    </span>
                  </div>
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    Close
                  </button>
                </div>

                <div className="divide-y divide-slate-800 mt-2 max-h-72 overflow-y-auto">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        setShowNotifications(false);
                        onSelectTab(n.tab);
                      }}
                      className="py-3 px-2 rounded-xl hover:bg-slate-800/60 cursor-pointer transition"
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-white">{n.title}</p>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">{n.message}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-3 mt-2 border-t border-slate-800 text-center">
                  <button
                    onClick={() => {
                      setShowNotifications(false);
                      onSelectTab('reports');
                    }}
                    className="text-xs font-semibold text-amber-400 hover:underline"
                  >
                    View All Academy Reports →
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Mobile Navigation Drawer */}
      {showMobileMenu && (
        <div className="md:hidden border-t border-slate-800 bg-slate-950 p-4 space-y-2">
          <div className="text-[10px] font-bold uppercase text-slate-500 px-2 pb-1">
            Navigate Modules
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button onClick={() => { onSelectTab('dashboard'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">📊 Dashboard</button>
            <button onClick={() => { onSelectTab('students'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">👨‍🎓 Students</button>
            <button onClick={() => { onSelectTab('fees'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">💰 Fees (PKR)</button>
            <button onClick={() => { onSelectTab('attendance'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">📅 Attendance</button>
            <button onClick={() => { onSelectTab('exams'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">📝 Exams</button>
            <button onClick={() => { onSelectTab('etea'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">🎯 ETEA Practice</button>
            <button onClick={() => { onSelectTab('teachers'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-slate-900 text-left font-medium">👨‍🏫 Teachers</button>
            <button onClick={() => { onSelectTab('ai'); setShowMobileMenu(false); }} className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 text-left font-bold">🤖 ETA AI</button>
          </div>
        </div>
      )}
    </header>
  );
};
