import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  BookOpen,
  Users2,
  Receipt,
  CalendarCheck2,
  FileSpreadsheet,
  BrainCircuit,
  Settings,
  PhoneCall,
  Sparkles,
  BarChart3,
  LogOut,
  ChevronRight,
} from 'lucide-react';
import { User, UserRole } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  currentUser: User;
  onLogout: () => void;
  onSwitchRole: (role: UserRole) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onLogout,
  onSwitchRole,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['principal', 'admin', 'teacher', 'accountant', 'attendance_operator'] },
    { id: 'students', label: 'Students', icon: GraduationCap, roles: ['principal', 'admin', 'teacher', 'accountant'] },
    { id: 'classes', label: 'Classes & Sections', icon: BookOpen, roles: ['principal', 'admin', 'teacher'] },
    { id: 'teachers', label: 'Teachers & Staff', icon: Users2, roles: ['principal', 'admin'] },
    { id: 'fees', label: 'Fee Management', icon: Receipt, badge: 'PKR', roles: ['principal', 'accountant', 'admin'] },
    { id: 'attendance', label: 'Attendance', icon: CalendarCheck2, roles: ['principal', 'admin', 'teacher', 'attendance_operator'] },
    { id: 'exams', label: 'Tests & Exams', icon: FileSpreadsheet, roles: ['principal', 'admin', 'teacher'] },
    { id: 'etea', label: 'ETEA Practice', icon: BrainCircuit, badge: 'MCQs', roles: ['principal', 'admin', 'teacher'] },
    { id: 'reports', label: 'Reports & Export', icon: BarChart3, roles: ['principal', 'admin', 'accountant'] },
    { id: 'ai', label: 'ETA Smart Assistant', icon: Sparkles, badge: 'AI', highlight: true, roles: ['principal', 'admin', 'teacher', 'accountant', 'attendance_operator'] },
    { id: 'settings', label: 'Academy Settings', icon: Settings, roles: ['principal', 'admin'] },
  ];

  const filteredNavItems = navItems.filter((item) => item.roles.includes(currentUser.role));

  const roleLabels: Record<UserRole, { label: string; color: string }> = {
    principal: { label: 'Principal / Super Admin', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' },
    admin: { label: 'Administrator', color: 'bg-blue-500/20 text-blue-300 border-blue-500/40' },
    teacher: { label: 'Faculty / Teacher', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' },
    accountant: { label: 'Accounts Officer', color: 'bg-purple-500/20 text-purple-300 border-purple-500/40' },
    attendance_operator: { label: 'Attendance Operator', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' },
  };

  return (
    <aside className="no-print hidden md:flex flex-col w-64 lg:w-72 bg-slate-950 border-r border-slate-800 text-slate-200 select-none shrink-0 min-h-screen">
      
      {/* Academy Brand Header */}
      <div className="p-4 lg:p-5 border-b border-slate-800/80 bg-gradient-to-b from-blue-950/40 to-transparent">
        <div className="flex items-center gap-3">
          <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/10 border-2 border-amber-300">
            <span className="font-black text-slate-950 text-base tracking-tighter">ETA</span>
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950"></span>
          </div>
          <div className="overflow-hidden">
            <h1 className="font-black text-sm lg:text-base tracking-tight text-white uppercase truncate">
              ETA Academy
            </h1>
            <p className="text-[10px] text-amber-400 font-bold uppercase tracking-wider truncate">
              Khwazakhela, Swat
            </p>
          </div>
        </div>

        <div className="mt-3 py-1.5 px-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
          <span className="truncate">Classes: <strong>6th to 12th</strong></span>
          <span className="font-bold text-amber-400 font-mono">Rs. PKR</span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          Academy Modules
        </div>

        {filteredNavItems.map((item) => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/20'
                  : item.highlight
                  ? 'text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/80'
              }`}
            >
              <div className="flex items-center gap-3 truncate">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-white' : item.highlight ? 'text-amber-400' : 'text-slate-400 group-hover:text-amber-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase tracking-wider ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : item.highlight
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Role Switcher & User Profile */}
      <div className="p-3 border-t border-slate-800 bg-slate-900/60 space-y-2.5">
        
        {/* Quick Role Switcher for instant verification */}
        <div className="bg-slate-950/70 p-2 rounded-xl border border-slate-800 text-[10px]">
          <div className="flex items-center justify-between text-slate-400 mb-1 font-semibold">
            <span>Active Role:</span>
            <span className={`px-1.5 py-0.2 rounded border ${roleLabels[currentUser.role]?.color || ''}`}>
              {currentUser.role}
            </span>
          </div>

          <select
            value={currentUser.role}
            onChange={(e) => onSwitchRole(e.target.value as UserRole)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-slate-200 text-xs focus:outline-hidden focus:border-amber-400"
            title="Switch user role to test permissions"
          >
            <option value="principal">👑 Principal (Mr. Rahmat Ali)</option>
            <option value="admin">💼 Administrator</option>
            <option value="teacher">👨‍🏫 Teacher (Mr. Nouman Khan)</option>
            <option value="accountant">💰 Accountant (Muhammad Farooq)</option>
            <option value="attendance_operator">📋 Attendance Operator</option>
          </select>
        </div>

        {/* User Card */}
        <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
              {currentUser.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-white truncate">{currentUser.name}</p>
              <p className="text-[10px] text-slate-400 truncate">{currentUser.email}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            title="Sign out"
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>

        {/* PWA Install Button */}
        <PWAInstallButton variant="sidebar" />

        {/* Academy Contact Bar */}
        <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
          <a
            href="https://wa.me/923456898969"
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-400 hover:underline flex items-center gap-1 font-mono"
          >
            <PhoneCall className="w-2.5 h-2.5" />
            0345-6898969
          </a>
          <span className="text-slate-500">v2.5 PWA</span>
        </div>

      </div>
    </aside>
  );
};
